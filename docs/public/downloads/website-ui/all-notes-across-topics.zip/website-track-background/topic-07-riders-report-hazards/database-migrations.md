<!-- changed-box:start -->
> **What changed since this was written**
>
> This note was written around Aug 11, 2026, before the website repository was restructured on Sept 26, 2026.
>
> - The `ridescoredc` table → `data.road_segment` + `data.ridescore_v1_scores`, served only through the `serving` schema: `serving.survey_segments` for the survey (street names and shapes, no score) and `serving.update_score` for the scored map. Martin publishes only `serving`.
> - `crashes_dc` layer/table → `crashes` (served from the database's `serving` schema; tiles at `/tiles/crashes/...`).
> - This note describes the older `ridescoredc-models` `live/` yoyo setup. The survey tables (`app.survey_submissions`, `app.survey_contiguous_segments`, `app.survey_granular_segments`) now have their own migrations in the website repo at `api/migrations/`, applied with `npm run migrate`. Road data has no migrations: it is reloaded wholesale with `npm run data`.
> - Server deployment commands (SSH, checkout and venv steps) have been removed from this copy.
> - Links to other `docs-4-ai/...` notes: those notes are in this pack's topic folders. `infrastructure-overview.md` is not included; the guide pages replace it.
>
> Ideas and analysis here are still useful; names, paths and line numbers may not match today's code. Check against https://github.com/civictechdc/ridescoredc-website (develop).
<!-- changed-box:end -->

# Database migrations — RideScore models (yoyo)

Internal notes on how database schema/data changes reach staging and prod for the
`ridescoredc-models` repo. Companion to `infrastructure-overview.md`.

## Tooling

- Migrations are managed with **yoyo-migrations**, under `ridescoredc-models/live/`.
- yoyo talks to Postgres via **psycopg 3**, which it selects from the URL *scheme*:
  it is invoked with a `postgresql+psycopg://…` URL. The plain `postgresql://`
  form of the same `DATABASE_URL` is what `psql` (used by the baseline load) and
  Martin consume — the deploy script and CI rewrite the scheme for yoyo only.
  There is no psycopg2 anywhere.
- yoyo records every applied version in the `_yoyo_migration` table and takes a
  lock, so each migration runs exactly once per database and concurrent applies
  are safe.

## What's in `live/`

- `migrations/0001_baseline.py` — the **authoritative baseline**. It loads
  `schema/0001_baseline.sql`, a full **pg_dump** of the source DB (PostGIS
  extensions, tiger/topology, the model tables `ridescoredc` + `crashes_dc` *with
  data*, and the `update_score` tile function). A pg_dump isn't fully
  driver-runnable (it has `\restrict` and `COPY … FROM stdin`), so the migration
  replays it over **yoyo's own connection**: plain SQL through the cursor, and
  each `COPY` block streamed via psycopg 3's `cursor.copy()`. No `psql`, no
  separate connection, and no `DATABASE_URL` needed for the migration itself.
- `migrations/post-apply.py` — a repeatable lane that re-applies `functions/*.sql`
  (`CREATE OR REPLACE`) after every run. `functions/` is currently empty.
- `schema/wip-patch.sql` — WIP survey-table DDL (moved out of the website's old
  boot-time patch). **Not applied by yoyo yet.**
- `schema/wip-update_score_v2.sql` — WIP Martin tile function (v2). **Not applied
  by yoyo yet**; the live tile function is `update_score` (v1), which ships inside
  the baseline dump.

## Postgres version

Staging and prod run **PostgreSQL 16**, so CI's smoke-apply uses
`postgis/postgis:16-3.5` — keep that image's major version in sync if the servers
move. The baseline dump was taken from **PG 17.8**, but the only PG-17-specific
line in it is `SET transaction_timeout = 0` (a GUC that didn't exist before 17);
`0001_baseline.py` skips it, so the dump loads cleanly on 16. If a future
regenerated dump trips another *"unrecognized configuration parameter"*, add that
`SET` to the skip list in `0001_baseline.py`.

## Deploy model (early phase = manual)

**CI does not deploy.** The models `ci.yml` runs checks only: lint, structure
(migration naming/order), an append-only guard (committed migrations are
immutable — you add a new one, never edit history), and a smoke-apply against a
throwaway PostGIS (apply → assert → rollback → re-apply).

Applying to a real database is **manual** for now: after a PR merges and CI is green, a maintainer applies pending migrations on the staging server first, then production. (Server deployment commands redacted from this copy.)

Key points:

- **No service restart needed.** Martin serves tiles with caching disabled
  (`MARTIN_CACHE_SIZE=0`), so table/data/function changes show up live. If caching
  is ever turned on, restart Martin after a change.
- **Idempotent + canary.** yoyo records applied versions in `_yoyo_migration`, so
  re-running is a no-op when nothing is pending. Staging is the canary — never
  apply to prod until staging looks right.

Adopting an existing database that already has these tables means marking the baseline as already applied rather than applying it. (Server-specific details redacted from this copy.)

## Data / model-refresh cadence

- The upstream **GIS / DC open data may refresh roughly monthly**, which can
  change the scored-segment inputs (`ridescoredc`) and crash points (`crashes_dc`).
- We do **not** intend to ship a migration for every monthly refresh. Instead we
  plan to **batch model-data updates into one group migration roughly quarterly**:
  regenerate the data, review it together, and land it as a single reviewed change.
- Practically: monthly GIS changes accumulate in the pipeline; about quarterly
  they become one new `000N_*` data migration (or a refreshed baseline dump),
  applied to staging first and then prod via the manual process above.
