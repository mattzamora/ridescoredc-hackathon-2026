<!-- changed-box:start -->
> **What changed since this was written**
>
> This note was written around Aug 11, 2026, before the website repository was restructured on Sept 26, 2026.
>
> - The `references/nearmiss` folder is not included in this pack.
>
> Ideas and analysis here are still useful; names, paths and line numbers may not match today's code. Check against https://github.com/civictechdc/ridescoredc-website (develop).
<!-- changed-box:end -->

# Dynamic Survey Creation from JSON — Technical Implementation Report

> Reference: `references/nearmiss`

---

## Overview

The NearMiss app implements a JSON-driven survey engine in **SvelteKit 2 / Svelte 5**. Survey structure is entirely data-defined — adding or modifying a survey requires only editing a JSON file, no code changes.

---

## 1. JSON Schema Structure

Surveys live in `src/lib/data/` as plain JSON files (`nvfssSurvey.json`, `wabaSurvey.json`, `surveyAllOnePage.json`). The schema is three levels deep:

```
Survey
  └── pages[]
        └── questions[]
              ├── legend       — field label
              ├── key          — form field name (also URL param key)
              ├── type         — "checkbox" | "radio" | "textarea" | "date" | "geospatial"
              ├── required     — boolean validation flag
              ├── choices[]    — options for radio/checkbox
              └── description  — array of help text strings
```

The `type` field is the discriminator that drives the entire rendering pipeline.

**Example question definition:**
```json
{
  "legend": "What are you reporting?",
  "key": "report types",
  "description": ["Check all that apply"],
  "required": true,
  "type": "checkbox",
  "choices": ["Near Miss", "Dangerous Location"]
}
```

---

## 2. Rendering Pipeline

```
JSON file
   ↓  imported at route load
Survey object (typed via types.ts)
   ↓  passed as prop
SurveyForm.svelte  (multi-page orchestrator)
   ↓  iterates survey.pages[currentPage].questions
FieldSet.svelte  (per-question dispatcher)
   ↓  switches on question.type
CheckboxInput | RadioInput | TextAreaInput | DateTimeInput | GeospatialInput
```

**FieldSet** is the critical dispatch layer — a thin `{#if}` chain on `question.type` that hands the `Question` object down to the correct leaf component. Each leaf component is self-contained and knows nothing about the survey structure above it.

### TypeScript Types (`src/lib/types.ts`)

```typescript
type Question = {
  legend: string
  key: string
  description: string[]
  required?: boolean
  choices?: string[]
  type: string   // "checkbox" | "radio" | "textarea" | "date" | "geospatial"
}

type SurveyPage = {
  title: string
  description?: string
  questions?: Question[]
}

type Survey = {
  id: number | string
  title: string
  pages: SurveyPage[]
}

type SurveyAnswer = {
  survey_id: number | string
  report_id: number | string
  answer_string: string       // JSON stringified form data
  last_page_viewed: number
  submitted: boolean
}
```

---

## 3. State Management — Two-Layer Persistence

Every input component syncs its value to **two places simultaneously**:

| Layer | Mechanism | Purpose |
|---|---|---|
| URL search params | `page.url.searchParams.set/append(key, value)` | Shareable links, page refresh survival |
| IndexedDB (Dexie) | `updateSurveyAnswerText(JSON.stringify(formObj), answer)` | Cross-session persistence, offline |

On mount, components read initial values from URL params — meaning a partially filled survey can be resumed just by revisiting the URL. Multi-select fields (checkbox) use `searchParams.append` to store repeated keys.

**IndexedDB schema (`src/lib/db.ts`):**
```typescript
const db = new Dexie('NearMissLocal') as Dexie & {
  reports: EntityTable<Report, 'id'>,
  surveyAnswers: Table<SurveyAnswer, '[report_id+survey_id]'>
};

db.version(1).stores({
  reports: '++id, date, position, inserted_at, updated_at',
  surveyAnswers: '[report_id+survey_id], submitted, report_id, survey_id'
});
```

The `answer_string` field stores the full form data as a JSON blob — capturing all keys including multi-valued checkboxes.

---

## 4. Form Data Collection & Serialization

On every page transition, `SurveyForm` collects the entire `<form>` via the `FormData` API and merges it into a single object:

```typescript
const formObj = Object.fromEntries(
  [...formData.keys()].map((key) => [key, [...new Set(formData.getAll(key))]])
);
updateSurveyAnswerText(JSON.stringify(formObj), surveyAnswer);
```

`FormData.getAll()` handles checkbox multi-select correctly. `Set` deduplication prevents duplicate entries on repeated saves.

**Serialized format stored in IndexedDB:**
```json
{
  "report types": ["Near Miss", "Dangerous Location"],
  "reporting": ["Driver"],
  "description": "Incident description text",
  "location": "-77.357, 38.9586",
  "date": "2024-01-15T14:30"
}
```

---

## 5. Special Question Type: Geospatial

The `geospatial` type renders a full **MapLibre GL** map with a click-to-place marker. It stores coordinates as a URL param string (`"-77.357, 38.9586"`) and as GeoJSON features internally.

A utility function in `src/lib/surveyutils.ts` scans the schema to find all question keys of a given type, then pre-populates them from the report's known position at load time:

```typescript
function keysForQuestionType(survey: Survey, type: string): string[] {
  let keys: string[] = []
  survey.pages.forEach((page) => page.questions?.forEach((question) => {
    if (question.type === type) keys = [...keys, question.key]
  }))
  return keys
}

// Usage at route load:
const geoKeys = keysForQuestionType(survey, 'geospatial');
geoKeys.forEach((key) => {
  page.url.searchParams.set(key, `${report.position[0]}, ${report.position[1]}`);
});

const dateKeys = keysForQuestionType(survey, 'date');
dateKeys.forEach((key) => {
  page.url.searchParams.set(key, dateToDatetimeLocalString(report.date));
});
```

---

## 6. Validation

- **Per-field:** Each input component derives an `invalid` boolean (`$derived(required && group.length === 0)`) and sets the HTML5 `required` attribute conditionally, enabling native browser constraint validation
- **Per-page:** On "Next", `SurveyForm` collects all invalid `<input>` elements from the DOM before allowing navigation
- **UX:** `ErrorFields.svelte` renders a sticky error banner with count; scrolls to the first invalid field

---

## 7. Multi-page Navigation & Resumption

`SurveyForm` tracks `currentPage` (1-indexed). `last_page_viewed` is persisted to IndexedDB on each page transition. On reload, `getOrCreateSurveyAnswer()` is idempotent — it returns the existing record if present and pre-populates URL params from the stored `answer_string`, enabling full form resumption.

**Report creation flow:**
```
1. User creates report (with geolocation)
   → createReport(date, position) → IndexedDB.reports

2. User navigates to /reports/[id]
   → getOrCreateSurveyAnswer(survey.id, report.id)
   → Pre-populate URL params from saved answer_string

3. SurveyForm mounts, user fills out pages
   → Each page nav: updateSurveyAnswerText() saves to DB
   → last_page_viewed tracked for resumption

4. Final page submit
   → updateSurveyAnswerSubmitted(true, surveyAnswer)
   → Optional POST to backend API
```

---

## 8. API Integration (`src/lib/api.ts`)

| Endpoint | Method | Purpose |
|---|---|---|
| `/v1/anonymous` | POST | Register anonymous user |
| `/v1/anonymous/otp` | POST | Generate one-time password |
| `/v1/reports` | POST | Submit report with survey answers |
| `/v1/reports` | DELETE | Delete report (OTP verified) |

Submission is optional — the app is fully functional offline with IndexedDB as the source of truth.

---

## 9. Stack

| Concern | Technology |
|---|---|
| Framework | SvelteKit 2 / Svelte 5 |
| Reactivity | `$state`, `$derived`, `bind:` |
| Styling | Tailwind CSS 4 + @tailwindcss/forms |
| Mapping | MapLibre GL 5 |
| Local DB | Dexie 4 (IndexedDB) |
| Types | TypeScript 5 |
| Build | Vite 6 |

---

## Key Design Decisions

- **JSON as schema, not config** — the entire survey structure (pages, ordering, question types, choices) is expressed in JSON, making it editable without code changes
- **`key` doubles as URL param name** — the question's `key` field is used directly as the URL search parameter key, coupling the schema to state management with no additional mapping layer
- **No central store** — state lives in URL params (ephemeral) and IndexedDB (persistent); no Svelte store layer
- **Leaf components are stateless** — each input reads from and writes to URL params; `SurveyForm` owns the lifecycle and persistence logic
- **Idempotent DB operations** — `getOrCreateSurveyAnswer()` ensures no duplicate records and enables safe re-entry

---

## File Reference

| File | Role |
|---|---|
| `src/lib/data/nvfssSurvey.json` | 4-page near-miss survey schema |
| `src/lib/data/wabaSurvey.json` | Crash tracker survey schema |
| `src/lib/data/surveyAllOnePage.json` | Single-page condensed variant |
| `src/lib/types.ts` | TypeScript interfaces (Survey, Question, SurveyAnswer) |
| `src/lib/surveyutils.ts` | `keysForQuestionType()` and helpers |
| `src/lib/db.ts` | Dexie IndexedDB schema and CRUD operations |
| `src/lib/api.ts` | Backend API client |
| `src/lib/components/forms/SurveyForm.svelte` | Multi-page form orchestrator |
| `src/lib/components/forms/elements/FieldSet.svelte` | Question type dispatcher |
| `src/lib/components/forms/elements/CheckboxInput.svelte` | Multi-select input |
| `src/lib/components/forms/elements/RadioInput.svelte` | Single-select input |
| `src/lib/components/forms/elements/TextAreaInput.svelte` | Free text input |
| `src/lib/components/forms/elements/DateTimeInput.svelte` | Date/time picker |
| `src/lib/components/forms/elements/GeospatialInput.svelte` | MapLibre map picker |
| `src/routes/reports/[slug]/+page.svelte` | Survey form route |
| `src/routes/reports/[slug]/+page.ts` | Route data loader |
