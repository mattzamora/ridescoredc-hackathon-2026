<!-- changed-box:start -->
> **What changed since this was written**
>
> This note was written around Aug 11, 2026, before the website repository was restructured on Sept 26, 2026.
>
> - `mvp_map/feedback_mvp.html` (or `feedback_mvp.html`) → `frontend/survey/index.html` (the survey, served at `/survey/`). Paint-a-route lives on the survey page, not the map page.
> - `ogc_fid` → two IDs: `segment_id` (text; a block's lasting ID; survey answers are stored against it) and `tile_id` (integer the map uses for feature-state via `promoteId`; changes every data build; never store it).
> - The `ridescoredc` table → `data.road_segment` + `data.ridescore_v1_scores`, served only through the `serving` schema: `serving.survey_segments` for the survey (street names and shapes, no score) and `serving.update_score` for the scored map. Martin publishes only `serving`.
> - Survey tables → `app.survey_submissions`, `app.survey_contiguous_segments`, `app.survey_granular_segments`. Migrations now live in the website repo at `api/migrations/` and are applied with `npm run migrate`. Columns changed too: `ogc_fid` / `ogc_fids` / `route_ogc_fids` became text `segment_id` / `segment_ids`, and each submission records a `geometry_source`. See `api/migrations/0001_app_schema.sql`.
> - `mvp_map/api/` (`main.py`, `init.sql`, Dockerfile) → `api/` in the website repo. Tables are created by `api/migrations/`, not `init.sql`. `POST /api/submissions` is called at `/api/...` on the page's own address (nginx on `localhost:8000`, or Vite on `localhost:5173`), not `http://localhost:8000` directly.
> - `docs-4-ai/survey_sample.html` is included in this folder as `survey_sample.html`.
> - Links to other `docs-4-ai/...` notes: those notes are in this pack's topic folders. `infrastructure-overview.md` is not included; the guide pages replace it.
>
> Ideas and analysis here are still useful; names, paths and line numbers may not match today's code. Check against https://github.com/civictechdc/ridescoredc-website (develop).
<!-- changed-box:end -->

# Per-Segment Survey — Design Intent & Decisions

> Status: **Implemented** (2026-05-23). All major decisions locked and built.
> Reference UI: `docs-4-ai/survey_sample.html`
> Builds on: `docs-4-ai/mvp-feedback-plan.md`
> Source of existing questions: `mvp_map/feedback_mvp.html`

---

## What We're Building

After a user paints and confirms their route, we intercept the current survey flow and replace it with a **per-segment questionnaire** using the mobile bottom-sheet UI shown in `survey_sample.html`.

The survey has two tiers:
1. **Per-contiguous-segment questions** — the main body; user steps through each contiguous segment one at a time
2. **Whole-route summary questions** — asked once, at the end, after all segments

---

## Segment Granularity — Three Tiers

| Tier | Definition | Source | Storage purpose |
|---|---|---|---|
| **Granular** | Single road geometry between two intersections | `ridescoredc.ogc_fid` | Raw data, future analysis |
| **Contiguous** | Run of consecutive granular segments sharing the same `route_name` | Derived via `route_name` grouping on the ordered selection | Primary survey + display unit |
| **Selected route** | The full painted route as one submission | All `ogc_fid`s in paint order | Session/submission record |

### Contiguous Segment Algorithm

Split into a new contiguous segment whenever `route_name` changes in the ordered sequence of painted granular segments.

The painted route is an **ordered sequence** — the sequencer algorithm (see below) walks the graph of selected `ogc_fid`s and produces a traversal order. Directionality is implied by selection order / spatial contiguity, not stored in the DB. The contiguous grouping is applied after sequencing.

**Disconnected routes**: If the user paints two spatially non-contiguous stretches, these are treated as **two separate submissions** — each gets its own full survey flow run independently.

---

## Survey UX Flow

```
User paints route(s) → "Rate route →" button
   [if disconnected stretches → split into separate submissions, each flows independently]

   Per-segment questionnaire:
      → Map: top half, auto-centers + zooms to segment 1, highlights it cyan/black
      → Bottom sheet: segment track + questions
      → User answers LTS (1–4) + Safety (1–10)
         → if LTS ≥ 3: stress factor checkboxes expand inline
      → Next → map moves to segment 2 ... repeat
      → Segments can be skipped and revisited freely via the track
      → "Finish →" button always accessible to jump past remaining segments

   Whole-route summary screen (after all segments or after "Finish →"):
      → Time of day
      → Map LTS calibration
      → Perceived traffic volume (optional)
      → Comments (optional)
      → Submit
```

### "Finish →" Mechanism
A persistent "Finish →" button or affordance is visible at all times during the per-segment flow, allowing users who are skipping most segments to proceed directly to the whole-route summary screen without stepping through every segment node.

---

## Map Behavior During Survey

- **Mobile**: map occupies top ~50% of screen; bottom sheet occupies lower ~50%
- **Desktop**: map fills most of the screen; survey panel slides in from the right (similar to current setup)
- **All painted segments**: retain the paint-selection blue used during route drawing
- **Active contiguous segment**: highlighted **cyan with a black border** — distinct from both the base map and the painted-blue selection, and chosen deliberately to not suggest any LTS rating or quality judgment
- **Completed segments**: green node in track timeline
- **Pending segments**: gray node in track timeline
- Map **auto-centers and zooms** to the active contiguous segment when advancing or when a node is tapped in the track
- The map does **not** display the computed LTS color for the active segment during the survey to avoid biasing responses — the user sees only the cyan highlight and the base map

---

## Bottom Sheet UI (per `survey_sample.html`)

Four zones, unified layout that scales from 1 to N segments without layout changes:

1. **Header** — "Rate your route" + progress pill (e.g. "3 / 8") + road name subtitle
2. **Segment track** — horizontally scrollable, drag-scrollable timeline. Nodes: checkmark (answered), number (pending), active enlarged circle (current). Clicking any node jumps to it and re-centers map. Auto-scrolls to keep active node visible.
3. **Question panel** — slides in/out per segment. Shows road name + questions. Stress factors expand conditionally.
4. **Footer** — Back arrow + "Next segment" button + persistent "Finish →" shortcut to whole-route summary

---

## Questions

### Per-segment (asked for each contiguous segment)

| # | Question | Type | Scale | Condition |
|---|---|---|---|---|
| 1 | Was this segment appropriate for: | Button pick | LTS 1–4 | Always |
| 2 | How safe did you feel on this segment? | Likert | 1–10 | Always |
| 3 | What drove stress on this segment? | Multi-select checkboxes | — | **Only if LTS ≥ 3** |

**Stress factor checkbox options** (shown when LTS 3 or 4 selected):
- Motor traffic speed
- Motor traffic volume
- Number of motor lanes
- Little separation from traffic
- Intersections or crossings
- Door zone or parking-adjacent
- Bike lane or path blocked
- Map bike facility did not match ground

**LTS button labels:**

| Value | Persona label | Description |
|---|---|---|
| 1 | Beginners and children | Strong separation from almost all traffic; simple crossings |
| 2 | Casual adults | Own space away from higher-speed/multilane traffic; comfortable for most adults |
| 3 | Confident riders | Moderate-speed or multilane interaction; enthused and confident riders |
| 4 | Strong and fearless | High-speed traffic interaction; only very assertive riders |

### Whole-route summary (shown once, at the end)

| # | Question | Type | Notes |
|---|---|---|---|
| 1 | When did you ride this route? | Button pick | Morning · Afternoon · Evening · Night |
| 2 | Compared to the map colors for these segments… | Button pick | I felt more stressed · About right · I felt less stressed |
| 3 | Perceived motor traffic on this ride | Button pick (optional) | Low · Medium · High |
| 4 | Any other comments? | Free text (optional) | 500 char max |

> Note: The map calibration question (Q2) refers to the colors the user sees on the map, not to the LTS numeric value. We do not mention "LTS" or display the model's computed score during the survey to avoid anchoring the user's response.

---

## Database Storage Plan

Three tables written on submission:

### `survey_submissions`
One row per user submission session.

| Column | Type | Notes |
|---|---|---|
| `submission_id` | UUID PK | |
| `submitted_at` | timestamptz | |
| `route_ogc_fids` | int[] | Ordered array of all granular segment IDs in the painted route |
| `time_of_day` | varchar | Morning / Afternoon / Evening / Night |
| `map_lts_calibration` | varchar | too_optimistic / about_right / too_pessimistic (nullable) |
| `traffic_volume` | varchar | low / medium / high (nullable) |
| `comments` | text | nullable |

### `survey_contiguous_segments`
One row per contiguous segment per submission.

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `submission_id` | UUID FK | |
| `sequence_index` | int | Order within the submission (0-based) |
| `route_name` | varchar | From `ridescoredc.route_name` |
| `ogc_fids` | int[] | Ordered granular segment IDs making up this contiguous segment |
| `lts_perceived` | int | 1–4 (nullable — partial responses allowed) |
| `safety_rating` | int | 1–10 (nullable — partial responses allowed) |
| `stress_factors` | text[] | Only populated when `lts_perceived` ≥ 3; nullable otherwise |

### `survey_granular_segments`
One row per granular segment per submission (for future use, inherits contiguous-level ratings).

| Column | Type | Notes |
|---|---|---|
| `submission_id` | UUID FK | |
| `ogc_fid` | int FK → `ridescoredc` | |
| `contiguous_segment_id` | UUID FK | |
| `sequence_index` | int | Order within the submission |

---

## Implementation Notes

### Files changed / created
| File | What changed |
|---|---|
| `mvp_map/feedback_mvp.html` | Old flat survey panel replaced with per-segment bottom-sheet. New CSS, HTML, and JS. Old `openSurveyPanel()` now launches segment survey. |
| `mvp_map/api/main.py` | FastAPI app — `POST /api/submissions`, `GET /health`. Runs `init.sql` on startup with retry. |
| `mvp_map/api/init.sql` | Creates `survey_submissions`, `survey_contiguous_segments`, `survey_granular_segments` (idempotent). |
| `mvp_map/api/requirements.txt` | fastapi, uvicorn, psycopg2-binary, pydantic |
| `mvp_map/api/Dockerfile` | python:3.12-slim, copies main.py + init.sql, runs uvicorn on port 8000 |
| `mvp_map/docker-compose.yml` | Added `api` service (port 8000, depends on db) |

### Key frontend additions
- `segmentGeoCenter` map — stores `[lng, lat]` midpoint per `ogc_fid` when painting; used for map fly-to during survey
- `road-survey-border` + `road-survey-active` map layers — black/cyan highlight for active contiguous segment; controlled via `feature-state.surveyActive`
- `buildContiguousSegments()` — groups `strokeOrderedSegmentIds` by consecutive `route_name` changes
- `fitMapToSegmentFids()` — flies map to bbox of active segment, with bottom padding for the sheet on mobile

### API endpoint
```
POST http://localhost:8000/api/submissions
Content-Type: application/json

{
  "route_ogc_fids": [int, ...],
  "contiguous_segments": [
    {
      "sequence_index": int,
      "route_name": "string | null",
      "ogc_fids": [int, ...],
      "lts_perceived": int | null,    // 1–4
      "safety_rating": int | null,    // 1–10
      "stress_factors": ["string"] | null  // only when lts_perceived >= 3
    }
  ],
  "time_of_day": "string | null",
  "map_lts_calibration": "string | null",
  "traffic_volume": "string | null",
  "comments": "string | null"
}

Response 201: { "submission_id": "uuid" }
```

---

## Sequencer Algorithm — Implemented

`computeRouteSequence()` in `feedback_mvp.html`, runs when the survey is opened.

### Data stored during painting
- `segmentEndpoints` Map: `ogc_fid → [[lngA,latA],[lngB,latB]]` — the first and last vertices of the segment's LineString geometry, captured in `findBestCandidate` and stored via `commitSegment`.
- `strokeOrderedSegmentIds` array: segments in the order they were committed (baseline paint order, survives edits).

### Steps
1. **Adjacency graph** — Two segments are neighbours if any of their four endpoint-pair distances is < 0.0001° (~10 m). This threshold absorbs floating-point drift; road-network endpoints at shared intersections are nominally identical.
2. **Connected components in paint order** — BFS seeded from the unvisited segment with the lowest paint-order index. Components are ordered by when the user first touched each group, so disconnected stretches appear in the order they were painted. Segment numbering is continuous across components (component A ends at N, component B starts at N+1).
3. **Direction-preserving walk per component**:
   - Identify the **first-painted** segment in the component (lowest `strokeOrderedSegmentIds` index).
   - **BFS outward from first-painted** to find the nearest degree-1 node (route endpoint). Choosing the *nearest* endpoint rather than the *earliest-painted* endpoint anchors the counting direction to the same side the user began drawing, regardless of how many segments were added later in the opposite direction.
   - **Greedy neighbor-to-neighbor walk** from that endpoint. At each step, choose the unvisited neighbour with the lowest paint-order index (preserves original drawing direction through turns and 90° bends). Only adjacent segments are ever visited consecutively — no jumping.
   - Branches and segments lacking endpoint data are appended in paint order at the end of the component.
4. **Contiguous grouping** — Group consecutive segments in the sequenced output by `route_name` change → contiguous survey segments.

### Guarantees
- Within a connected component, consecutive entries in the sequence are always graph-adjacent (share an intersection endpoint). No mid-route jumping.
- The start of the sequence matches the end of the route the user began drawing from.
- Disconnected components continue numbering from the end of the prior component.

### Edge cases handled
- **Loops** (no degree-1 node): BFS finds nothing → falls back to first-painted as start.
- **Branches**: greedy walk covers the main path; unreachable segments appended in paint order.
- **Missing endpoint data**: segment is isolated in the adjacency graph, becomes its own single-node component, ordered by paint index.
- **Intermediate segments added after main stroke**: because BFS determines direction from the first-painted anchor rather than from paint-order of endpoints, later additions do not shift the counting direction.
