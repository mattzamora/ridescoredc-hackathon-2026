<!-- changed-box:start -->
> **What changed since this was written**
>
> This analysis is new (October 2026) and was checked against `ridescoredc-website` develop at commit 38386ee (Sept 30, 2026). It already uses today's names (`frontend/survey/index.html`, `tile_id`, `segment_id`, `survey_segments`). Line numbers are approximate and will drift.
>
> Ideas and analysis here are still useful; names, paths and line numbers may not match today's code. Check against https://github.com/civictechdc/ridescoredc-website (develop).
<!-- changed-box:end -->

# Route-selector bugs — analysis for hackathon Topic 6

> File: `frontend/survey/index.html` in `ridescoredc-website` (develop, commit 38386ee, 2,252 lines), served at `/survey/`.
> Line numbers are approximate: they were checked against that commit and will drift as the file changes. Search by function name rather than trusting a number.

Two bugs make the paint-a-route selector pick the wrong blocks. This note explains what the code does today, why each bug happens, how to reproduce it, and some fix ideas. The fix ideas are starting points, not tested solutions.

---

## How painting works today (short version)

1. `pointermove` on the paint canvas records screen points and, at most every 50 ms, calls `enqueuePaintSnap(pt)` (approximately lines 1438–1462).
2. `enqueuePaintSnap` calls `findBestCandidate(pt)` to pick one street piece near the pointer, pushes it onto `snapQueue`, and marks it with the `pending` feature-state (the light-blue "about to be selected" highlight).
3. `tryDrainSnapQueue` (approximately 1376–1393) waits until the queue holds `COMMIT_LAG` = 8 picks, then checks the oldest pick against the direction the stroke actually went afterwards. It either commits that pick or drops it.
4. On `pointerup`, `finishStrokePipeline` (approximately 1557–1566) flushes the queue with a looser threshold and then prunes any block added this stroke that sits far from the stroke (`pruneSelectionsFarFromRawPolyline`).

Feature IDs on this page are `tile_id` (promoted with `promoteId` at approximately line 774). Responses are stored by `segment_id`, looked up at submit time.

---

## Bug A — wrong street picked at intersections

### What the code does

`findBestCandidate` (approximately lines 1260–1346):

- Queries rendered features on layer `road-score` in a box of ±`SNAP_RADIUS` around the pointer. `SNAP_RADIUS` = 40 (line ~1208), so the box is about 80 × 80 px.
- For every edge of every feature, computes `dist` = pixel distance from pointer to the edge.
- Computes a direction `penalty` from the stroke's momentum: `penalty = PERP_PENALTY - (PERP_PENALTY - 1) * alignment` (line ~1306), with `PERP_PENALTY` = 3.5. So an edge aligned with the stroke gets 1, a perpendicular edge gets 3.5.
- Applies a continuity multiplier `contMult` (approximately 1310–1317): if either end of the edge is within `CONTINUITY_PX` = 16 px of either end of `lastCommittedEdge`, multiply by `CONTINUITY_SCORE_MULT` = 0.58.
- Applies a revisit multiplier of 1.14 to blocks already selected (`AVOID_REVISIT_MULT`, line ~750; used at ~1321).
- Final score (line ~1319, then ~1321): `score = dist * penalty * contMult`, times the revisit factor where it applies. The lowest score wins, using a strict `<` (line ~1323).

### Why it goes wrong

1. **Multiplying by distance cancels direction at the intersection.** When the pointer is on the intersection, `dist` is close to 0 for every street that meets there. `0 × 1` and `0 × 3.5` are both about 0, so direction stops mattering at exactly the moment it matters most.
2. **Ties go to whichever feature MapLibre lists first.** With all scores about 0, the strict `<` keeps the first edge that reached the minimum. That order comes from `queryRenderedFeatures` and has nothing to do with the stroke.
3. **The lookahead can only accept or drop, never re-pick.** `tryDrainSnapQueue` checks the queued pick against the direction the stroke went next (`|dot| ≥ COMMIT_ALIGN_THRESHOLD` = 0.38, line ~894; check at ~1389). If the pick was the cross street, it is dropped. Nothing goes back to ask which street *does* match that later direction, so the correct block near the corner can be lost too.
4. **The continuity bonus helps both streets equally.** `lastCommittedEdge` is the last committed edge. At the shared intersection vertex, the straight-on block and the cross street both have an endpoint within 16 px of it, so both get the 0.58 bonus. It cannot break the tie it was meant to break.
5. **`lastCommittedEdge` is stored in screen pixels and is not reset per stroke.** It is set in `commitSegment` (line ~1358) and cleared only when the selection becomes empty or is cleared (lines ~1407, ~1616, ~1632, ~1642). The paint `pointerdown` handler (approximately 978–986) resets momentum and the queue but not `lastCommittedEdge`. If the user pans or zooms between strokes, the stored pixel position now points at an unrelated place on screen, and the first picks of the next stroke can get a bonus they should not.
6. **All thresholds are fixed pixel values.** `SNAP_RADIUS` 40, `CONTINUITY_PX` 16, `MIN_MOVE` 12, `OUTLIER_PRUNE_PX` 62. Nothing in the paint code reads the zoom level, so at low zoom 40 px covers several blocks and at high zoom very little. (No `getZoom` call appears in the snapping code.)

### How to reproduce

Zoom to street level at a four-way intersection on a straight street. Paint straight through the intersection at an ordinary speed. Repeat a few times, and try a slower stroke and a stroke that wobbles slightly at the corner. You will sometimes see a stub of the cross street turn pending (light blue) and then either commit or disappear, and sometimes the block just past the intersection is missing.

### Fix ideas

- **Additive penalty instead of multiplicative:** `score = dist + k * (1 - alignment) * SNAP_RADIUS`. Direction then still counts when `dist` is about 0.
- **Re-pick instead of drop:** when the lookahead rejects a queued pick, run `findBestCandidate` again near that queued point using the post-corner direction (the `dirOverride` option already exists on `findBestCandidate`), and commit what that returns if it aligns.
- **Reset `lastCommittedEdge` on `pointerdown`**, or store it in lng/lat and re-project it when used.
- **Make the continuity bonus direction-aware:** give the bonus only to an edge that continues roughly in line with `lastCommittedEdge`, not to every edge touching its end.
- **Scale pixel thresholds with zoom**, or express them in metres and convert.
- **Deterministic tie-break:** when scores are within a small epsilon, prefer the better-aligned edge.

---

## Bug B — blocks appear, then vanish when you lift your finger

### What the code does

- Martin serves tiles. A tile only contains the part of each line that falls inside it, so a long block that crosses a tile edge arrives as **several pieces that share one `tile_id`**.
- `querySegmentFeatureById(fid)` (approximately lines 1508–1515) calls `map.querySourceFeatures('segments', …)` and returns `.find(...)`, the **first** piece with that `tile_id`.
- `segmentMinDistToPolylineScreen` (approximately 1517–1542) measures the stroke-to-block distance using only that one piece.
- `pruneSelectionsFarFromRawPolyline` (approximately 1546–1555), run on `pointerup`, drops any block added this stroke whose measured distance is more than `OUTLIER_PRUNE_PX` = 62 px (line ~900).

### Why it goes wrong

If the first piece returned is the far part of the block, in another tile, the block can measure more than 62 px from a short stroke that only touched the near piece. It is pruned on `pointerup`, so it shows blue while you paint and disappears when you lift.

### How to reproduce

1. Open `/survey/` and open the browser console.
2. Run `map.showTileBoundaries = true` to draw the tile grid.
3. Find a long block that crosses a tile boundary. Turn on Paint and paint a short stroke on the part of the block on one side of the boundary.
4. Watch it turn blue, then vanish on release. Try again on the other side; the result depends on which piece `find()` returns.

(This mechanism follows from the code; whether a given block reproduces it depends on tile layout. Treat the repro as likely, not guaranteed.)

### A related effect

The sequencer (`computeRouteSequence`, approximately line 1731) links blocks by their endpoints (`segmentEndpoints`, threshold `ENDPOINT_THRESH` = 0.0001°, line ~1729). Those endpoints come from `lineEndpointA` / `lineEndpointB` of the piece that won in `findBestCandidate`, so a clipped piece can give an endpoint at a tile edge rather than at an intersection. That can break adjacency and split the route or reorder it. This is inferred from the code and **unconfirmed** in practice.

### Fix ideas

- Use **all** pieces with that id: `filter` rather than `find`, then take the minimum distance over every piece.
- **Merge piece endpoints** per id before the sequencer groups sections, keeping the two endpoints farthest apart (or the ones that are not on a tile edge).
- Longer term: ask the server for whole geometries by `segment_id` when the stroke ends.

---

## Smaller things noticed (unconfirmed impact)

- `undoLastSegment` (approximately 1619–1633) removes the id from `selectedSegments` but does not remove it from `strokeOrderedSegmentIds`, unlike `removeSegmentSelection`. Whether this affects the survey order has not been tested.

---

## What snap-intersection-problem.md proposed vs what is in the code today

| Proposal in snap-intersection-problem.md | In today's code? | Where (approximate) |
|---|---|---|
| Lookahead commit (Approach 3) | Yes | `snapQueue`, `tryDrainSnapQueue` ~1376, `COMMIT_LAG` = 8 |
| Relaxed flush on stroke end | Yes | `flushSnapQueueRelaxed` ~1464, `COMMIT_ALIGN_RELAXED` = 0.22 |
| Client-side continuity bonus (Approach 2, Variant A) | Yes | `contMult` in `findBestCandidate` ~1310 |
| Undo last segment | Yes | `undoLastSegment` ~1619, Ctrl/Cmd+Z |
| Undo last stroke | Yes | `undoLastPaintStroke` ~1587, "Undo stroke" button |
| Click a selected block to deselect | Yes | `map.on('click', 'road-selected', …)` ~835 |
| Pending (unconfirmed) highlight | Yes | `pending` feature-state, set in `enqueuePaintSnap` ~1455 |
| Erase / unpaint brush | Yes | Unpaint mode, `eraseNearPaintPoint` ~1410 |
| Database adjacency table (Approach 2, Variant B) | No | — |
| Chaikin smoothing + re-snap after stroke (Approach 4) | No | A comment at ~898 says "no Chaikin / re-snap" |
| Retroactive revision of committed picks (Approach 1) | No | Only the distance-based prune on `pointerup` |
| Post-stroke direction sweep (Phase 3) | No | — |
| Lasso / box deselect | No | — |

The roadmap's "Refine route" handles (paint-route-editing-roadmap.md, section 4.1) are also not in today's file: no refine functions were found.
