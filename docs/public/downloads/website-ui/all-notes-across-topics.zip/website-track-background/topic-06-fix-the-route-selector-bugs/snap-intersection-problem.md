<!-- changed-box:start -->
> **What changed since this was written**
>
> This note was written around Aug 11, 2026, before the website repository was restructured on Sept 26, 2026.
>
> - `mvp_map/feedback_mvp.html` (or `feedback_mvp.html`) → `frontend/survey/index.html` (the survey, served at `/survey/`). Paint-a-route lives on the survey page, not the map page.
> - `ogc_fid` → two IDs: `segment_id` (text; a block's lasting ID; survey answers are stored against it) and `tile_id` (integer the map uses for feature-state via `promoteId`; changes every data build; never store it).
> - The `ridescoredc` table → `data.road_segment` + `data.ridescore_v1_scores`, served only through the `serving` schema: `serving.survey_segments` for the survey (street names and shapes, no score) and `serving.update_score` for the scored map. Martin publishes only `serving`.
> - Names in the code samples changed: the survey's source is `segments`, its source-layer is `survey_segments` (was `update_score_v2`), and the selection layer is still `road-selected`.
> - For what is and is not implemented today, see `route-selector-bugs-analysis.md` in the Topic 6 folder.
>
> Ideas and analysis here are still useful; names, paths and line numbers may not match today's code. Check against https://github.com/civictechdc/ridescoredc-website (develop).
<!-- changed-box:end -->

# Intersection Snap Problem — Guide to Next Steps

> Context: `mvp_map/feedback_mvp.html` — paint mode snap-to-segment

---

## Why the Problem Persists

The current implementation applies a directional penalty to candidates at the moment of each snap query. The fundamental flaw is that **the decision is made at the worst possible moment** — when the cursor is at the intersection itself, the stroke direction is ambiguous. The cursor has just arrived at the crossing point and has not yet committed to a direction. At that instant:

- Both roads are at near-equal pixel distance
- The momentum vector is pointing into the intersection, not along either road
- The penalty is therefore nearly equal for both candidates

Any approach that tries to make the correct decision *at the intersection* is fighting this ambiguity. The more productive framing is: **defer or revise the decision using information that only becomes available after the cursor has moved past the intersection.**

---

## Approach 1 — Historical Revision (Retroactive Correction)

### Concept
Don't commit a segment at snap time. Instead, maintain a **pending buffer** of recently snapped segments. When new snap data comes in, look back and ask: does the current direction of travel contradict any recent selection? If so, revise it.

### How it works

```
Stroke:  A → B → C → D  (points over time)

At C, the snap grabs a perpendicular segment (wrong road).
At D, the cursor has clearly continued straight — retroactively remove C's selection.
```

**Implementation sketch:**

```javascript
const PENDING_WINDOW = 6;  // snap events to hold before committing
let pendingSnaps = [];     // [{ featureId, props, pt, strokeIdx }]

function snapToSegments(pt) {
  // ... find nearest as before, get candidate ...
  pendingSnaps.push({ featureId, props: nearest.properties, pt, strokeIdx: paintPoints.length });

  if (pendingSnaps.length > PENDING_WINDOW) {
    revisePending();
    commitOldest();
  }
}

function revisePending() {
  if (pendingSnaps.length < 3) return;

  // Current travel direction from the last few stroke points
  const currentDir = getStrokeDirection(paintPoints, paintPoints.length - 1, 8);

  // Walk backwards through pending and flag any that are perpendicular
  // to the direction *after* they were selected
  pendingSnaps.forEach((snap, i) => {
    // Direction of stroke after this snap was made
    const dirAfter = getStrokeDirection(paintPoints, snap.strokeIdx + 4, 6);
    const segDir   = getSegmentDirection(snap);
    const alignment = Math.abs(dot(dirAfter, segDir));
    snap.suspect = alignment < 0.45;  // mark as likely wrong
  });

  // Remove suspect snaps that are flanked by non-suspect ones
  // (i.e. a wrong turn in the middle of a straight run)
}

function commitOldest() {
  const snap = pendingSnaps.shift();
  if (!snap.suspect) {
    selectedSegments.set(snap.featureId, snap.props);
    map.setFeatureState(...);
  }
}
```

**On stroke end:** flush the pending buffer — commit non-suspects, discard suspects. Then run a final retroactive pass over the whole selected set.

### Pros
- Corrects mistakes the user never notices
- No UI needed

### Cons
- Selection lags slightly behind the stroke (by PENDING_WINDOW events ~250ms)
- Edge case: intentional sharp turns get incorrectly flagged as suspect
- Needs careful tuning of the suspect threshold

---

## Approach 2 — Segment Continuity / Chain Preference

### Concept
Prefer segments that **connect to already-selected segments**. This is inspired by how graph-based routing works but without full pathfinding — just topological adjacency.

Road segments in the database share endpoints where they intersect. When a user is painting along K St and hits the Connecticut Ave intersection, the correct next segment is one whose endpoint is adjacent to the last selected K St segment. The Connecticut Ave segment's nearest endpoint is the same intersection point but it branches off at 90°.

### How it works

Each segment in the tile data has `ogc_fid`. If we can know which segments share an endpoint, we can score candidates based on whether they continue the chain.

**Two variants:**

**Variant A — Client-side adjacency heuristic (no DB query)**
At snap time, check if the candidate segment's nearest projected endpoint is within N pixels of the *last selected segment's* endpoint. If yes, boost it. This doesn't require database knowledge — it's purely geometric.

```javascript
function snapToSegments(pt) {
  // ... existing candidate loop ...

  // Additional continuity bonus
  if (lastSelectedEndpoint) {
    const endDist = Math.hypot(
      candidateStart.x - lastSelectedEndpoint.x,
      candidateStart.y - lastSelectedEndpoint.y
    );
    if (endDist < 15) score *= 0.6; // 40% score boost for connecting segments
  }
}
```

**Variant B — Database-backed adjacency (more accurate)**
Add a query to PostGIS to find topologically connected segments:
```sql
-- Segments that share an endpoint with a given ogc_fid
SELECT b.ogc_fid FROM ridescoredc a, ridescoredc b
WHERE a.ogc_fid = $1
  AND a.ogc_fid != b.ogc_fid
  AND (ST_DWithin(ST_StartPoint(a.wkb_geometry), ST_StartPoint(b.wkb_geometry), 0.00001)
    OR ST_DWithin(ST_StartPoint(a.wkb_geometry), ST_EndPoint(b.wkb_geometry), 0.00001)
    OR ST_DWithin(ST_EndPoint(a.wkb_geometry), ST_StartPoint(b.wkb_geometry), 0.00001)
    OR ST_DWithin(ST_EndPoint(a.wkb_geometry), ST_EndPoint(b.wkb_geometry), 0.00001));
```

This could be pre-computed as a graph adjacency table for performance.

### Pros
- Directly models the concept of "continuing along a road"
- Complements directional momentum rather than competing with it

### Cons
- Variant A can fail at complex intersections
- Variant B adds API complexity and latency

---

## Approach 3 — Lookahead Commit (Deferred Snapping)

### Concept
Directly inspired by vector pen tools: **don't snap to a road until you've seen enough future stroke to confirm intent.** This is the cleanest mental model and the most robust.

Think of it like a snake that follows the cursor but with a fixed lag — the snap point trails behind the actual cursor position by a fixed number of stroke events.

```
Cursor position:  ──────────────X  (current)
Committed snap:   ────────X        (N events behind)
Lookahead window:           ────X  (what we use to validate the pending snap)
```

### Implementation sketch

```javascript
const COMMIT_LAG = 8;  // stroke events to wait before committing
let snapQueue = [];    // unconfirmed candidates

function snapToSegments(pt) {
  const candidate = findNearestCandidate(pt); // as before, returns { featureId, props }
  snapQueue.push(candidate);

  if (snapQueue.length < COMMIT_LAG) return; // accumulate first

  // The candidate we're about to commit is COMMIT_LAG events old
  const toCommit = snapQueue[0];

  // Validate: what direction did the stroke go after this candidate was made?
  const afterIdx = paintPoints.length - COMMIT_LAG;
  const dirAfter = getStrokeDirection(paintPoints, afterIdx, COMMIT_LAG);
  const segDir   = getSegmentDirection(toCommit.featureId);
  const alignment = Math.abs(dot(dirAfter, segDir));

  if (alignment >= 0.4) {
    // Confirmed: stroke continued in the segment's direction
    commitSnap(toCommit);
  }
  // If not confirmed, just discard — the segment is skipped

  snapQueue.shift(); // remove from queue
}
```

**On stroke end:** flush the queue with a relaxed threshold (no future data, so fall back to momentum-at-time-of-snap).

### Pros
- Highest accuracy of all approaches
- The validation uses observed future data, not predictions
- Naturally handles sharp turns (direction change will confirm the new road)

### Cons
- Visible lag between painting and selection appearing (~400ms at 50ms throttle × 8 events)
- Flushing on stroke end needs careful handling
- Increases complexity of state management

---

## Approach 4 — Post-Stroke Geometric Smoothing

### Concept
Inspired by Illustrator's smooth tool and stabilizers in Procreate/Photoshop. After the stroke ends, fit a smoothed curve through the raw paint points and re-snap against that curve rather than the raw jittery input.

The idea: the user's *intent* is better represented by a smoothed Bezier fit through their points than by the raw sequence of mouse positions. Snap against intent, not noise.

### Implementation sketch

```javascript
paintCanvas.addEventListener('pointerup', () => {
  painting = false;
  clearSelection();  // discard all real-time snaps

  const smoothed = fitSmoothPath(paintPoints);  // returns resampled smooth points
  smoothed.forEach(pt => snapToSegments(pt));    // re-snap the clean path

  fadeStroke();
});

function fitSmoothPath(pts) {
  // 1. Resample to uniform spacing (every 8px along the stroke)
  const resampled = resampleUniform(pts, 8);
  // 2. Apply Chaikin's algorithm (2-3 passes smooths without shrinkage)
  return chaikin(chaikin(chaikin(resampled)));
}

function chaikin(pts) {
  const out = [pts[0]];
  for (let i = 0; i < pts.length - 1; i++) {
    out.push({ x: pts[i].x * 0.75 + pts[i+1].x * 0.25,
               y: pts[i].y * 0.75 + pts[i+1].y * 0.25 });
    out.push({ x: pts[i].x * 0.25 + pts[i+1].x * 0.75,
               y: pts[i].y * 0.25 + pts[i+1].y * 0.75 });
  }
  out.push(pts[pts.length - 1]);
  return out;
}
```

**Key advantage:** the smoothed path doesn't cross into the perpendicular road at all, because the wiggles that took the cursor there get smoothed away. The snap then just finds whatever road the smooth intent-line runs along.

### Pros
- Eliminates the root cause (jittery input) rather than compensating for it
- Real-time display can still show the raw stroke; the smoothing is only for snapping
- Chaikin's algorithm is 10 lines of code

### Cons
- Re-snapping after stroke ends means selection doesn't appear until lift
- Smoothing can cut corners on genuine intentional turns
- Aggressive smoothing can lose short segments

---

## Approach 5 — Manual Correction Tools

Regardless of which algorithmic approach is chosen, manual correction is essential because edge cases will always exist. The user needs a way to fix mistakes without restarting.

### Undo last segment

```javascript
let selectionHistory = [];  // ordered array of featureIds as they were added

function undoLastSegment() {
  if (!selectionHistory.length) return;
  const id = selectionHistory.pop();
  selectedSegments.delete(id);
  map.setFeatureState(
    { source: 'segments', sourceLayer: 'update_score_v2', id },
    { selected: false }
  );
  updateBadge();
}
```

Add to UI: a small **⌫ Undo** button in the controls bar (or keyboard shortcut `Z`).

### Click-to-deselect (in normal mode)

When paint mode is off, clicking an already-selected (blue) segment should deselect it:

```javascript
map.on('click', 'road-selected', (e) => {
  const id = e.features[0].id;
  if (selectedSegments.has(id)) {
    selectedSegments.delete(id);
    map.setFeatureState({ source: 'segments', sourceLayer: 'update_score_v2', id }, { selected: false });
    updateBadge();
  }
});
```

### Lasso / box deselect

Click and drag in normal mode to draw a deselection box. Any selected segments within the box get removed. More complex to implement but very useful for cleaning up cluster mistakes at intersections.

---

## Recommended Implementation Priority

### Phase 1 — Quick wins (low effort, immediate improvement)

1. **`selectionHistory` array** — enables undo. 5 lines of code.
2. **Click-to-deselect** on the `road-selected` layer. 10 lines.
3. **Post-stroke Chaikin smoothing (Approach 4)** — removes jitter before snapping. ~40 lines, no state management complexity. Best bang for effort.

### Phase 2 — Architectural improvement

4. **Lookahead commit (Approach 3)** — most accurate solution for intersection handling. Replace the real-time snap with the queued version. Acceptable lag at 8 events × 50ms = 400ms.

5. **Segment continuity bonus (Approach 2, Variant A)** — geometric endpoint adjacency, no DB queries. Combine with lookahead commit for compound benefit.

### Phase 3 — Polish

6. **Historical revision sweep on stroke end** — run a cleanup pass after lift to catch any remaining wrong selections, using the now-complete stroke geometry. Remove any selected segment whose direction contradicts the final smoothed path.

7. **Visual feedback** — show unconfirmed (pending) candidates in a lighter highlight color so the user can see what's about to be committed vs. what's firm.

---

## Combined Algorithm (target state)

The full pipeline combining the best ideas:

```
1. Pointer moves
   → Accumulate paint points
   → Update momentum (EMA direction)
   → Every 50ms: find nearest candidate using direction-penalised scoring

2. Candidate found
   → Push to snapQueue (not yet committed)
   → If queue length >= COMMIT_LAG:
       → Take oldest candidate
       → Validate against observed post-direction
       → If valid: commit (setFeatureState, add to selectedSegments + history)
       → Discard if invalid

3. Pointer up
   → Run Chaikin smoothing on raw stroke
   → Flush remaining snapQueue with relaxed threshold
   → Run post-stroke revision sweep: remove segments that contradict smoothed path
   → Fade stroke canvas

4. User correction
   → Undo button: pop selectionHistory, deselect
   → Click selected segment: deselect that segment
```

---

## Parameters to Tune

| Parameter | Current | Suggested range | Effect |
|---|---|---|---|
| `PERP_PENALTY` | 3.5 | 2.5 – 5.0 | Higher = harder to grab cross streets |
| `SNAP_RADIUS` | 40px | 25 – 50px | Smaller = more precise, misses thin roads |
| `MOMENTUM_SMOOTH` | 0.25 | 0.1 – 0.4 | Lower = direction changes more slowly |
| `MIN_MOVE` | 12px | 8 – 20px | Distance before direction filtering activates |
| `COMMIT_LAG` | — | 6 – 12 events | Higher = more lookahead, more lag |
| Chaikin passes | — | 2 – 4 | More = smoother, more corner-cutting |

All of these interact. Recommend tuning them with a fixed test route (e.g., K St → Connecticut Ave intersection) to evaluate each change in isolation.
