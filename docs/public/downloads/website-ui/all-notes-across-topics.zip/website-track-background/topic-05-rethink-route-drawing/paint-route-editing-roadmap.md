<!-- changed-box:start -->
> **What changed since this was written**
>
> This note was written around Aug 11, 2026, before the website repository was restructured on Sept 26, 2026.
>
> - `mvp_map/feedback_mvp.html` (or `feedback_mvp.html`) → `frontend/survey/index.html` (the survey, served at `/survey/`). Paint-a-route lives on the survey page, not the map page.
> - `ogc_fid` → two IDs: `segment_id` (text; a block's lasting ID; survey answers are stored against it) and `tile_id` (integer the map uses for feature-state via `promoteId`; changes every data build; never store it).
> - The `references/route_snapper` folder is not included in this pack. route_snapper is public at https://github.com/dabreegster/route_snapper
> - Section 4.1 (Refine route handles) describes code that is not in today's `frontend/survey/index.html`: no refine functions were found there.
> - Links to other `docs-4-ai/...` notes: those notes are in this pack's topic folders. `infrastructure-overview.md` is not included; the guide pages replace it.
>
> Ideas and analysis here are still useful; names, paths and line numbers may not match today's code. Check against https://github.com/civictechdc/ridescoredc-website (develop).
<!-- changed-box:end -->

# Paint route — editing scope & borrowed ideas

> **Goal:** Bring **route_snapper–style** correction UX into RideScore: **draggable junctions** (waypoints) that **snap to the road network** so users can fix small mistakes without repainting.  
> **Context:** `mvp_map/feedback_mvp.html` (segment `ogc_fid` selection) · `references/route_snapper` · `docs-4-ai/route-snapper-audit-and-ridescore-recommendations.md`

---

## 1. What we are scoping (in product scope)

### 1.1 “Draggable junction” editing — user story

After painting (or anytime a route exists), the user can:

1. See **handles** at key points along their route (junctions / decision points, not necessarily every segment vertex).
2. **Drag** a handle; while dragging, a **preview** shows the adjusted path or segment set **snapped** to nearby roads (same visual language as paint: blue highlight).
3. **Release** to commit: selection updates to match the corrected path (add/remove `ogc_fid` as needed).
4. Optional: **Shift** or tool toggle for a **free point** that does not snap (route_snapper’s snapped vs freehand split).

This directly addresses “small corrections” without clearing the route or relying only on undo / per-segment click-off.

### 1.2 Why this matches route_snapper well

| route_snapper concept | RideScore adaptation |
|----------------------|------------------------|
| Waypoints `Snapped(NodeID)` / `Free` | Handles = **lng/lat** (or screen) snapped to **nearest graph node** or **nearest point on MVT edge** |
| Shortest path between waypoints | Either **client graph** (`snap.bin`) **or** simplified **polyline-resnap**: re-run path between handles using same `findBestCandidate` + continuity along **ordered** handle chain |
| `Dragging` / `Hovering` modes | MapLibre **symbol/circle** layer or HTML overlay; map `dragPan` off while dragging handle |
| `renderGeojson` preview | GeoJSON `LineString` + `Point` features in a `route-edit` source, or canvas overlay |
| `editExistingRoute` | Seed handles from **current selection**: e.g. ordered segment chain endpoints, or Douglas–Peucker simplification of union centroid line |

**Minimum viable edit UX (without WASM):**  
Build an ordered **polyline through selected segments** (or through stroke sample), place **K handles** (e.g. every Nth vertex or at high-curvature points). On handle drag end, **re-snap** the sub-strokes between consecutive handles using existing tile query + momentum disabled in favor of **local chord direction** between handles. Recompute **union of segments** along each sub-chain. No full graph required; quality depends on intersection density.

**Stronger edit UX (with graph / WASM):**  
Embed **route_snapper** (or DC GeoJSON → `snap.bin`) so drag truly **re-routes** between handles; then **map path edges → `ogc_fid`** (pre-tagged edges or PostGIS `ST_DWithin` once on finish).

---

## 2. Implementation tracks (pick one primary)

### Track A — “Lightweight handles” (no `snap.bin`, stays in `feedback_mvp`)

- **Data:** `selectedSegments` + optional `orderedRoute: ogc_fid[]` built at paint end (order along stroke or along graph walk if you add adjacency later).
- **Handles:** Derived from resampled line along **union of segment geometries** (querySourceFeatures) or from **saved paintPoints** last stroke.
- **Drag:** On drop, update one handle position → **replace** segment IDs on affected index range only (local re-query).
- **Pros:** Single HTML stack, no Rust pipeline.  
- **Cons:** Intersections still heuristic between two handles unless you add **continuity + shortest partial path** heuristics.

### Track B — **Embed route_snapper** for edit mode only

- **Paint** stays as today for initial capture.
- **“Refine route”** loads WASM + `snap.bin` (DC clip); `editExistingRoute` with polyline from current selection (needs waypoint reconstruction or two-endpoint seed + `split` logic).
- **Output:** Path → segment IDs via **buffer + query** or **edge metadata** in graph file.
- **Pros:** Best snapping / junction behavior, proven UX.  
- **Cons:** Build pipeline, bundle size, dual sources of truth (tiles vs graph) unless graph is generated from same DB export.

### Track C — **Server-side reroute**

- POST waypoints → PostGIS **pgrouting** (or simple “snap each leg to nearest segment chain”) → return `ogc_fid[]`.
- **Pros:** Thin client.  
- **Cons:** Latency, offline story.

**Recommendation:** Ship **Track A** for a first “edit with handles” iteration; plan **Track B** if intersection quality on edits is still insufficient.

---

## 3. Other ideas to bring in (beyond draggable junctions)

Ideas are ordered roughly by **impact / effort** for RideScore MVP.

### From route_snapper (behavior & API)

| Idea | Application |
|------|-------------|
| **Snap / free toggle** (`S` key, shift+click) | Let users pin a handle off-street (construction, trail) then snap the next leg back to grid. |
| **`avoid_doubling_back` style penalty** | When re-snapping between handles, down-rank edges already in `selectedSegments` unless handle forces a loop. |
| **Double-click to finish / Enter / Esc** | Consistent with reference: finish edit session, cancel without applying preview. |
| **`splitRoute` semantics** | “Split route here” at a click → two survey groups or two selection buckets (future multi-leg feedback). |
| **Preview `snapped: false` legs** | Style unsnapped preview segments differently (dashed) until user confirms. |
| **`undo_length` in UI** | Mirror deep undo stack during edit mode (you already have segment undo globally). |

### From earlier RideScore / snap-intersection notes

| Idea | Application |
|------|-------------|
| **Erase brush** (Alt + paint) | Remove segments the stroke crosses — fast cleanup without handle surgery. |
| **Lasso / box subtract** | Drag rectangle in browse mode; remove all selected segments intersecting box. |
| **“Undo last stroke”** | Pop all IDs added in last `pointerdown`…`pointerup` (requires per-stroke id sets — related to `idsTouchedThisStroke`). |
| **Survey-time strip** | Before submit, list segments with remove checkbox (low engineering, high clarity). |
| **Soft warning on disjoint extend** | If new paint’s first commits are far from existing selection, toast: “Connecting a new area?” |

### From map UX polish

| Idea | Application |
|------|-------------|
| **Handle hit slop** | 12–16px circle pick tolerance on handles (route_snapper uses pixel-derived meters for node snap). |
| **Keyboard nudge** | Arrow keys move focused handle 1m (accessibility). |
| **Magnetism** | While dragging near a strong candidate intersection, slight pull (hysteresis) to reduce jitter. |

---

## 4. Engineering checklist (when implementing handles)

- [ ] **Ordering:** Selection is a `Set` today; editing needs **ordered chain** of segments or a stored **reference polyline** (last stroke or merged geometry).
- [ ] **Layers:** Dedicated `route-handles` + `route-edit-preview` MapLibre sources so paint canvas and handles don’t fight pointer capture.
- [ ] **State machine:** `idle | painting | editing | editing-drag` — only one consumes pointer events.
- [ ] **Commit rules:** Apply preview to `selectedSegments` on **explicit** confirm (button or Enter) vs on every drag end — reduces flicker; route_snapper leans continuous redraw + finish.
- [ ] **Performance:** Throttle drag re-queries; debounce heavy `querySourceFeatures`.
- [ ] **Mobile:** Touch targets for handles ≥ 44px.

---

## 4.1 Refine route — logic audit (implemented in `feedback_mvp.html`)

**Problem (prior behavior):** `snapLngLatToRoad` used the **screen midpoint** of the nearest MVT sub-segment, so orange pins sat visually **between** corners and did not match “drag at intersection ends” mental model. Preview `LineString`s could look messy when consecutive handles collapsed to the same screen location after snap.

**Current behavior:**

| Piece | Logic |
|--------|--------|
| **Candidate geometry** | `findBestCandidate` now attaches **`vertexLLA` / `vertexLLB`** (lng/lat endpoints of the winning edge) alongside the existing pixel `edge`. |
| **Primary drag** | Active handle uses **`snapRefineHandleToRoadVertex`**: nearer of the two segment endpoints in **screen distance** → locks to intersection / block end. |
| **Initial placement & pull-followers** | Uses **`snapRefineHandleClosestOnBestEdge`**: closest point along that same edge (perpendicular in screen space, then `unproject`) so handles along long straights stay on the **same** centerline instead of jumping to unrelated intersections. |
| **Broad drag (route_snapper-inspired)** | Moving handle `i` applies a **weighted Δ** to indices `i±1` and `i±2` (`REFINE_PULL_WEIGHTS`), then re-snaps followers with **closest-on-edge restricted to `selectedSegments` IDs only**. Unrestricted snap caused a **four-corners / runaway-handle** bug at crossings: each follower jumped to a different approach leg. Primary handle still uses **global** vertex snap so you can attach to a new road. |
| **Rebuild stability** | Corners closer than **~24 m** along the chain still merge. **No even index cap** (it resampled handles globally and spawned dots on untouched straightaways). After live commit, **reproject existing handles** onto the new stitched chain when the number of continuous chains matches; only on split/merge do we run a full `placeHandlesForChain` rebuild. |
| **Chord sampling (`collectIdsAlongHandlePath`)** | **Isotropic** snap (no chord-only direction bias). **Hysteresis:** along each leg, prefer the **previous segment** unless another candidate is **~22 px** closer in screen space — otherwise dense samples at every intersection flip between arms and **every branch** joins the selection. Coarser spacing (~10 m, max 48 steps/leg) reduces node spam. |
| **Preview line** | MapLibre **`line-cap` / `line-join`: `round`**, slightly adjusted dash array, opacity below 1. **`syncRefinePreviewLine`** drops consecutive coordinates closer than **0.25 m** to avoid degenerate segments and dash artifacts. |
| **Mouse up** | **`dedupeNearIdenticalRefineHandles`** removes consecutive near-duplicate handles after a gesture. |

**Live commit (no Enter):** While dragging, **`scheduleRefineLiveCommit`** (rAF) reapplies **`collectIdsAlongHandlePath` → `replaceEntireSelection`** so the blue selection tracks the dashed handle polyline in real time. **Pointer release** flushes any pending rAF, optionally pushes a snapshot onto **`refineUndoStack`**, then **rebuilds** orange handles from the new segment order. **Esc** still calls **`exitRefineMode(true)`** to restore the snapshot from when refine was opened. **Toggling Refine off** calls **`exitRefineMode(false)`** and keeps the current selection. **Undo last refine** / **Ctrl+Z** (when the refine undo stack is non-empty) pops one step.

**Still different from route_snapper:** dragging a **graph node** there recomputes the entire snapped route through the transport network. Here we only **re-sample segments** along straight chords between handles (`collectIdsAlongHandlePath`). Embedding the WASM tool remains the path to identical semantics.

---

## 5. Doc cross-links

- **Route snapper deep dive & tiers:** `docs-4-ai/route-snapper-audit-and-ridescore-recommendations.md`  
- **Intersection heuristics (paint):** `docs-4-ai/snap-intersection-problem.md`  
- **Product criteria (paint):** `docs-4-ai/paint-concept-notes.md`

---

*This document is the working scope for “editable routes with draggable junctions” and related corrections; update it as implementation choices land.*
