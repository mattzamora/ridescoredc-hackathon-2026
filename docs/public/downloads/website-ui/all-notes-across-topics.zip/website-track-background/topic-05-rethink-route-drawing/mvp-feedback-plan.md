<!-- changed-box:start -->
> **What changed since this was written**
>
> This note was written around Aug 11, 2026, before the website repository was restructured on Sept 26, 2026.
>
> - `mvp_map/index.html` → `frontend/index.html` (the map, served at `/`). Code both pages share (base map, tile addresses, crash layer) is now in `frontend/src/shared/`.
> - `mvp_map/feedback_mvp.html` (or `feedback_mvp.html`) → `frontend/survey/index.html` (the survey, served at `/survey/`). Paint-a-route lives on the survey page, not the map page.
> - `ogc_fid` → two IDs: `segment_id` (text; a block's lasting ID; survey answers are stored against it) and `tile_id` (integer the map uses for feature-state via `promoteId`; changes every data build; never store it).
> - The `ridescoredc` table → `data.road_segment` + `data.ridescore_v1_scores`, served only through the `serving` schema: `serving.survey_segments` for the survey (street names and shapes, no score) and `serving.update_score` for the scored map. Martin publishes only `serving`.
> - Martin at `http://localhost:3000` → tiles are requested at `/tiles/...` on the page's own address: nginx on `localhost:8000` in the Full Stack setup, or proxied by Vite on `localhost:5173` in the Front-End setup.
> - The `references/nearmiss` folder is not included in this pack.
>
> Ideas and analysis here are still useful; names, paths and line numbers may not match today's code. Check against https://github.com/civictechdc/ridescoredc-website (develop).
<!-- changed-box:end -->

# MVP Feedback Mechanism — Intentions & Build Plan

> Built on: `mvp_map/index.html` + existing PostGIS road segments data

---

## Restated Intention

Allow cyclists to trace the route they rode directly on the RideScoreDC map by painting over road segments with a finger or mouse. The painted stroke snaps to the nearest road segments in real time, highlighting them blue. Once the route is painted, the user completes a short survey rating their experience on those specific segments. The submission is associated with the specific `ogc_fid` segment IDs from the PostGIS database.

**Core UX flow:**
```
Tap "Paint Route"
   → drag finger/mouse along roads
   → segments snap + highlight blue as you paint
   → lift finger → stroke fades
   → "Rate X segments" button appears
   → survey panel opens
   → submit → segments + answers recorded
```

**Out of scope for this phase:** graph-based routing, per-segment individual questions, offline persistence of selection state.

---

## What Already Exists

| Asset | Status | Notes |
|---|---|---|
| Road segments in PostGIS | Ready | 13,834 segments with `ogc_fid`, scores, geometry |
| Martin tile server | Running on `:3000` | Serves `update_score` MVT |
| `update_score` SQL function | Needs 1 change | Must add `ogc_fid` to SELECT |
| MapLibre GL map | Running | `mvp_map/index.html` |
| Survey pattern | Reference only | `references/nearmiss` |

---

## MVP Build Plan

### Step 1 — Add `ogc_fid` to the tile data (SQL)

The `update_score` function currently does not expose `ogc_fid` in its output, so features have no stable ID for `feature-state`. One change to the function:

```sql
-- In the SELECT inside public.update_score:
SELECT
  ST_AsMVTGeom(...) AS geom,
  ogc_fid,           -- ADD THIS
  (ridescore_v1 * ...) AS user_score,
  route_name,
  bike_facility_type,
  ...
FROM ridescoredc
```

Also update the `addSource` call in `index.html` to promote `ogc_fid` as the feature ID:

```javascript
map.addSource('my-vector-source', {
  type: 'vector',
  tiles: ["http://localhost:3000/update_score/{z}/{x}/{y}?..."],
  promoteId: { 'update_score': 'ogc_fid' },   // ADD THIS
  minzoom: 1,
  maxzoom: 14
});
```

---

### Step 2 — Add a selection highlight layer

After the existing `update_score` line layer, add a second layer that renders selected segments blue:

```javascript
map.addLayer({
  id: 'update_score_selected',
  type: 'line',
  source: 'my-vector-source',
  'source-layer': 'update_score',
  paint: {
    'line-color': '#0066FF',
    'line-width': 6,
    'line-opacity': ['case',
      ['boolean', ['feature-state', 'selected'], false], 1, 0
    ]
  }
});
```

This sits on top of the existing score gradient layer. Only segments with `feature-state.selected = true` are visible on it.

---

### Step 3 — Paint mode UI

Add to the controls bar (top-left) alongside the existing Settings/Imagery/Accidents buttons:

```html
<button class="ctrl-btn toggle-btn" id="paintBtn" onclick="togglePaintMode()">
  Paint Route
</button>
```

Add a canvas overlay that sits above the MapLibre canvas:

```html
<canvas id="paint-canvas"
  style="position:fixed;top:0;left:0;width:100%;height:100%;
         pointer-events:none;z-index:500;touch-action:none">
</canvas>
```

`pointer-events:none` by default — paint mode switches it to `all`.

---

### Step 4 — Paint mode logic

```javascript
let paintMode = false
let painting = false
let paintPoints = []           // screen pixel coords of stroke
let selectedSegments = new Map() // ogc_fid → feature properties

function togglePaintMode() {
  paintMode = !paintMode
  document.getElementById('paintBtn').classList.toggle('active', paintMode)
  const canvas = document.getElementById('paint-canvas')
  canvas.style.pointerEvents = paintMode ? 'all' : 'none'

  // Disable map interaction in paint mode
  if (paintMode) {
    map.dragPan.disable()
    map.scrollZoom.disable()
    map.doubleClickZoom.disable()
    map.touchZoomRotate.disable()
  } else {
    map.dragPan.enable()
    map.scrollZoom.enable()
    map.doubleClickZoom.enable()
    map.touchZoomRotate.enable()
  }
}
```

---

### Step 5 — Stroke drawing + snap-to-segment

```javascript
const paintCanvas = document.getElementById('paint-canvas')
const ctx = paintCanvas.getContext('2d')
let snapThrottle = null

paintCanvas.addEventListener('pointerdown', (e) => {
  painting = true
  paintPoints = [{ x: e.clientX, y: e.clientY }]
  paintCanvas.setPointerCapture(e.pointerId)
})

paintCanvas.addEventListener('pointermove', (e) => {
  if (!painting) return
  const pt = { x: e.clientX, y: e.clientY }
  paintPoints.push(pt)
  drawStroke(paintPoints)

  // Throttle snap queries to ~50ms
  if (!snapThrottle) {
    snapThrottle = setTimeout(() => {
      snapToSegments(pt)
      snapThrottle = null
    }, 50)
  }
})

paintCanvas.addEventListener('pointerup', () => {
  painting = false
  fadeStroke()   // fade canvas out over 400ms
  updateFeedbackButton()
})

function drawStroke(points) {
  ctx.clearRect(0, 0, paintCanvas.width, paintCanvas.height)
  ctx.strokeStyle = 'rgba(0, 102, 255, 0.6)'
  ctx.lineWidth = 4
  ctx.lineJoin = 'round'
  ctx.lineCap = 'round'
  ctx.beginPath()
  ctx.moveTo(points[0].x, points[0].y)
  points.slice(1).forEach(p => ctx.lineTo(p.x, p.y))
  ctx.stroke()
}

function fadeStroke() {
  let opacity = 0.6
  const fade = setInterval(() => {
    opacity -= 0.05
    if (opacity <= 0) { clearInterval(fade); ctx.clearRect(0, 0, paintCanvas.width, paintCanvas.height); return }
    ctx.globalAlpha = opacity
    drawStroke(paintPoints)
    ctx.globalAlpha = 1
  }, 30)
}

function snapToSegments(screenPt) {
  // Query a 40px bounding box around the paint point
  const bbox = [
    [screenPt.x - 40, screenPt.y - 40],
    [screenPt.x + 40, screenPt.y + 40]
  ]
  const features = map.queryRenderedFeatures(bbox, { layers: ['update_score'] })
  if (!features.length) return

  // Find nearest segment by pixel distance
  let nearest = null
  let minDist = Infinity
  features.forEach(f => {
    const coords = f.geometry.coordinates
    coords.forEach(coord => {
      const px = map.project(coord)
      const dist = Math.hypot(px.x - screenPt.x, px.y - screenPt.y)
      if (dist < minDist) { minDist = dist; nearest = f }
    })
  })

  if (nearest && !selectedSegments.has(nearest.properties.ogc_fid)) {
    const id = nearest.properties.ogc_fid
    selectedSegments.set(id, nearest.properties)
    map.setFeatureState(
      { source: 'my-vector-source', sourceLayer: 'update_score', id },
      { selected: true }
    )
    updateSelectionBadge()
  }
}
```

---

### Step 6 — Selection badge + clear button

```html
<div id="selection-badge"
  style="display:none;position:fixed;bottom:24px;left:50%;transform:translateX(-50%);
         background:#0066FF;color:#fff;border-radius:999px;padding:10px 20px;
         font:600 13px Inter,sans-serif;z-index:900;display:flex;gap:12px;align-items:center">
  <span id="badge-count">0 segments selected</span>
  <button onclick="clearSelection()"
    style="background:rgba(255,255,255,0.2);border:none;color:#fff;
           border-radius:4px;padding:4px 10px;cursor:pointer;font:inherit">
    Clear
  </button>
  <button id="rate-btn" onclick="openSurveyPanel()"
    style="background:#fff;color:#0066FF;border:none;
           border-radius:4px;padding:4px 10px;cursor:pointer;font:600 inherit">
    Rate segments →
  </button>
</div>
```

```javascript
function updateSelectionBadge() {
  const n = selectedSegments.size
  const badge = document.getElementById('selection-badge')
  badge.style.display = n > 0 ? 'flex' : 'none'
  document.getElementById('badge-count').textContent = `${n} segment${n !== 1 ? 's' : ''} selected`
}

function clearSelection() {
  selectedSegments.forEach((_, id) => {
    map.setFeatureState(
      { source: 'my-vector-source', sourceLayer: 'update_score', id },
      { selected: false }
    )
  })
  selectedSegments.clear()
  updateSelectionBadge()
}
```

---

### Step 7 — Survey panel (MVP: hardcoded HTML)

For the demo, a simple panel — no framework needed. Replace with a JSON-driven engine (nearmiss pattern) in a later iteration.

```html
<div id="survey-panel"
  style="display:none;position:fixed;right:0;top:0;bottom:0;width:340px;
         background:#fff;z-index:1000;box-shadow:-4px 0 20px rgba(0,0,0,.15);
         padding:24px;overflow-y:auto;font-family:Inter,sans-serif">

  <div style="font:600 15px/1 Inter;margin-bottom:20px">
    Route Feedback
    <button onclick="closeSurveyPanel()"
      style="float:right;background:none;border:none;cursor:pointer;font-size:18px">×</button>
  </div>

  <form id="feedback-form">

    <label style="display:block;font:500 12px Inter;margin-bottom:8px">
      Overall, how safe did this route feel?
    </label>
    <div style="display:flex;gap:8px;margin-bottom:20px">
      ${[1,2,3,4,5].map(n =>
        `<label style="flex:1;text-align:center">
          <input type="radio" name="safety_rating" value="${n}" required style="display:block;margin:0 auto 4px">
          ${n}
        </label>`
      ).join('')}
    </div>
    <div style="display:flex;justify-content:space-between;font:11px Inter;color:#64748b;margin-top:-16px;margin-bottom:20px">
      <span>Very unsafe</span><span>Very safe</span>
    </div>

    <label style="display:block;font:500 12px Inter;margin-bottom:8px">
      What made it feel that way? (check all that apply)
    </label>
    <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:20px">
      ${['Traffic speed','Number of lanes','No bike lane','Road surface','Parked cars','Intersections']
        .map(opt => `<label style="font:12px Inter;display:flex;gap:8px;align-items:center">
          <input type="checkbox" name="factors" value="${opt}"> ${opt}
        </label>`).join('')}
    </div>

    <label style="display:block;font:500 12px Inter;margin-bottom:8px">
      Any other comments?
    </label>
    <textarea name="comments" maxlength="500" rows="4"
      style="width:100%;border:1px solid #e2e8f0;border-radius:6px;
             padding:8px;font:12px Inter;resize:none;margin-bottom:20px"></textarea>

    <button type="submit"
      style="width:100%;padding:12px;background:#1a1a2e;color:#fff;border:none;
             border-radius:6px;font:600 13px Inter;cursor:pointer">
      Submit Feedback
    </button>
  </form>
</div>
```

```javascript
function openSurveyPanel() {
  document.getElementById('survey-panel').style.display = 'block'
}

function closeSurveyPanel() {
  document.getElementById('survey-panel').style.display = 'none'
}

document.getElementById('feedback-form').addEventListener('submit', (e) => {
  e.preventDefault()
  const form = new FormData(e.target)
  const payload = {
    segments: [...selectedSegments.keys()],
    safety_rating: form.get('safety_rating'),
    factors: form.getAll('factors'),
    comments: form.get('comments'),
    timestamp: new Date().toISOString()
  }
  console.log('Feedback payload:', payload)
  // TODO: POST to backend
  alert(`Feedback submitted for ${payload.segments.length} segments. Thank you!`)
  closeSurveyPanel()
  clearSelection()
  togglePaintMode()
})
```

---

## Demo Checklist

- [ ] **Step 1** — Edit `public.update_score` SQL to add `ogc_fid` to SELECT; `docker exec` to apply
- [ ] **Step 2** — Add `promoteId` to `addSource` in `index.html`
- [ ] **Step 3** — Add selection highlight layer (`update_score_selected`)
- [ ] **Step 4** — Add Paint Route button to controls bar
- [ ] **Step 5** — Add `<canvas id="paint-canvas">` overlay
- [ ] **Step 6** — Add paint mode JS (toggle, pointer events, stroke drawing)
- [ ] **Step 7** — Add snap-to-segment logic (`queryRenderedFeatures` + `setFeatureState`)
- [ ] **Step 8** — Add selection badge + Clear button
- [ ] **Step 9** — Add survey panel HTML
- [ ] **Step 10** — Wire submit handler, log payload to console

**Demo is complete when:** a user can paint over streets, see them turn blue, tap "Rate segments", fill in the form, and see the payload logged with the correct `ogc_fid` array.

---

## Next Steps After Demo

1. Replace hardcoded survey HTML with a JSON-driven schema (nearmiss pattern)
2. Build a backend endpoint to receive and store feedback
3. Visualize aggregate feedback on the map as a second score layer
4. Add `route_id` grouping so whole named routes can be selected in one tap
