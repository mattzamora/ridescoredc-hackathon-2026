<!-- changed-box:start -->
> **What changed since this was written**
>
> This note was written around Aug 11, 2026, before the website repository was restructured on Sept 26, 2026.
>
> - `mvp_map/feedback_mvp.html` (or `feedback_mvp.html`) → `frontend/survey/index.html` (the survey, served at `/survey/`). Paint-a-route lives on the survey page, not the map page.
> - `ogc_fid` → two IDs: `segment_id` (text; a block's lasting ID; survey answers are stored against it) and `tile_id` (integer the map uses for feature-state via `promoteId`; changes every data build; never store it).
> - The `ridescoredc` table → `data.road_segment` + `data.ridescore_v1_scores`, served only through the `serving` schema: `serving.survey_segments` for the survey (street names and shapes, no score) and `serving.update_score` for the scored map. Martin publishes only `serving`.
> - The `references/route_snapper` folder is not included in this pack. route_snapper is public at https://github.com/dabreegster/route_snapper
> - Links to other `docs-4-ai/...` notes: those notes are in this pack's topic folders. `infrastructure-overview.md` is not included; the guide pages replace it.
>
> Ideas and analysis here are still useful; names, paths and line numbers may not match today's code. Check against https://github.com/civictechdc/ridescoredc-website (develop).
<!-- changed-box:end -->

# Route snapper reference — audit & RideScore DC map recommendations

> Reference: `references/route_snapper` (MapLibre route snapper from the A-B Street ecosystem)  
> Current app: `mvp_map/feedback_mvp.html` — paint-to-segment selection with Martin vector tiles

---

## 1. What route_snapper is

**route_snapper** is a **MapLibre-oriented** tool for drawing **routes** (or **polygons** in “area mode”) that **snap to a precomputed street network graph** in the browser. Routing is **client-side** via **Rust → WebAssembly**; there is **no** server round-trip per drag.

High-level pipeline:

1. **Offline**: Build a compact binary graph (`snap.bin`) from **OpenStreetMap** (`osm-to-route-snapper`) or from **GeoJSON LineStrings** (`geojson-to-route-snapper`) that share vertices (see connectivity rules below).
2. **Runtime**: Load `snap.bin` in the page, construct `RouteSnapper` (JS wrapper) or `RouteTool` (TypeScript), wire MapLibre events.
3. **Interaction**: User places **waypoints** (snapped to graph **nodes** or **freehand** with shift+click). The tool computes **shortest paths** along directed edges between consecutive waypoints and renders preview + final GeoJSON.

Authoritative docs in-repo: `references/route_snapper/README.md`, `references/route_snapper/user_guide.md`, `references/route_snapper/route-snapper/README.md` (pointer to user guide).

---

## 2. Technical architecture (reference)

### 2.1 Graph model (`route-snapper-graph`)

- **`RouteSnapperMap`**: `nodes` (coordinates) + `edges` (each edge: `node1`, `node2`, `geometry` as `LineString`, optional `name`).
- **Directed routing**: Each undirected edge becomes **two** directed arcs in a `petgraph::graphmap::DiGraphMap` with per-direction **cost** (`forward_cost` / `backward_cost`).
- **Costs**: If override vectors are empty, cost defaults to **`length_meters`** (geodesic length along geometry). Overrides can set `null` to forbid a direction entirely (one-way, no access).
- **Serialization**: Custom bincode layout; coordinates quantized for size.

This is a **true network graph** suitable for Dijkstra / similar shortest-path queries.

### 2.2 WASM core (`route-snapper/src/lib.rs`)

- **`JsRouteSnapper`**: holds `Router` (map + graph + config), **`RTree`** over node positions for **nearest-node** queries under the cursor (screen-space radius derived from a pixel distance in TS: ~30px → meters at current zoom).
- **State machine**: modes such as `Neutral`, `Hovering(Waypoint)`, `Dragging`, `Freehand` — routes are **waypoint-driven**, not “every mouse move picks an edge.”
- **`Route`**: `waypoints: Vec<Waypoint>` (`Snapped(NodeID)` | `Free(Coord)`) and derived **`full_path`** (`PathEntry` including traversed directed edges).
- **Undo**: stack of waypoint snapshots (`MAX_PREVIOUS_STATES = 100`).
- **`renderGeojson`**: returns FeatureCollection for current preview, with properties like `snapped` on lines, `type` on points (`snapped-waypoint`, `free-waypoint`, `node`), optional `name`, `cursor`, `snap_mode`, `undo_length`.

### 2.3 TypeScript wrapper (`route-snapper-ts/src/index.ts`)

- **`RouteTool`**: binds MapLibre `mousemove` / `click` / `dblclick` / drag / key handlers.
- **`snapDistancePixels = 30`**: converts to meters at cursor for WASM `onMouseMove`.
- **Keys**: `Enter` finish, `Escape` cancel, `Ctrl+Z` undo, **`S`** toggles snap mode.
- **`split.ts`**: `splitRoute` splits a finished LineString at a point and **rebuilds waypoint metadata** (documented edge cases for snapped vs free splits).

### 2.4 Tooling

- **OSM import**: browser `import.html` or CLI with optional boundary GeoJSON clip.
- **GeoJSON import**: LineStrings must **topologically connect** — “If LineStrings cross but don’t share points (within 7 decimal places) they won’t connect.”
- **Examples**: `examples/index.html`, `examples/serve_locally.sh`.

---

## 3. How this differs from `feedback_mvp.html` paint snapping

| Dimension | **route_snapper** | **feedback_mvp (current)** |
|-----------|-------------------|-----------------------------|
| **Geometry source** | Fixed `snap.bin` graph (OSM or custom GeoJSON) | **Martin MVT** `queryRenderedFeatures` + `querySourceFeatures` |
| **Snap target** | **Graph nodes** (intersections / endpoints), then **shortest path** between waypoints | **Nearest screen-space point on any rendered edge** in radius |
| **Ambiguity at crossings** | Reduced: user picks **nodes** or sparse waypoints; path is **computed**, not per-sample | Mitigated with **lookahead queue**, momentum, continuity bonus, scoped prune — still heuristic |
| **Output** | Single **connected** `LineString` (+ `waypoints`, `length_meters`) | **Set of segment IDs** (`ogc_fid`) for survey |
| **Costs / preferences** | First-class: per-edge forward/back cost (length or custom) | Implicit: user “paints” segments; score is **display** on tiles, not routing cost |
| **Build / deploy** | Rust + wasm-pack, graph build step, NPM or CDN bundle | Single HTML, no WASM |
| **Area coverage** | Must predefine graph extent | Tiles load by viewport + zoom |

**Bottom line:** route_snapper optimizes **paths on a known graph**; RideScore MVP accumulates **features near a stroke** on **server-rendered tiles**. They solve related but not identical problems.

---

## 4. Strengths of route_snapper (ideas worth borrowing)

1. **Waypoint + shortest path** — Dramatically fewer “wrong road at intersection” issues than dense per-point nearest-edge selection, because the route between two intentional clicks is **globally** chosen on the graph (subject to costs).

2. **Explicit snapped vs freehand** — `Waypoint::Snapped` vs `Free`, `toggleSnapMode`, shift+click semantics — good pattern for “I really mean this off-grid point.”

3. **Per-edge directed costs** — Natural fit for **LTS**, **one-way**, **user_score as impedance** (e.g. `cost = length / f(score)`), or “avoid LTS 4 except when user forces.”

4. **`avoid_doubling_back`** — Optional penalty on reusing edges when routing between intermediate waypoints; useful for long routes without spaghetti.

5. **`extend_route` vs fixed endpoints** — Clear UX modes: two-click route vs keep extending.

6. **`editExistingRoute` + waypoint preservation** — Re-open a route for adjustment without redrawing from scratch.

7. **`splitRoute`** — Post-processing pattern for splitting one route into two survey-able legs while fixing `waypoints` / lengths.

8. **Rich preview GeoJSON** — `snapped` flags, cursor hints, undo depth — good for transparent UX and debugging.

9. **Client-only routing** — After graph load, no latency per interaction; privacy-friendly.

10. **Documented caveats** (user guide “Routing caveats”) — Defaults can include tram, construction, etc., and may ignore real-world one-way; **honest** about needing custom GeoJSON costs for end-user navigation vs planning sketches.

---

## 5. Limitations & risks for RideScore DC

1. **Graph build & freshness** — You must maintain a **pipeline** from `ridescoredc` (or OSM clip) → GeoJSON/node topology → `snap.bin`. Tile pipeline (Martin/SQL) and snap graph pipeline can **diverge** if not versioned together.

2. **Topology quality** — DC centerlines must **share vertices** at intersections like the GeoJSON importer expects; messy GIS topology → broken or missing connections (same class of issues as any graph router).

3. **Node-centric snapping** — Users snap to **junctions**, not arbitrary points along a long block. That can feel different from “draw along the road centerline” paint UX (mitigated by dense nodes if geometry is split finely).

4. **Bundle & init** — WASM deserialize + RTree setup has a one-time cost (`RouteTool` logs “Deserialize and setup JsRouteSnapper”); acceptable for a dedicated tool, heavier than zero-dependency HTML.

5. **MapLibre event coordination** — Requires `boxZoom: false`, `doubleClickZoom` disabled while drawing (documented); must coexist with paint canvas, survey panel, etc.

6. **Output mismatch** — Snapper output is a **polyline**; MVP needs **segment ID set**. Mapping path → `ogc_fid` hits requires **spatial join** (path buffer ∩ segment layer) or embedding edge IDs in the graph at build time from your segment table.

7. **Default OSM costs ≠ safety** — For “where I rode,” you’d want **custom costs from RideScore fields**, not raw OSM defaults.

---

## 6. Recommendations for RideScore (prioritized)

### Tier A — High value, incremental (no full WASM adoption)

1. **Waypoint-assisted “route confirm” mode** (inspired by snapper, implementable in current stack): After a rough paint stroke, simplify stroke to **K polyline vertices**, then for each consecutive pair run a **short path** on a **client-side lightweight graph** built from **visible tile features** or a **small GeoJSON** chunk for bbox only. Select union of edges along that path. *Challenge:* graph from MVT is incomplete at tile boundaries; mitigations: prefetch bbox graph from API, or only run short-path **within viewport graph** built once per session.

2. **Borrow UX patterns only**: **Enter** to finish stroke, **Esc** to cancel current stroke without clearing whole selection, **S**-style toggle between “strict snap” and “loose” (maps to your momentum / lookahead params), visible **undo depth** (you already have undo).

3. **`avoid_doubling_back` analogue** — When extending selection, lightly penalize edges already in `selectedSegments` in `findBestCandidate` scoring so loops need deliberate extra distance.

4. **Document caveats like route_snapper** — In UI copy or docs: paint mode is heuristic; graph routing (if added later) is authoritative for connectivity.

### Tier B — Medium effort, strong correctness

5. **Export `ridescoredc` (or simplified centerlines) to GeoJSON** with consistent noding at intersections → build **`snap.bin`** via `geojson-to-route-snapper` with **`forward_cost` / `backward_cost`** derived from `user_score`, LTS, bike facility (e.g. high LTS → high cost). Ship graph for **DC bbox** (or several tiles). Integrate **`route-snapper`** as an **alternate tool**: “Draw route (snapped)” vs current “Paint segments.” On `new-route`, **buffer the LineString** and collect intersecting `ogc_fid` from Martin **or** pre-tag graph edges with `ogc_fid` at build time for exact ID mapping.

6. **`editExistingRoute` pattern** — Re-enter paint or snap tool with previous stroke / selection summarized as waypoints or seed points.

### Tier C — Research / longer horizon

7. **“Graph from vector tiles on the fly”** — Mentioned in upstream README issues; would reduce dual pipelines but needs careful R-tree + partial graph stitching across zooms.

8. **Server-side shortest path** (PostGIS `pgrouting`) — Same UX as Tier B but graph stays in DB; higher latency, simpler client. Tradeoff vs WASM.

---

## 7. Suggested decision matrix

| If your priority is… | Favor… |
|----------------------|--------|
| Fastest MVP, minimal build | Keep **tile + heuristic paint**; apply Tier A UX + scoring tweaks. |
| Fewest wrong segments at complex intersections | **Graph + shortest path** (Tier B) for at least one drawing mode. |
| Exact alignment with DB `ogc_fid` forever | Graph edges **must carry `ogc_fid`** at `snap.bin` build time, or post-path **spatial join** with tolerance QA. |
| Zero WASM / single HTML | Do **not** embed route_snapper; instead **server or precomputed paths** + segment join. |
| Same codebase as ATIP / UK planning tools | Adopt **route-snapper** NPM package and shared graph build scripts. |

---

## 8. File index (reference tree)

| Path | Role |
|------|------|
| `references/route_snapper/README.md` | Project overview, demo link |
| `references/route_snapper/user_guide.md` | Graph build, API, events, MapLibre gotchas |
| `references/route_snapper/route-snapper-graph/src/lib.rs` | Serializable graph schema |
| `references/route_snapper/route-snapper/src/lib.rs` | WASM `JsRouteSnapper`, routing & UI state |
| `references/route_snapper/route-snapper-ts/src/index.ts` | `RouteTool` MapLibre bindings |
| `references/route_snapper/route-snapper-ts/src/split.ts` | Route splitting helper |
| `references/route_snapper/osm-to-route-snapper/` | CLI OSM → `snap.bin` |
| `references/route_snapper/geojson-to-route-snapper/` | CLI GeoJSON → `snap.bin` |
| `references/route_snapper/examples/index.html` | End-to-end demo |

---

## 9. Summary

**route_snapper** is strong where RideScore paint mode is weak: **topological correctness** and **intentional route shape** via **waypoints + shortest path** on a graph with **meaningful edge costs**. It is weaker for your exact MVP unless you invest in **graph build**, **ID mapping to `ogc_fid`**, and **WASM/tooling**.

**Practical path:** keep improving **heuristic paint** for fluid “I traced my ride” input (lookahead, continuity, scoped prune, future erase-brush / lasso), and add a **second-class “snap route” mode** (route_snapper or PostGIS routing) when users want a **clean single polyline** and fewer intersection errors—then **union segment IDs** from both modes into the same survey payload.

---

## 10. In scope: draggable junction editing

**Draggable waypoints / junctions** for small post-paint corrections (pattern from route_snapper: snapped vs free, drag handles, preview) is **explicitly in scope** for RideScore map UX. Implementation can be **lightweight (tile-resnap between handles)** or **graph-backed (WASM `snap.bin`)** — see the working roadmap:

→ **`docs-4-ai/paint-route-editing-roadmap.md`**

---

*Report generated from repository audit; route_snapper upstream license Apache 2.0.*
