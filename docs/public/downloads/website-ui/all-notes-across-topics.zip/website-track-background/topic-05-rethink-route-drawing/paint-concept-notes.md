<!-- changed-box:start -->
> **What changed since this was written**
>
> This note was written around Aug 11, 2026, before the website repository was restructured on Sept 26, 2026.
>
> - `mvp_map/feedback_mvp.html` (or `feedback_mvp.html`) → `frontend/survey/index.html` (the survey, served at `/survey/`). Paint-a-route lives on the survey page, not the map page.
> - `ogc_fid` → two IDs: `segment_id` (text; a block's lasting ID; survey answers are stored against it) and `tile_id` (integer the map uses for feature-state via `promoteId`; changes every data build; never store it).
> - The `ridescoredc` table → `data.road_segment` + `data.ridescore_v1_scores`, served only through the `serving` schema: `serving.survey_segments` for the survey (street names and shapes, no score) and `serving.update_score` for the scored map. Martin publishes only `serving`.
>
> Ideas and analysis here are still useful; names, paths and line numbers may not match today's code. Check against https://github.com/civictechdc/ridescoredc-website (develop).
<!-- changed-box:end -->

Based on everything we've discussed, here's a restatement of your intentions and acceptance criteria:

---

## Feature: Paint-mode rider feedback for RideScore DC

### Intent

Allow cyclists to trace the route they rode directly on the RideScore DC map by painting over road segments with their finger or mouse. Once a route is painted, they complete a short survey rating their experience on those specific segments. The feedback is submitted to the backend and associated with the corresponding `ogc_fid` segment IDs in the PostGIS database.

---

### Acceptance criteria

**Paint mode activation**
- A "Paint route" button in the map toolbar toggles paint mode on and off
- When paint mode is active, map pan, scroll zoom, touch zoom, and double-click zoom are all disabled
- A transparent overlay div sits above the MapLibre canvas and captures all pointer events
- A visible hint instructs the user to draw along their route

**Spline drawing**
- Dragging a finger or mouse across the map renders a real-time Catmull-Rom spline on a canvas overlay
- The spline uses `touch-action: none` to prevent iOS/Android scroll hijack
- `setPointerCapture` keeps the stroke tracking even if the pointer drifts outside the overlay
- When the pointer is lifted, the spline fades out within ~400ms

**Snap-to-segment**
- As the user paints, `map.queryRenderedFeatures` queries a 40px radius bbox around each paint point against the `road-segments` layer, throttled to ~50ms
- The nearest segment within that radius is found by projecting each GeoJSON vertex to screen pixels via `map.project()` and computing perpendicular pixel distance
- Each matched segment is added to the selection set (deduplicated by `ogc_fid`) exactly once
- Selected segments are immediately highlighted blue and widened via MapLibre `feature-state`

**MapLibre source requirements**
- The segments GeoJSON or vector tile source must declare `promoteId: 'ogc_fid'` so that `setFeatureState` can locate features by ID
- The `road-segments` layer paint expression uses `['feature-state', 'selected']` to toggle color and line width
- The `update_score` SQL function must include `ogc_fid` in its SELECT for segment identification

**Selection management**
- A badge shows the live count of selected segments while any are selected
- A "Clear" button deselects all segments and resets `feature-state` on each
- In pan mode (paint off), individual segments are also clickable to toggle selection

**Feedback handoff**
- Once at least one segment is selected, a "Rate N segments" button becomes visible
- Tapping it opens the survey panel and passes a payload containing: the array of selected `ogc_fid`s, the painted stroke as a GeoJSON `LineString` (converted via `map.unproject()`), and a timestamp
- The survey engine (modeled on the nearmiss JSON-driven schema) renders questions against that payload
- On survey completion, the response is POSTed to the backend associated with the specific segment IDs

**Out of scope for this phase**
- Routing or path-finding between painted endpoints (snap is purely nearest-segment, not graph-based)
- Per-segment individual questions (survey covers the whole painted route as one submission)
- Offline / IndexedDB persistence of the selection state across sessions