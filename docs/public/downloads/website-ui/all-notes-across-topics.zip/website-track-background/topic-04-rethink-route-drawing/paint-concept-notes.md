# Paint mode: original acceptance criteria, with what was built

Describes the code as of website develop 38386ee (October 2026).
Lists the acceptance criteria paint mode was designed against and marks each one against today's survey page.

> **Historical context:** this is the original plan for paint mode, which is now built. It explains why the feature works the way it does. Where today's code differs from the plan, it's noted inline. All of the code is in `frontend/survey/index.html` (the survey, served at `/survey/`). The scored map at `/` has no paint mode.

---

## Feature: paint-mode rider feedback for RideScore DC

### Intent

**Built.**

Let cyclists trace the route they rode by painting over road blocks with a finger or mouse. Once a route is painted, they answer a short survey about those specific blocks. The answers are sent to the backend and stored against those blocks.

**Today:** blocks are tracked on the page by `tile_id` (MapLibre's feature-state id, which changes every data build). On submit, `segmentIdsFor` converts them to `segment_id`, the lasting id that `app.survey_submissions` stores.

---

### Acceptance criteria

**Paint mode activation: built.**

- A **Paint Route** button in the controls bar toggles paint mode (`togglePaintMode`). Built.
- In paint mode, map pan, scroll zoom, touch zoom and double-click zoom are disabled. Built.
- An overlay above the map captures all pointer events. Built differently: it is a canvas, `#paint-canvas`, not a div, and it is also where the stroke is drawn.
- A visible hint tells the rider what to do. Built: `#paint-hint`. (It sits low-centre over the map and can cover what the rider is painting; see the Topic 5 bugs analysis.)

**Spline drawing: built.**

- Dragging draws a real-time Catmull-Rom spline on the canvas. Built: `drawSpline`.
- The canvas uses `touch-action: none` so phones don't scroll instead. Built.
- `setPointerCapture` keeps tracking if the pointer leaves the overlay. Built.
- The spline fades out within about 400 ms of lift. Built: `fadeStroke` takes about 300 ms.

**Snap-to-segment: built differently.**

- Planned: every ~50 ms, `queryRenderedFeatures` in a 40 px box around the paint point. Built: `findBestCandidate` queries layer `road-score` (not `road-segments`) within `SNAP_RADIUS` = 40 px, called from `enqueuePaintSnap` on a 50 ms throttle.
- Planned: nearest block by projecting vertices with `map.project()` and computing perpendicular pixel distance. Built, and more: the distance is to each edge (`ptSegDist`), adjusted for stroke direction, continuity with the last block, and blocks already selected.
- Planned: each matched block is added once. Built: `commitSegment` ignores ids already selected.
- Planned: matched blocks highlight blue **immediately**. Built differently: a pick first shows light blue (`pending` feature-state) and turns solid blue only when the lookahead queue confirms it (`tryDrainSnapQueue`), or when the stroke ends (`flushSnapQueueRelaxed`). On lift, blocks far from the stroke are removed again (`pruneSelectionsFarFromRawPolyline`).
- Not in the plan: a short tap adds the single nearest block (`isStrokeTapGesture`).

**MapLibre source requirements: built differently.**

- Planned: `promoteId: 'ogc_fid'`. Built: source `segments` uses `promoteId: { 'survey_segments': 'tile_id' }`.
- Planned: a `road-segments` layer whose paint uses `['feature-state', 'selected']`. Built: a separate `road-selected` layer reads `selected` (opacity 1) and `pending` (opacity 0.48); `road-score` draws all roads in grey underneath.
- Planned: add `ogc_fid` to the `update_score` SQL function. Built differently: the survey loads `/tiles/survey_segments/{z}/{x}/{y}`, published from `serving.survey_segments`, which carries `tile_id`, `segment_id` and street name but **no score**. The survey never loads scored tiles.

**Selection management: built, with more tools.**

- A badge shows the live count while anything is selected. Built differently: `updateBadge` shows "N roads selected", counting runs of blocks on the same street (`buildContiguousSegments`), not blocks.
- **Clear** deselects everything and resets feature-state. Built: `clearSelection`.
- With paint mode off, a selected block can be clicked to change it. Built for removal only: clicking a blue block calls `removeSegmentSelection`. Clicking a grey block opens a popup with the street name and `segment_id`; it does not add it.
- Not in the plan: **Undo** (`undoLastSegment`, also Ctrl/Cmd+Z), **Undo stroke** (`undoLastPaintStroke`) and **Unpaint** mode (`toggleUnpaintMode`) for erasing blocks with a stroke or tap.

**Feedback handoff: built differently.**

- Once a block is selected, a rate button appears. Built: **Rate route →** in the badge (`openSurveyPanel`).
- Planned payload: selected ids, the stroke as a GeoJSON `LineString`, a timestamp. Built differently: the stroke and timestamp are not sent. `submitSurvey` sends `segment_ids` for the route and `contiguous_segments`, one entry per same-street run with its `segment_ids` and answers, plus the route-summary answers.
- Planned: a JSON-driven survey engine. Not built: questions are written in the page's HTML.
- On completion the response is POSTed to the backend. Built: `POST /api/submissions`.

**Planned as out of scope**

- Routing or path-finding between painted points. Still not built: snapping is nearest-block with heuristics, not graph-based.
- Per-segment questions. **Built after all:** the survey asks questions for each same-street run of blocks.
- Saving the selection offline across sessions. Still not built.
