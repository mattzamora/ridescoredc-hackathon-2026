# Paint route: editing scope and borrowed ideas

Describes the code as of website develop 38386ee (October 2026).
Collects ideas for letting riders correct a painted route without repainting it, mostly borrowed from route_snapper, and marks which of them exist in today's survey page.

> **Goal:** bring route_snapper-style correction to RideScore: **draggable junctions** (waypoints) that snap to the road network, so riders can fix small mistakes without repainting.
> **Context:** paint mode in `frontend/survey/index.html` (served at `/survey/`), which selects road blocks by `tile_id` and stores answers by `segment_id`. route_snapper is public at https://github.com/dabreegster/route_snapper. See also `route-snapper-audit-and-ridescore-recommendations.md` in this folder.

**What riders can do today to correct a route** (all **Built**): **Undo** the last block (`undoLastSegment`, Ctrl/Cmd+Z), **Undo stroke** (`undoLastPaintStroke`), **Clear** (`clearSelection`), click a blue block with paint mode off to remove it (`removeSegmentSelection`), and erase with **Unpaint** mode (`toggleUnpaintMode`, `eraseNearPaintPoint`). There are no draggable handles and no "Refine route" mode.

---

## 1. What we are scoping

### 1.1 Draggable junction editing: user story

**Idea, not built.**

After painting (or any time a route exists), the rider can:

1. See **handles** at key points along the route (junctions or decision points, not every vertex).
2. **Drag** a handle. While dragging, a **preview** shows the adjusted path snapped to nearby roads, in the same blue as paint.
3. **Release** to commit: the selection updates to match the corrected path (blocks added or removed as needed).
4. Optionally, a key or toggle for a **free point** that does not snap (route_snapper's snapped vs freehand split).

This handles small corrections without clearing the route or relying only on undo and click-to-remove.

### 1.2 Why this matches route_snapper well

**Idea, not built.**

| route_snapper concept | RideScore adaptation |
|----------------------|------------------------|
| Waypoints `Snapped(NodeID)` / `Free` | Handles as lng/lat snapped to the nearest graph node or nearest point on a tile edge |
| Shortest path between waypoints | Either a client graph (`snap.bin`), or a simpler re-snap between handles using `findBestCandidate` plus continuity along the ordered handle chain |
| `Dragging` / `Hovering` modes | A MapLibre circle or symbol layer, or an HTML overlay; map `dragPan` off while a handle is dragged |
| `renderGeojson` preview | A GeoJSON source (`route-edit`) with the preview line and handle points, or a canvas overlay |
| `editExistingRoute` | Seed handles from the current selection, for example from the endpoints of the ordered block chain |

**Minimum viable edit (no WASM):** build an ordered polyline through the selected blocks, place K handles (every Nth vertex, or at sharp bends). When a handle is dropped, re-snap the stretch between neighbouring handles with the existing tile query, using the chord direction between handles instead of stroke momentum. Recompute the set of blocks along each stretch. No graph needed; quality depends on how dense the intersections are.

Today's code already has pieces this could start from: `computeRouteSequence` orders the selected blocks by shared endpoints (`segmentEndpoints`), and `findBestCandidate` accepts `dirOverride` (a direction to use instead of momentum), `onlyFeatureIds` (restrict to given ids) and `allowSelected`.

**Stronger edit (graph or WASM):** embed route_snapper (with a DC graph built from our own road data) so dragging truly re-routes between handles, then map the path's edges back to `segment_id`s (tag graph edges with `segment_id` at build time, or do a spatial join once on finish).

---

## 2. Implementation tracks (pick one primary)

### Track A: lightweight handles (no `snap.bin`, stays in the survey page)

**Idea, not built.**

- **Data:** `selectedSegments` plus an ordered chain. Today the page keeps `strokeOrderedSegmentIds` (paint order) and builds route order with `computeRouteSequence` when the survey opens, so the ordering part exists.
- **Handles:** derived from a resampled line along the selected blocks' geometry, or from the last stroke's `paintPoints`.
- **Drag:** on drop, move one handle and replace the block ids only in the affected stretch (local re-query).
- **Pros:** one HTML page, no Rust pipeline.
- **Cons:** intersections are still decided by heuristics between two handles unless continuity and short-path rules are added.

### Track B: embed route_snapper for edit mode only

**Idea, not built.**

- **Paint** stays as it is for the first capture.
- **"Refine route"** loads the WASM module and a DC `snap.bin`, and calls `editExistingRoute` with a polyline from the current selection (needs waypoints rebuilt, or a two-endpoint seed plus `split` logic).
- **Output:** path → `segment_id`s via buffer and query, or via edge metadata in the graph file.
- **Pros:** best snapping and junction behaviour; proven UX.
- **Cons:** build pipeline, bundle size, and two sources of truth (tiles vs graph) unless the graph is generated from the same published road data.

### Track C: server-side reroute

**Idea, not built.** The API today has only `POST /api/submissions` and a health check.

- POST waypoints → PostGIS routing (for example pgRouting) → return `segment_id`s.
- **Pros:** thin client.
- **Cons:** latency; needs a new API endpoint.

**Recommendation:** start with Track A for a first "edit with handles" version; move to Track B if intersection quality during edits is still not good enough.

---

## 3. Other ideas to bring in (beyond draggable junctions)

Roughly ordered by impact for effort.

### From route_snapper

| Idea | Application | Status |
|------|-------------|--------|
| **Snap / free toggle** (`S` key, shift+click) | Let riders pin a point off the street grid (construction, trail), then snap the next stretch back. | Idea, not built |
| **`avoid_doubling_back`-style penalty** | Down-rank blocks already selected unless the rider clearly loops. | Partly built: `findBestCandidate` multiplies the score of already-selected blocks by `AVOID_REVISIT_MULT` = 1.14 while painting. Nothing for handles, since handles don't exist. |
| **Enter to finish / Esc to cancel** | Finish or cancel an edit session. | Idea, not built. Esc today only leaves Unpaint mode. |
| **`splitRoute`** | "Split route here" → two survey groups. | Idea, not built. The survey already splits a route into same-street runs automatically (`buildContiguousSegments`). |
| **Preview unsnapped legs differently** | Dashed style for unsnapped preview until confirmed. | Idea, not built. The closest thing is the light-blue `pending` state for unconfirmed picks. |
| **Show undo depth** | Show how many undo steps are left. | Idea, not built. Undo buttons are only enabled or disabled. |

### From earlier RideScore notes

| Idea | Application | Status |
|------|-------------|--------|
| **Erase brush** | Remove blocks the stroke crosses. | **Built** as Unpaint mode (a separate button, not Alt + paint): `toggleUnpaintMode`, `eraseNearPaintPoint`, `tryUnpaintTapAt`. |
| **Lasso / box subtract** | Drag a box in normal mode to remove the selected blocks inside it. | Idea, not built |
| **Undo last stroke** | Remove all blocks added between `pointerdown` and `pointerup`. | **Built**: `undoLastPaintStroke`, using `strokeBatchesHistory` filled from `idsTouchedThisStroke`. |
| **Survey-time strip with remove checkboxes** | Before submit, list blocks with a way to drop them. | Idea, not built. The survey sheet shows a track of same-street runs that the rider can jump between, but not remove. |
| **Soft warning on a disconnected new stroke** | If a new stroke starts far from the existing selection, ask "Connecting a new area?" | Idea, not built |

### From map UX polish

| Idea | Application | Status |
|------|-------------|--------|
| **Handle hit slop** | 12–16 px pick tolerance on handles. | Idea, not built |
| **Keyboard nudge** | Arrow keys move the focused handle about 1 m (accessibility). | Idea, not built |
| **Magnetism** | Slight pull toward a strong candidate intersection while dragging, to reduce jitter. | Idea, not built |

---

## 4. Engineering checklist (when implementing handles)

**Idea, not built.**

- [ ] **Ordering:** editing needs an ordered chain of blocks or a stored reference polyline. Today `selectedSegments` is a `Map` keyed by `tile_id`; paint order is kept in `strokeOrderedSegmentIds`, and `computeRouteSequence` builds route order from block endpoints. The last stroke's points (`paintPoints`) are not kept after the next stroke starts.
- [ ] **Layers:** dedicated `route-handles` and `route-edit-preview` sources so the paint canvas and handles don't fight over pointer capture.
- [ ] **State machine:** `idle | painting | unpainting | editing | editing-drag`, with only one consuming pointer events. Today paint and unpaint are two flags (`paintMode`, `unpaintMode`) that switch each other off.
- [ ] **Commit rules:** apply the preview on an explicit confirm, or on every drag end. Explicit confirm reduces flicker; route_snapper redraws continuously and finishes on demand.
- [ ] **Performance:** throttle re-queries while dragging; `querySourceFeatures` is slow on large viewports.
- [ ] **Tile pieces:** a block that crosses a tile edge arrives as several pieces with the same `tile_id`. Any handle or distance logic must consider all pieces (see Bug B in the Topic 5 bugs analysis).
- [ ] **Mobile:** handle touch targets at least 44 px.

---

## 4.1 "Refine route": a detailed design

**Idea, not built.** None of the functions named in this section exist in today's code. Read it as a worked design for Track A, including problems the design expects and how it would avoid them.

**Already in the code that this design relies on:** `findBestCandidate` returns `vertexLLA` / `vertexLLB` (the lng/lat ends of the winning edge) alongside the pixel `edge`, and `lineEndpointA` / `lineEndpointB` (the ends of the winning line).

| Piece | Proposed logic |
|--------|--------|
| **Primary drag** | The dragged handle snaps to the nearer of the winning edge's two endpoints (`snapRefineHandleToRoadVertex`), so it locks to an intersection or block end rather than sitting mid-block. |
| **Initial placement and followers** | Other handles snap to the closest point on the best edge (`snapRefineHandleClosestOnBestEdge`), so handles along a long straight stay on the same centreline. |
| **Broad drag (route_snapper-inspired)** | Moving handle `i` also moves `i±1` and `i±2` by a weighted share of the drag (`REFINE_PULL_WEIGHTS`), then re-snaps those followers **only to blocks already selected** (`onlyFeatureIds`). Without that restriction, followers at a crossing can each jump to a different arm of the intersection. The dragged handle itself snaps to any road so it can join a new street. |
| **Rebuild stability** | Merge handles closer than about 24 m along the chain. Don't resample handles globally after a drag (it spawns handles on untouched straights); instead reproject existing handles onto the new chain, and rebuild only when chains split or merge (`placeHandlesForChain`). |
| **Sampling between handles (`collectIdsAlongHandlePath`)** | Snap without direction bias, with hysteresis: along each stretch, keep the previous block unless another is about 22 px closer, so dense samples at an intersection don't add every arm. Sample about every 10 m, at most 48 steps per stretch. |
| **Preview line** | Round line caps and joins, a dash pattern, opacity below 1; drop consecutive points closer than 0.25 m (`syncRefinePreviewLine`) to avoid dash artefacts. |
| **Pointer up** | Remove consecutive near-duplicate handles (`dedupeNearIdenticalRefineHandles`). |

**Live commit:** while dragging, a `requestAnimationFrame` callback (`scheduleRefineLiveCommit`) would re-run `collectIdsAlongHandlePath` and replace the selection, so the blue blocks follow the dashed line in real time. On release: flush the pending update, push a snapshot onto a refine undo stack, and rebuild handles from the new block order. **Esc** would restore the selection from when refine mode opened; turning refine mode off would keep the current selection; **Undo last refine** or Ctrl+Z would pop one step.

**Still different from route_snapper:** dragging a graph node there recomputes the route through the street network. This design only re-samples blocks along straight chords between handles. Embedding route_snapper is the way to get identical behaviour.

---

## 5. Related notes

- route_snapper deep dive and tiers: `route-snapper-audit-and-ridescore-recommendations.md` (this folder)
- Intersection snapping: `../topic-05-fix-the-route-selector-bugs/snap-intersection-problem.md`
- Live bug findings: `../topic-05-fix-the-route-selector-bugs/route-selector-bugs-analysis.md`
- Original paint acceptance criteria: `paint-concept-notes.md` (this folder)
