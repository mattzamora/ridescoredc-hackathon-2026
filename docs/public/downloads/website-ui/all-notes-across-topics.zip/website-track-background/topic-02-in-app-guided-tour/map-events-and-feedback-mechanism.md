# Map Events and the Feedback Mechanism

Describes the code as of website develop 38386ee and models develop ef0caea (October 2026).
How the two pages listen to the map, and how "pick a route, then give feedback" is wired today, for anyone adding interaction to either page.

> Pages: the scored map is `frontend/index.html` (served at `/`). Route feedback lives on a separate page, `frontend/survey/index.html` (served at `/survey/`). Shared map code is in `frontend/src/shared/`.

---

## 1. Event listeners on the two pages

**Built.**

### Map page (`frontend/index.html` plus `frontend/src/shared/crashes.js`)

```javascript
// Road segment: popup on click, pointer cursor on hover (in frontend/index.html)
map.on('click', 'update_score', (e) => { ... })
map.on('mouseenter', 'update_score', () => { map.getCanvas().style.cursor = 'pointer'; })
map.on('mouseleave', 'update_score', () => { map.getCanvas().style.cursor = ''; })

// Crash point: popup on click, pointer cursor on hover (in RideScore.addCrashes, crashes.js)
map.on('click', 'crashes', (e) => { ... })
map.on('mouseenter', 'crashes', () => { ... })
map.on('mouseleave', 'crashes', () => { ... })
```

All are layer-scoped: they fire only when the pointer is over a feature in that layer. MapLibre does the hit-testing against the tile geometry. The map page has no selection and no feedback; it only shows information.

### Survey page (`frontend/survey/index.html`)

The survey page loads the same crash layer (so the `crashes` listeners above exist there too) and adds its own:

| Listener | What it does |
|---|---|
| `map.on('click', 'road-score', ...)` | Popup with the street name and its `segment_id`. Ignored while painting or unpainting. |
| `map.on('click', 'road-selected', ...)` | Removes an already-selected segment (`removeSegmentSelection`). Ignored while painting. |
| `mouseenter` / `mouseleave` on `road-score` and `road-selected` | Pointer cursor. Ignored while painting. |
| `pointerdown` / `pointermove` / `pointerup` / `pointercancel` on `#paint-canvas` and `#unpaint-canvas` | The paint and unpaint gestures. These are DOM events on canvases laid over the map, not MapLibre events. |
| `keydown` on `document` | Ctrl+Z (or Cmd+Z) undoes the last segment; Escape leaves unpaint mode. |

While paint mode is on, `togglePaintMode()` turns off MapLibre's drag-pan, scroll-zoom, double-click-zoom and touch-zoom, and gives the paint canvas `pointer-events: all`, so strokes go to the canvas instead of moving the map.

---

## 2. How the click → popup flow works

**Built.**

```
User clicks a road on the map page
   ↓
map.on('click', 'update_score', (e) => {
   const p = e.features[0].properties   // properties from the tile
   const html = `<div>…<table>…</table></div>`
   new maplibregl.Popup().setLngLat(e.lngLat).setHTML(html).addTo(map)
})
```

**The click event `e`:**

```javascript
e.lngLat                    // { lng, lat } where the user clicked
e.point                     // { x, y } pixel position on screen
e.features                  // features under the click (can be several)
e.features[0].properties    // the columns the tile source selected
e.features[0].geometry      // GeoJSON geometry
e.features[0].id            // feature id (set when the source uses promoteId)
```

**Properties on `update_score` features** (from `serving.update_score` in the models repo, `serving/030_update_score.sql`):

- `tile_id`, `segment_id`
- `user_score`, `ridescore_v1`, `lts_level`
- `route_name`, `bike_facility_type`, `function`, `num_lanes_raw`, `speed_limit_raw`, `road_width`, `parking_presence`, `pavement_condition`

**Properties on `survey_segments` features** (from the view `serving.survey_segments`, `serving/020_survey_segments.sql`): only `tile_id`, `segment_id` and `route_name`. No score of any kind.

Earlier versions of the tile function had no identifier column at all, so a clicked segment could not be stored. That is fixed: both sources now carry `segment_id` (lasting, store this) and `tile_id` (per data build, for feature-state only, never store it).

---

## 3. MapLibre events and queries relevant to feedback

**Partly built.** Today the pages use `click`, `mouseenter`, `mouseleave` and `queryRenderedFeatures`. The rest are listed as options.

### Layer-scoped events

| Event | Possible use for feedback | Used today |
|---|---|---|
| `click` | Select or inspect a segment | Yes |
| `mouseenter` / `mouseleave` | Hover state, cursor | Yes (cursor only) |
| `mousemove` | Highlight the segment under the cursor | No |
| `dblclick` | Separate "select" from "open details" | No (double-click zoom is disabled while painting) |
| `contextmenu` | Right-click options | No |

### Map-level events

| Event | Possible use | Used today |
|---|---|---|
| `map.on('click', e)` with no layer | Click on empty space to deselect | No |
| `moveend`, `zoomend` | React when the user finishes panning or zooming | No |

### Querying features without a click

```javascript
// Features near a point (a small box around it)
map.queryRenderedFeatures([[x - r, y - r], [x + r, y + r]], { layers: ['road-score'] })

// Features in the viewport matching a filter
map.queryRenderedFeatures({ layers: ['road-score'], filter: ['==', ['get', 'route_name'], 'K ST NW'] })
```

The survey's paint snapping uses the first form: `findBestCandidate()` queries `road-score` in a box of `SNAP_RADIUS` (40 px) around each stroke point and scores the candidates by distance, direction and continuity.

---

## 4. Multi-segment selection

### Approach A: toggle segments into a selection, highlighted with feature-state

**Built**, on the survey page, using painting instead of plain clicks.

- The selection is `selectedSegments`, a `Map` from `tile_id` to the feature's properties. `strokeOrderedSegmentIds` keeps the order segments were added.
- Paint mode adds segments as the user swipes along roads, or taps one road. Unpaint mode removes them the same way. With neither mode on, clicking a blue segment removes it.
- The badge offers **Undo**, **Undo stroke**, **Clear** and **Rate route →**, and counts selected "roads" (runs of the same street, from `buildContiguousSegments()`).

Highlighting uses feature-state, which needs a stable integer id per feature. The survey source sets that with `promoteId`:

```javascript
map.addSource('segments', {
  type: 'vector',
  tiles: [`${location.origin}/tiles/survey_segments/{z}/{x}/{y}`],
  promoteId: { 'survey_segments': 'tile_id' },
  minzoom: 1, maxzoom: 14
});
```

`commitSegment()` then marks a segment:

```javascript
map.setFeatureState(
  { source: 'segments', sourceLayer: 'survey_segments', id: featureId },
  { selected: true, pending: false }
);
```

and the `road-selected` layer draws it:

```javascript
'line-opacity': [
  'case',
  ['boolean', ['feature-state', 'selected'], false], 1,
  ['boolean', ['feature-state', 'pending'], false], 0.48,
  0
]
```

`tile_id` is only good for this build of the data. What gets stored is `segment_id`, looked up from the saved properties at submit time by `segmentIdsFor()`.

### Approach B: select every segment of the same named street

**Idea, not built.**

```javascript
map.on('click', 'road-score', (e) => {
  const routeName = e.features[0].properties.route_name;
  const sameStreet = map.queryRenderedFeatures({
    layers: ['road-score'],
    filter: ['==', ['get', 'route_name'], routeName],
  });
  // add each to selectedSegments and set feature-state
});
```

Caveat: `queryRenderedFeatures` only returns features currently drawn in the viewport. A street that runs off screen would need panning, or a server-side query by `route_name`.

---

## 5. Popup versus a panel for the survey

**Built.** The project went with the recommended split:

| Concern | Popup | Panel / bottom sheet |
|---|---|---|
| Form inputs | Awkward | Full control |
| Multi-step survey | Not suitable | Natural |
| Stays open across selections | Closes on map click | Stays open |
| Phone use | Narrow | Full width |

Popups stay for read-only information (road and crash details). The survey is `#survey-sheet`: a bottom sheet at half the screen height on phones (up to 768 px wide), and a 380 px panel on the right on wider screens. On phones the map shrinks to the top half while the sheet is open (`body.survey-active #map { bottom: 50vh; }`).

---

## 6. The feedback flow as built

**Built** (on `/survey/`), except where marked.

```
1. User turns on Paint Route and swipes along roads (or taps one)
   → findBestCandidate() snaps stroke points to road-score features
   → commitSegment() adds each to selectedSegments and sets feature-state selected
   → The road turns blue (road-selected layer)

2. User adjusts the selection
   → Unpaint, Undo, Undo stroke, Clear, or click a blue segment to drop it
   → Badge shows "N roads selected"

3. User clicks "Rate route →"
   → openSurveyPanel()
   → buildContiguousSegments() orders the selection (computeRouteSequence())
     and groups it into runs of the same street
   → Survey sheet opens; map flies to the first run, highlighted cyan with a black border

4. Per-street questions, one run at a time
   → Perceived LTS (1–4), safety (1–10), stress factors if LTS is 3 or 4
   → Next / Back / tap the track / "Skip →" to jump to the summary

5. Route summary
   → Time of day, overall satisfaction (1–5), would ride again — all required
   → Comments (optional)

6. Submit
   → POST /api/submissions with segment_ids and per-run answers
   → Thank-you screen; "Done" closes the sheet and clears the selection
```

Not built from the original plan:

- **Map-level click to deselect everything**: **Idea, not built.** Clearing is done with the badge's **Clear** button.
- **Direction of travel** and a **"did you feel safe?" yes/no per segment**: **Idea, not built.** Safety is a 1–10 rating per run instead.

The page shows the thank-you screen even if the POST fails; the error only goes to the browser console.

---

## 7. What still needs to change

**Partly built.** The original list here (add IDs to the tile function, add selection state, highlight layer, feedback button, survey panel) is done, though on the survey page rather than the map page. Remaining gaps and options:

- **Feedback from the scored map page.** **Idea, not built.** The map page has no selection or "give feedback" action. Adding one must not show the score to someone who is about to rate the street; that is why the survey is a separate page served from `serving.survey_segments`, which carries no score. A safe version would link from the map page to `/survey/` instead of embedding the survey.
- **Selection highlight on the map page.** **Idea, not built.** It would need `promoteId: { 'update_score': 'tile_id' }` on `my-vector-source` and a highlight layer, as the survey page does.
- **Crash count in the road popup.** The map popup reads `crash_count_5yr`, which `serving.update_score` does not select, so it shows `undefined`. Fix by adding the column to the function in the models repo.

---

## 8. Ideas from the NearMiss survey pattern

**Idea, not built.** The note `topic-06-riders-report-hazards/nearmiss-dynamic-surveys.md` describes a JSON-driven survey engine from a different app (NearMiss). How its concepts line up with RideScore DC today:

| NearMiss concept | RideScore DC today |
|---|---|
| `report_id` | `submission_id` (UUID, returned by `POST /api/submissions`) |
| `survey.json` defining questions | Questions are hard-coded HTML and JS in `frontend/survey/index.html` (for example the `STRESS_FACTORS` array and the `#ss-lts-row` buttons) |
| `SurveyForm.svelte` | The `#survey-sheet` markup and its functions (`renderQuestion()`, `segNext()`, `submitSurvey()`) |
| IndexedDB draft persistence | None. Answers live in memory (`surveyAnswers`) and are lost on reload. |
| Pre-filling a geospatial question | The route itself is the location: `segment_ids` from the painted selection |

Questions a JSON-defined segment survey could add (none are built):

- Direction of travel
- A free-text description per segment (today there is one comments box per route)
- A finer time of day than Morning / Afternoon / Evening / Night

Any new answer also needs a field on `ContiguousSegment` or `SurveySubmission` in `api/main.py`, the matching `INSERT`, and a new numbered migration in `api/migrations/` for the column.
