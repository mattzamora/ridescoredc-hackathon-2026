# Website/UI track — background pack (Topics 3–7)

RideScore DC Hackathon, Saturday October 3, 2026.

This pack holds the project's internal design notes that are useful background for the Intermediate topics 3–7 of the Website/UI track, plus one new analysis written for Topic 6. They are optional reading: the topic pages on the hackathon site tell you what to do; these notes tell you what was tried and why.

Each document comes twice: a `.md` (Markdown) file and a `.docx` (Word) copy. The Topic 4 folder also has `survey_sample.html`, a standalone mock-up you can open in any browser.

## What's in it

| Topic | File | Why it's useful |
|---|---|---|
| 3. Make the map make sense | `topic-03-make-the-map-make-sense/mvp-map.md` | How the map page is built: tile sources, layers, score colors, the weight sliders and popups. |
| 3. Make the map make sense | `topic-03-make-the-map-make-sense/map-events-and-feedback-mechanism.md` | MapLibre click/hover events, feature-state highlighting and popup-vs-panel trade-offs. |
| 4. A survey that works on a phone | `topic-04-survey-on-a-phone/survey-per-segment-plan.md` | Design decisions behind the per-segment bottom-sheet survey, its questions and the route sequencer. |
| 4. A survey that works on a phone | `topic-04-survey-on-a-phone/survey_sample.html` | Standalone bottom-sheet mock-up; open it in a phone-sized browser window. |
| 5. Rethink route drawing | `topic-05-rethink-route-drawing/paint-route-editing-roadmap.md` | Scope for draggable-junction editing and a list of borrowed correction ideas. |
| 5. Rethink route drawing | `topic-05-rethink-route-drawing/route-snapper-audit-and-ridescore-recommendations.md` | How route_snapper's graph-based snapping differs from tile painting, with tiered recommendations. |
| 5. Rethink route drawing | `topic-05-rethink-route-drawing/mvp-feedback-plan.md` | The original step-by-step build plan for paint mode, with code sketches. |
| 5. Rethink route drawing | `topic-05-rethink-route-drawing/paint-concept-notes.md` | Short intent and acceptance criteria for paint-mode feedback. |
| 6. Fix the route-selector bugs | `topic-06-fix-the-route-selector-bugs/snap-intersection-problem.md` | Five approaches to the wrong-street-at-intersections problem, with tuning parameters. |
| 6. Fix the route-selector bugs | `topic-06-fix-the-route-selector-bugs/route-selector-bugs-analysis.md` | New: today's two selector bugs traced to specific functions, with repro steps and fix ideas. |
| 7. Riders report hazards | `topic-07-riders-report-hazards/nearmiss-dynamic-surveys.md` | A JSON-driven survey engine (NearMiss) you could borrow for a hazard report form. |
| 7. Riders report hazards | `topic-07-riders-report-hazards/database-migrations.md` | How schema changes were managed with yoyo; background for adding a hazard-report table. |

## Read this first: the notes are out of date in places

Most notes were written around August 11, 2026, before the website repository was restructured on September 26, 2026. File names, table names, IDs and line numbers in them may not match today's code. Every note starts with a **"What changed since this was written"** box listing the renames that note relies on (for example `ogc_fid` is now `segment_id` plus `tile_id`, and `mvp_map/feedback_mvp.html` is now `frontend/survey/index.html`).

Ideas and analysis here are still useful; names, paths and line numbers may not match today's code. Check against https://github.com/civictechdc/ridescoredc-website (develop). When a note and the hackathon guide disagree, the guide is right.

## How to use with AI tools

Give the `.md` files to your AI assistant (attach them or paste them in). Markdown keeps headings, tables and code blocks intact, so the assistant reads the structure correctly; Word files lose some of it. The `.docx` copies are for reading or printing. Diagrams and some formatting are simplified in the Word copies.

A good first prompt: "I'm working on Topic N of the RideScore DC hackathon Website/UI track. Read these background notes, note anything the 'What changed' box says is renamed, and help me plan a 2–3 hour approach."

## Topics without a pack

Topics 8 and 10 have no background pack. For those, use the guide pages:

- [The data](https://mattzamora.github.io/ridescoredc-hackathon-2026/tracks/website-ui/the-data)
- [Repository layout](https://mattzamora.github.io/ridescoredc-hackathon-2026/tracks/website-ui/repository-layout)

## Not included

Database dumps, server setup notes, personal messages and the older infrastructure overview are deliberately left out. The `references/route_snapper` and `references/nearmiss` folders mentioned in some notes are not included; route_snapper is public at https://github.com/dabreegster/route_snapper.
