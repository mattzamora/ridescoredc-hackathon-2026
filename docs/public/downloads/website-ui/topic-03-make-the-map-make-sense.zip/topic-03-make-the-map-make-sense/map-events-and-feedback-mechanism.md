<!-- changed-box:start -->
> **What changed since this was written**
>
> This note was written around Aug 11, 2026, before the website repository was restructured on Sept 26, 2026.
>
> - `mvp_map/index.html` → `frontend/index.html` (the map, served at `/`). Code both pages share (base map, tile addresses, crash layer) is now in `frontend/src/shared/`.
> - `crashes_dc` layer/table → `crashes` (served from the database's `serving` schema; tiles at `/tiles/crashes/...`).
> - `ogc_fid` → two IDs: `segment_id` (text; a block's lasting ID; survey answers are stored against it) and `tile_id` (integer the map uses for feature-state via `promoteId`; changes every data build; never store it).
> - The `ridescoredc` table → `data.road_segment` + `data.ridescore_v1_scores`, served only through the `serving` schema: `serving.survey_segments` for the survey (street names and shapes, no score) and `serving.update_score` for the scored map. Martin publishes only `serving`.
> - The `references/nearmiss` folder is not included in this pack.
> - Links to other `docs-4-ai/...` notes: those notes are in this pack's topic folders. `infrastructure-overview.md` is not included; the guide pages replace it.
>
> Ideas and analysis here are still useful; names, paths and line numbers may not match today's code. Check against https://github.com/civictechdc/ridescoredc-website (develop).
<!-- changed-box:end -->

# Map Events & Feedback Mechanism — Technical Report

> Reference: `mvp_map/index.html`
> Intent: Build a route selection + segment feedback survey on top of the existing map

---

## 1. Current Event Listeners in the Map

The map currently registers four event listeners, all on named layers:

```javascript
// Road segment — open popup on click
map.on('click', 'update_score', (e) => { ... })

// Road segment — cursor change on hover
map.on('mouseenter', 'update_score', () => { map.getCanvas().style.cursor = 'pointer' })
map.on('mouseleave', 'update_score', () => { map.getCanvas().style.cursor = '' })

// Crash point — open popup on click
map.on('click', 'crashes_dc', (e) => { ... })
map.on('mouseenter', 'crashes_dc', () => { map.getCanvas().style.cursor = 'pointer' })
map.on('mouseleave', 'crashes_dc', () => { map.getCanvas().style.cursor = '' })
```

All are layer-scoped — they only fire when the interaction target is a feature on that specific layer. MapLibre handles hit-testing internally against the vector tile geometry.

---

## 2. How the Current Click → Popup Flow Works

```
User clicks on road segment
   ↓
map.on('click', 'update_score', (e) => {
   const p = e.features[0].properties   // feature properties from the tile
   const html = `<table>...</table>`     // build HTML string
   new maplibregl.Popup()
     .setLngLat(e.lngLat)               // position popup at click coordinates
     .setHTML(html)                     // inject HTML content
     .addTo(map)                        // attach to map
})
```

**Key object: `e` (the click event)**

```javascript
e.lngLat          // { lng, lat } — exact coordinates where user clicked
e.point           // { x, y }    — pixel coordinates on screen
e.features        // array of features under the click point (can be multiple)
e.features[0]     // topmost feature
e.features[0].properties   // all columns from the PostGIS table/function
e.features[0].geometry     // GeoJSON geometry of the feature
e.features[0].id           // feature ID (if set)
```

**Properties available on `update_score` features:**
- `user_score`, `ridescore_v1`, `route_name`, `bike_facility_type`
- `function`, `lts_level`, `num_lanes_raw`, `speed_limit_raw`
- `road_width`, `parking_presence`, `pavement_condition`

Note: `ogc_fid` and `route_id` are **not** currently selected in the `update_score` SQL function — they would need to be added to uniquely identify a segment for feedback submission.

---

## 3. Full MapLibre Event Reference Relevant to Feedback

### Layer-scoped events (fire only on specific layer features)

| Event | Usage for feedback |
|---|---|
| `click` | Primary trigger — user selects a segment |
| `dblclick` | Could distinguish "select" from "open detail" |
| `mouseenter` | Show preview/tooltip on hover |
| `mouseleave` | Clear hover state |
| `mousemove` | Highlight segment under cursor in real time |
| `contextmenu` | Right-click for additional options |

### Map-level events (fire anywhere on the map)

| Event | Usage for feedback |
|---|---|
| `map.on('click', (e))` | Detect clicks on empty space (deselect) |
| `map.on('moveend')` | Detect when user finishes panning |
| `map.on('zoomend')` | Detect zoom changes |

### Querying features programmatically

Beyond click events, MapLibre can query features without user interaction:

```javascript
// All features at a pixel point
map.queryRenderedFeatures(e.point, { layers: ['update_score'] })

// All features within a bounding box
map.queryRenderedFeatures([topLeft, bottomRight], { layers: ['update_score'] })

// Filter by property
map.queryRenderedFeatures({ layers: ['update_score'], filter: ['==', 'route_name', 'K ST NW'] })
```

This is useful for selecting all segments of the same named route when a user clicks one segment.

---

## 4. Multi-Segment Selection — Design Considerations

For a "indicate which route you took" flow, users need to select multiple road segments. The current model (click → single popup) needs to be extended.

### Approach A: Click-to-toggle selection state

```javascript
let selectedSegments = new Map()  // key: segment identifier → value: feature properties

map.on('click', 'update_score', (e) => {
  const feature = e.features[0]
  const id = feature.properties.ogc_fid  // needs to be added to SQL function

  if (selectedSegments.has(id)) {
    selectedSegments.delete(id)
  } else {
    selectedSegments.set(id, feature.properties)
  }

  // Re-render selection highlight layer
  updateSelectionLayer()
})
```

### Approach B: Select all segments of the same named route

```javascript
map.on('click', 'update_score', (e) => {
  const routeName = e.features[0].properties.route_name

  // Query all currently rendered segments with same route name
  const allSegments = map.queryRenderedFeatures(
    { layers: ['update_score'] },
    { filter: ['==', 'route_name', routeName] }
  )
  // Add all to selection
})
```

**Caveat:** `queryRenderedFeatures` only returns features currently in the viewport. For a full route that extends beyond the screen, the user would need to pan and select additional segments, or the selection would need to be driven by a database query instead.

### Highlighting Selected Segments

MapLibre supports feature-state to style selected features without re-fetching tiles:

```javascript
// Set state on a feature
map.setFeatureState(
  { source: 'my-vector-source', sourceLayer: 'update_score', id: featureId },
  { selected: true }
)

// Reference in layer paint
'line-color': ['case',
  ['boolean', ['feature-state', 'selected'], false],
  '#0066FF',         // selected — blue
  ['interpolate', ['linear'], ['get', 'user_score'],
    0, '#CC3232', 50, '#E7B416', 100, '#2DC937']  // default gradient
]
```

**Important:** Feature-state requires features to have stable IDs. The `update_score` function would need to include `ogc_fid` as the feature ID for this to work. MVT feature IDs must be integers.

---

## 5. Popup vs. Custom Panel — Trade-offs for Survey UI

The current `maplibregl.Popup` is minimal — it displays HTML at a map coordinate and closes when the user clicks elsewhere. For a survey/feedback flow it has significant limitations:

| Concern | Popup | Custom side panel / modal |
|---|---|---|
| Form inputs | Works but awkward | Full control |
| Multi-step survey | Not suitable | Natural |
| Persisting across segment selections | Closes on map click | Stays open |
| Mobile usability | Limited width | Full responsive control |
| Accessing selected segments list | Must pass via closure | Shared state |

**Recommended pattern:** Keep `maplibregl.Popup` for the read-only segment info preview (existing behavior), and open a separate side panel or bottom sheet when the user initiates a feedback/survey action (e.g., a "Give Feedback on Selection" button that appears after ≥1 segment is selected).

---

## 6. Proposed Event Flow for Feedback Mechanism

```
1. User clicks road segment
   → map.on('click', 'update_score')
   → Toggle segment into selectedSegments Map
   → Highlight segment (feature-state or separate layer)
   → Show small preview popup: route name + score + "Add to selection" confirm

2. User builds up selection (repeat step 1 on more segments)
   → Selection counter badge appears in UI ("3 segments selected")

3. User clicks "Give Feedback" button (appears when selection is non-empty)
   → Side panel / modal opens
   → Passes selectedSegments data into survey component

4. Survey collects feedback
   → Overall experience rating
   → Per-factor ratings (pavement, safety, lanes, etc.)
   → Free text comments
   → Optional: "Did you feel safe?" boolean per segment

5. Submit
   → POST to backend with: { segments: [...ogc_fids], answers: {...} }
   → Clear selection, close panel, show confirmation

6. User clicks empty map area
   → map.on('click') at map level (no layer filter)
   → Deselect all if no survey in progress
```

---

## 7. What Needs to Change in the Existing Code

### In the `update_score` PostgreSQL function
Add `ogc_fid` and `route_id` to the SELECT so features have stable identifiers available in the tile properties:
```sql
SELECT
  ST_AsMVTGeom(...) AS geom,
  ogc_fid,          -- add this
  route_id,         -- add this
  user_score,
  route_name,
  ...
```

### In `index.html`
1. Add a `selectedSegments` state object
2. Modify the `map.on('click', 'update_score')` handler to toggle selection instead of (or in addition to) showing a popup
3. Add a selection highlight layer with `feature-state`-driven styling
4. Add a "Feedback" button to the controls bar that activates when selection is non-empty
5. Add the survey panel/modal HTML + open/close logic
6. Wire the "Update Map" flow to clear selection state

---

## 8. Integration with NearMiss Survey Pattern

The `references/nearmiss` survey system (see `docs-4-ai/nearmiss-dynamic-surveys.md`) is directly applicable here. The mapping between the two systems:

| NearMiss concept | Feedback mechanism equivalent |
|---|---|
| `report_id` | Selected segment `ogc_fid` (or a session ID covering multiple segments) |
| `survey.json` | A new JSON file defining segment feedback questions |
| `SurveyForm.svelte` | Survey panel component embedded in the map page |
| IndexedDB persistence | Same — store draft feedback locally before submission |
| `keysForQuestionType` | Could pre-populate geospatial question with segment coordinates |

The survey JSON for segment feedback would likely cover:
- Overall safety feeling (radio: 1–5)
- What made it feel unsafe (checkbox: traffic speed, lane width, pavement, etc.)
- Direction of travel (radio: N/S/E/W)
- Time of day (datetime or radio: morning/afternoon/evening/night)
- Free text description (textarea)
