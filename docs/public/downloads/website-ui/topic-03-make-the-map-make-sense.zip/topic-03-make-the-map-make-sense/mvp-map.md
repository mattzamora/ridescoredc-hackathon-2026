<!-- changed-box:start -->
> **What changed since this was written**
>
> This note was written around Aug 11, 2026, before the website repository was restructured on Sept 26, 2026.
>
> - `mvp_map/index.html` → `frontend/index.html` (the map, served at `/`). Code both pages share (base map, tile addresses, crash layer) is now in `frontend/src/shared/`.
> - `crashes_dc` layer/table → `crashes` (served from the database's `serving` schema; tiles at `/tiles/crashes/...`).
> - The `ridescoredc` table → `data.road_segment` + `data.ridescore_v1_scores`, served only through the `serving` schema: `serving.survey_segments` for the survey (street names and shapes, no score) and `serving.update_score` for the scored map. Martin publishes only `serving`.
> - Martin at `http://localhost:3000` → tiles are requested at `/tiles/...` on the page's own address: nginx on `localhost:8000` in the Full Stack setup, or proxied by Vite on `localhost:5173` in the Front-End setup.
> - `mvp_map/docker-compose.yml` → `docker-compose.yml` at the root of the website repo (start it with `npm run stack`).
>
> Ideas and analysis here are still useful; names, paths and line numbers may not match today's code. Check against https://github.com/civictechdc/ridescoredc-website (develop).
<!-- changed-box:end -->

# MVP Map — Technical Implementation Report

> Reference: `mvp_map/index.html`

---

## Overview

The MVP map is a single self-contained HTML file with no build step. It uses **MapLibre GL JS** to render an interactive bike safety map of Washington D.C., pulling vector tile data from a local **Martin** tile server backed by a **PostGIS** database. The map supports two display modes (pre-computed RideScore vs. custom weighted scoring) and two optional overlay layers (satellite imagery and accident heatmap).

---

## Architecture

```
Browser (index.html)
   ├── MapLibre GL JS (rendering engine)
   ├── Martin tile server (http://localhost:3000)  ← vector tiles
   │     ├── /update_score/{z}/{x}/{y}?...         ← road segments (MVT function)
   │     └── /crashes_dc/{z}/{x}/{y}               ← crash points (MVT table)
   └── DC GIS tile server (external)               ← 2025 aerial imagery (raster)
```

No JavaScript bundler, no framework, no dependencies beyond the MapLibre CDN script and stylesheet.

---

## Map Initialization

```javascript
const map = new maplibregl.Map({
  container: 'map',
  style: 'https://tiles.openfreemap.org/styles/bright',
  center: [-77.02515, 38.91668],   // Washington D.C.
  zoom: 15
});
```

The base map style is served by **OpenFreeMap** (open-source, no API key required). All custom layers are added inside the `map.on('style.load', ...)` callback to ensure the base style is ready first.

---

## Data Sources

### 1. Road Segments — `update_score` (Vector Tiles)

```javascript
map.addSource('my-vector-source', {
  type: 'vector',
  tiles: ["http://localhost:3000/update_score/{z}/{x}/{y}?i_ridescore=4&..."],
  minzoom: 1,
  maxzoom: 14
});
```

This calls a **PostgreSQL function** (`public.update_score`) via Martin. The function accepts query parameters as a `json` argument and dynamically computes a `user_score` per road segment on the fly inside PostGIS:

```sql
(ridescore_v1 * i_ridescore + speedlimit_score * i_speedlimit + ...) 
/ (i_ridescore + i_speedlimit + ...)  AS user_score
```

The tile URL carries all scoring weights as query parameters, so changing the sliders issues a new tile request with different weights — no separate API call needed.

**Properties exposed per tile feature:**
- `user_score` — computed weighted score (0–100 range)
- `route_name`, `bike_facility_type`, `function`, `lts_level`
- `num_lanes_raw`, `speed_limit_raw`, `road_width`
- `parking_presence`, `pavement_condition`, `ridescore_v1`

### 2. Crash Points — `crashes_dc` (Vector Tiles)

```javascript
map.addSource('points-source', {
  type: 'vector',
  tiles: ["http://localhost:3000/crashes_dc/{z}/{x}/{y}"],
  minzoom: 1,
  maxzoom: 14
});
```

Auto-published by Martin from the `public.crashes_dc` PostGIS table. No server-side computation — raw point data served directly as MVT.

### 3. Satellite Imagery (Raster Tiles)

```javascript
map.addSource('dc-ortho-2025', {
  type: 'raster',
  tiles: ['https://maps2.dcgis.dc.gov/dcgis/rest/services/DCGIS_DATA/Ortho2025_WebMercator/MapServer/tile/{z}/{y}/{x}'],
  tileSize: 256
});
```

2025 aerial photography from the DC GIS public tile service. Loaded as a raster layer, hidden by default.

---

## Layers

| Layer ID | Type | Source | Default Visibility |
|---|---|---|---|
| `ortho-2025-layer` | raster | `dc-ortho-2025` | hidden |
| `update_score` | line | `my-vector-source` | visible |
| `crashes_dc` | circle | `points-source` | hidden |
| `crashes_dc_heatmap` | heatmap | `points-source` | hidden |

### Road Segment Styling

Lines are colored by `user_score` using a linear interpolation:

```javascript
'line-color': ['interpolate', ['linear'], ['get', 'user_score'],
  0,   '#CC3232',   // red   — dangerous
  50,  '#E7B416',   // amber — moderate
  100, '#2DC937'    // green — safe
]
```

Line width is fixed at 3px.

### Crash Point Styling

Individual points shown at zoom ≥ 15:
- `circle-radius: 4`, red fill, white stroke, 70% opacity

### Crash Heatmap Styling

Heatmap weight is driven by injury severity:
```javascript
'heatmap-weight': ['+', ['get', 'MAJORINJURIES_BICYCLIST'], ['*', ['get', 'FATAL_BICYCLIST'], 5]]
```
Fatalities are weighted 5× relative to major injuries. Opacity fades out at very high zoom (transitions to individual points).

---

## Scoring System

### Two Modes

**RideScore mode** (default): Uses the pre-computed `ridescore_v1` column directly by passing `i_ridescore=4` with all other weights set to `0`.

**Custom mode**: All six individual factor sliders are enabled. Each slider maps to a weight parameter (0–3 = Off/Low/Medium/High) sent as query params to the tile endpoint.

### Scoring Factors

| Slider | URL Param | PostGIS Column |
|---|---|---|
| Speed Limit | `i_speedlimit` | `speedlimit_score` |
| Number of Lanes | `i_numlanes` | `num_lanes_score` |
| Bike Lane Type | `i_facility` | `facility_score` |
| Road Type | `i_function` | `function_score` |
| Road Width | `i_roadwidth` | `road_width_score` |
| Pavement Condition | `i_pavement` | `pavement_condition_score` |

### Tile Refresh

When the user clicks "Update Map", `RefreshZone()` calls `source.setTiles()` with a new URL containing updated weights and a cache-busting timestamp:

```javascript
function RefreshZone(i_ridescore, i_speedlimit, ...) {
  const timestamp = Date.now();
  map.getSource('my-vector-source').setTiles([
    `http://localhost:3000/update_score/{z}/{x}/{y}?i_ridescore=${i_ridescore}&...&ts=${timestamp}`
  ]);
}
```

The `ts` parameter forces MapLibre to treat it as a new source and re-fetch all tiles, bypassing the tile cache.

---

## UI Components

### Controls (top-left)
- **Settings button** — toggles the scoring panel
- **Imagery toggle** — shows/hides the 2025 satellite layer
- **Accidents toggle** — shows/hides crash heatmap + points

### Settings Panel (top-left, collapsible)
- Mode switcher: "Use RideScore" vs "Custom"
- Six range sliders (0–3), disabled in RideScore mode
- Labels: Off / Low / Medium / High
- "Update Map" button triggers `RefreshZone()`

### Logo / Attribution (top-right)
- Clicking opens an attribution panel crediting DC Government data under CC-BY-4.0

### Popups (on click)

**Road segment click** — shows a table with:
- Safety Score, RideScore, LTS level, Bike Lane type
- Crash count (5yr), Speed Limit, Lanes, Road Width, Road Type, Pavement

**Crash point click** — shows a table with:
- Address, Date/time, Fatalities, Major/minor injuries
- Total bicycles, vehicles, pedestrians involved

Cursor changes to `pointer` on hover over either layer.

---

## Key Design Patterns

- **Tile URL as API call** — all scoring logic lives in the database function; the frontend only changes URL parameters. No REST API, no JSON payloads.
- **Cache-busting via timestamp** — `Date.now()` appended to tile URL forces a full re-fetch on every "Update Map" click without needing to destroy/recreate the source
- **`maxzoom: 14` on vector sources** — Martin serves tiles up to zoom 14; MapLibre overzooms above that, preventing redundant tile requests at street level
- **Dual crash layers** — the same `points-source` feeds both a heatmap (city-wide overview) and individual circles (street-level detail), toggled together

---

## Dependencies

| Dependency | Version | How loaded |
|---|---|---|
| MapLibre GL JS | 5.18.0 | CDN (`unpkg.com`) |
| MapLibre GL CSS | 5.18.0 | CDN (`unpkg.com`) |
| Inter font | — | Google Fonts |
| OpenFreeMap styles | — | Remote tile URL |

No npm, no build step. The file runs directly in a browser.

---

## Local Infrastructure Required

| Service | Port | Role |
|---|---|---|
| Martin tile server | 3000 | Serves `update_score` and `crashes_dc` MVT endpoints |
| PostGIS (Docker) | 5432 | Stores road segments and crash data |

Start with `docker compose up -d` from `mvp_map/`. See `mvp_map/docker-compose.yml`.
