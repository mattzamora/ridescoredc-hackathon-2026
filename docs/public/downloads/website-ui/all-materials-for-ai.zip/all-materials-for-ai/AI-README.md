# RideScore DC Hackathon — Website/UI track: all materials for AI

This folder is meant to be uploaded whole to an AI assistant. Everything is Markdown (plus one HTML mock-up and a few screenshots).

## Layout

- `guide/` — the public hackathon guide's Website/UI pages, copied from the guide site (https://mattzamora.github.io/ridescoredc-hackathon-2026/tracks/website-ui), written for the October 3, 2026 event.
  - `guide/website-ui.md` — track overview and glossary
  - `guide/website-ui/` — setting up, understanding the site, the guides (Front-End, Full Stack, Windows/WSL), how the site works, repository layout, the data, technical guides (making changes), submitting your work, and `topics.md`
  - `guide/website-ui/topics/` — all 13 topic pages
  - `guide/images/` — screenshots the topic pages refer to
- `background/` — design notes and analysis for Topics 2–6, one folder per topic, plus `background/README.md`.
  - `background/topic-03-survey-on-a-phone/survey_sample.html` is a standalone mock-up; open it in a browser.
  - `background/topic-05-fix-the-route-selector-bugs/route-selector-bugs-analysis.md` has tested reproduction steps and code-level causes for the selector bugs.

## How current it is

The guide pages and the background notes both describe the code as of website `develop` at commit 38386ee and models `develop` at commit ef0caea (October 2026). Each background section is labeled **Built**, **Partly built**, **Idea, not built** or **Historical plan**. Two notes in Topic 4 (`mvp-feedback-plan.md`, `paint-concept-notes.md`) are the original plans for paint mode, kept as historical context and marked where the built feature differs.

The code itself is the final word: https://github.com/civictechdc/ridescoredc-website (develop branch).

## Suggested first prompt

> I'm on Topic N of the RideScore DC hackathon Website/UI track. Read the guide page for Topic N (guide/website-ui/topics/) and its background notes if it has any (background/topic-0N-.../), plus guide/website-ui/setting-up.md. Then help me plan a 2–3 hour approach: what to build, which files to change, and what to hand in.

Topics 1 and 7–13 have no background notes; their topic pages and `how-the-site-works.md`, `the-data.md` and `repository-layout.md` cover the background.
