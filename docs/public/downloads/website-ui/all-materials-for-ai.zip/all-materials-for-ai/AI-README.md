# RideScore DC Hackathon — Website/UI track: all materials for AI

This folder is meant to be uploaded whole to an AI assistant. Everything is Markdown (plus one HTML mock-up).

## Layout

- `guide/` — the public hackathon guide's Website/UI pages, copied from the guide site (https://mattzamora.github.io/ridescoredc-hackathon-2026/tracks/website-ui). These are **current** (written for the October 3, 2026 event).
  - `guide/website-ui.md` — track overview
  - `guide/website-ui/` — setting up, understanding the site, the guides (Front-End, Full Stack, Windows/WSL), how the site works, repository layout, the data, making changes, doing the work, submitting your work, and `topics.md`
  - `guide/website-ui/topics/` — all 15 topic pages
- `background/` — older internal design notes for Topics 3–7, one folder per topic, plus `background/README.md`.
  - `background/topic-04-survey-on-a-phone/survey_sample.html` is a standalone mock-up; open it in a browser.
  - `background/topic-06-fix-the-route-selector-bugs/route-selector-bugs-analysis.md` is new and was checked against today's code.

## Which source wins

The background notes were mostly written around August 11, 2026, **before** the website repository was restructured on September 26, 2026. Each starts with a "What changed since this was written" box listing renamed files, tables and IDs. Their ideas are still useful, but names, paths and line numbers may be stale.

**The guide pages are current. If a background note and a guide page disagree, the guide page wins.** When in doubt, check the code: https://github.com/civictechdc/ridescoredc-website (develop branch).

## Suggested first prompt

> I'm on Topic N of the RideScore DC hackathon Website/UI track. Read the guide page for Topic N (guide/website-ui/topics/) and its background notes (background/topic-0N-.../), plus guide/website-ui/setting-up.md. Then help me plan a 2–3 hour approach: what to build, which files to change, and what to hand in.

Topics 1, 2 and 8–15 have no background notes; use the guide pages (for Topics 8 and 10, start with `the-data.md` and `repository-layout.md`).
