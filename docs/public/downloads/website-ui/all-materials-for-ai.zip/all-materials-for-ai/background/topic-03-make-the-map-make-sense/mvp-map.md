# The Map Page: How It Works

Describes the code as of website develop 38386ee and models develop ef0caea (October 2026).
A technical tour of the scored map at `/` (`frontend/index.html`), for anyone changing how the map looks or behaves.

---

## Overview

**Built.** The map is a plain HTML page, `frontend/index.html`, with no build step and no framework. It uses **MapLibre GL JS** to draw a bike-safety map of Washington, D.C. Road and crash tiles come from **Martin**, which reads them out of **PostGIS**. The page has two scoring modes (the precomputed RideScore, or a custom weighting) and two overlays (aerial imagery and crashes).

Code the map shares with the survey page lives in three plain scripts under `frontend/src/shared/`, loaded with `<script>` tags. They hang everything off one global object, `RideScore`:

| File | What it provides |
|---|---|
| `config.js` | `RideScore.config`: basemap style, start center and zoom, the aerial imagery URL, and `tiles(name)`, which builds `/tiles/<name>/{z}/{x}/{y}` on the page's own origin |
| `basemap.js` | `RideScore.createMap()`, `RideScore.addImagery()`, and the button handlers `toggleImagery()`, `toggleAccidents()`, `toggleAttribution()` |
| `crashes.js` | `RideScore.addCrashes()`: the crash source, both crash layers, and the crash popup |

The scored road layer is **not** shared. Only the map page loads it. The survey page leaves it out on purpose so respondents never see a score (see the survey notes in topic 04).

---

## Architecture

**Built.**

```
Browser (frontend/index.html, served by nginx or Vite)
   ├── MapLibre GL JS 5.18.0 (from unpkg)
   ├── /tiles/...  on the page's own origin  → Martin → PostGIS (serving schema only)
   │     ├── /tiles/update_score/{z}/{x}/{y}?i_ridescore=…   road segments (serving.update_score function)
   │     └── /tiles/crashes/{z}/{x}/{y}                      crash points (serving.crashes view)
   ├── OpenFreeMap "bright" style (basemap)
   └── DC GIS 2025 orthophoto tiles (raster, external)
```

Tiles are always requested at `/tiles/...` on whatever address served the page:

- **Full Stack setup** (`npm run stack`): nginx on `localhost:8000` serves `frontend/` straight from disk and forwards `/tiles/` to Martin and `/api/` to FastAPI (`nginx/default.conf`).
- **Front-End setup** (`npm run dev`): Vite on `localhost:5173` serves `frontend/` and proxies `/tiles` and `/api` to an upstream, by default `https://dev.ridescoredc.com` (`vite.config.js`).

So the same page works on your machine and on the servers without edits. Martin publishes only the `serving` schema (`martin.yaml`), never the raw `data` tables.

---

## Map initialization

**Built.** The page calls `RideScore.createMap('map')` (in `basemap.js`), which does this:

```javascript
const { style, center, zoom } = RideScore.config;
RideScore.map = new maplibregl.Map({ container: containerId, style, center, zoom });
```

`RideScore.config` sets `style` to `https://tiles.openfreemap.org/styles/bright` (no API key), `center` to `[-77.02515, 38.91668]` and `zoom` to `15`. All custom sources and layers are added inside `map.on('style.load', ...)` so the basemap is ready first.

---

## Data sources

### 1. Road segments: `update_score` (vector tiles)

**Built.**

```javascript
map.addSource('my-vector-source', {
  type: 'vector',
  tiles: [`${location.origin}/tiles/update_score/{z}/{x}/{y}?i_ridescore=4&i_speedlimit=0&i_numlanes=0&i_facility=0&i_function=0&i_roadwidth=0&i_pavement=0`],
  minzoom: 1, maxzoom: 14
});
```

Martin calls the PostgreSQL function `serving.update_score(z, x, y, query_params json)`, defined in the models repo at `serving/030_update_score.sql`. It joins `data.road_segment` to `data.ridescore_v1_scores` on `segment_id` and computes `user_score` per segment:

```sql
( s.ridescore_v1              * w_ridescore
+ s.speedlimit_score          * w_speedlimit
+ s.num_lanes_score           * w_numlanes
+ s.facility_score            * w_facility
+ s.function_score            * w_function
+ s.road_width_score          * w_roadwidth
+ s.pavement_condition_score  * w_pavement
) / NULLIF(w_total, 0) AS user_score
```

Each weight comes from a query parameter (`i_ridescore`, `i_speedlimit`, …) wrapped in `coalesce(..., 0)`, so a missing parameter counts as zero instead of blanking the map. If every weight is zero, `NULLIF` makes `user_score` null instead of raising a division-by-zero error.

The tile URL carries the weights, so changing them is just a new tile request. There is no separate API call.

**Properties on each feature** (source-layer `update_score`):

- `tile_id`, `segment_id`: the two identifiers (see "Identifiers" below)
- `user_score`: the weighted average of component scores, each on a 0–100 scale
- `route_name`, `bike_facility_type`, `function`, `num_lanes_raw`, `parking_presence`, `pavement_condition`, `road_width`, `speed_limit_raw`: from `data.road_segment`
- `lts_level`, `ridescore_v1`: from `data.ridescore_v1_scores`

### 2. Crash points: `crashes` (vector tiles)

**Built.** Added by `RideScore.addCrashes(map)` in `crashes.js`:

```javascript
map.addSource('crashes', {
  type: 'vector',
  tiles: [RideScore.config.tiles('crashes')],
  minzoom: 1,
  maxzoom: 14,
});
```

Martin auto-publishes the view `serving.crashes` (models repo, `serving/040_crashes.sql`), which selects from `data.crashes`. Columns: `report_date`, `address`, `major_injuries_bicyclist`, `minor_injuries_bicyclist`, `fatal_bicyclist`, `total_bicycles`, `total_vehicles`, `total_pedestrians`, `geometry`. It takes no parameters, so its tiles are cacheable.

The field names are lowercase pipeline names (`major_injuries_bicyclist`), not the city's published names (`MAJORINJURIES_BICYCLIST`). Using the old names returns nothing and fails silently.

### 3. Aerial imagery (raster tiles)

**Built.** Added by `RideScore.addImagery(map)` in `basemap.js` as source `dc-ortho-2025`, using the DC GIS 2025 orthophoto tile service (`RideScore.config.orthoTiles`), `tileSize: 256`. Hidden by default.

---

## Identifiers

**Built.** Every road feature carries two IDs that do different jobs:

| ID | Type | Use it for | Lasts |
|---|---|---|---|
| `segment_id` | text | Anything stored (survey answers, reports). It is the block's lasting identity. | Across data builds |
| `tile_id` | integer | MapLibre feature-state (`promoteId`) | One data build only. Never store it. |

The map page does not set `promoteId` on `my-vector-source` today, because it does not use feature-state. The survey page does (`promoteId: { 'survey_segments': 'tile_id' }`).

---

## Layers

**Built.**

| Layer id | Type | Source | Source-layer | Default |
|---|---|---|---|---|
| `ortho-2025-layer` | raster | `dc-ortho-2025` | — | hidden |
| `update_score` | line | `my-vector-source` | `update_score` | visible |
| `crashes` | circle | `crashes` | `crashes` | hidden (and only from zoom 15) |
| `crashes_heatmap` | heatmap | `crashes` | `crashes` | hidden |

### Road segment styling

Lines are colored by `user_score`:

```javascript
'line-color': ['interpolate', ['linear'], ['get', 'user_score'],
  0, '#CC3232', 50, '#E7B416', 100, '#2DC937'],
'line-width': 3
```

Red is low, amber middle, green high. A null `user_score` (all weights zero) has no defined color in this expression.

### Crash point styling

Individual points from zoom 15: `circle-radius: 4`, red fill `#CC3232`, white 2px stroke, 0.7 opacity.

### Crash heatmap styling

Every crash counts for something, and serious ones count for more:

```javascript
'heatmap-weight': [
  'interpolate', ['linear'],
  ['+', ['get', 'major_injuries_bicyclist'], ['*', ['get', 'fatal_bicyclist'], 5]],
  0, 0.15,
  5, 1,
],
```

A crash with no serious injury still weighs 0.15, because most crashes in the data injured nobody seriously and a pure severity weight would leave the layer nearly empty. A fatality counts 5 times a major injury, and 5 is the top of the ramp. Heatmap opacity rises from 0.2 to 1 between zoom 8 and 12, then fades to 0 by zoom 18, where the points take over.

---

## Scoring system

### Two modes

**Built.**

- **RideScore mode** (default): sends `i_ridescore=4` and every other weight `0`, so `user_score` equals `ridescore_v1`.
- **Custom mode**: enables the six factor sliders. Each is a range input from 0 to 3, labeled Off / Low / Medium / High (`LABELS` array), starting at 2 (Medium). `i_ridescore` is sent as `0`.

### Scoring factors

| Slider label | Input id / URL param | Column in `data.ridescore_v1_scores` |
|---|---|---|
| Speed Limit | `i_speedlimit` | `speedlimit_score` |
| Number of Lanes | `i_numlanes` | `num_lanes_score` |
| Bike Lane Type | `i_facility` | `facility_score` |
| Road Type | `i_function` | `function_score` |
| Road Width | `i_roadwidth` | `road_width_score` |
| Pavement Condition | `i_pavement` | `pavement_condition_score` |

### Tile refresh

**Built.** The **Update Map** button (`#updateBtn`) calls `RefreshZone()`, which swaps the tile URL on the existing source and adds a timestamp:

```javascript
function RefreshZone(i_ridescore, i_speedlimit, i_numlanes, i_facility, i_function, i_roadwidth, i_pavement) {
  const timestamp = Date.now();
  const source = map.getSource('my-vector-source');
  source.setTiles([`${location.origin}/tiles/update_score/{z}/{x}/{y}?i_ridescore=${i_ridescore}&...&ts=${timestamp}`]);
}
```

The `ts` parameter makes every URL new, so MapLibre fetches fresh tiles instead of reusing cached ones. Martin passes all query parameters to the function as JSON, and `serving.update_score` simply never reads `ts`.

Sliders do nothing until **Update Map** is pressed. Live updating on slider change is **Idea, not built**.

---

## UI components

### Controls (top left)

**Built.** Three buttons in `.controls`:

- **Settings** (`toggleSettings()`, in the page): opens the "Your Priority" panel.
- **Imagery** (`toggleImagery()`, in `basemap.js`): shows or hides `ortho-2025-layer`.
- **Accidents** (`toggleAccidents()`, in `basemap.js`): shows or hides both `crashes` and `crashes_heatmap` together.

The toggle buttons get an `active` class (green dot) when on.

### Settings panel (top left, collapsible)

**Built.** Mode switcher ("Use RideScore" / "Custom"), a note shown in RideScore mode, the six sliders (disabled in RideScore mode), and **Update Map**.

### Logo and attribution (top right)

**Built.** The "DC Bike Safety" button calls `toggleAttribution()`, which opens a panel crediting Washington, D.C. Government data under CC-BY-4.0.

### Popups (on click)

**Built, with one known gap.**

**Road segment** (`map.on('click', 'update_score', ...)` in the page): street name, then Safety Score (`user_score`), RideScore, LTS, Bike Lane, Crashes (5yr), Speed Limit, Lanes, Road Width, Road Type, Pavement.

Known gap: the popup reads `crash_count_5yr`, but `serving.update_score` does not select that column, so "Crashes (5yr)" shows `undefined`. The column exists on `data.road_segment`; fixing it means adding `g.crash_count_5yr` to the function's `SELECT` in the models repo's `serving/030_update_score.sql`.

**Crash point** (`map.on('click', 'crashes', ...)` in `crashes.js`): Date, Address, Bicyclist fatalities, Serious injuries, Minor injuries. The view also carries `total_bicycles`, `total_vehicles` and `total_pedestrians`, but the popup does not show them.

The cursor becomes a pointer over either layer.

---

## Key design patterns

**Built.**

- **Tile URL as the API.** Scoring lives in a database function. The page only changes URL parameters. No JSON endpoint is involved in drawing the map.
- **Same-origin tiles.** `/tiles/...` on the page's own address, so nginx (Full Stack) or Vite (Front-End) decides where tiles come from. Nothing in the page changes between environments.
- **Cache-busting with a timestamp** on every Update Map, without destroying and recreating the source.
- **`maxzoom: 14` on vector sources.** MapLibre overzooms above 14 instead of requesting more tiles.
- **Two crash layers on one source**: heatmap for the city view, circles at street level, toggled together.
- **Scores only where they belong.** The scored source is added in `frontend/index.html`, not in a shared file, so the survey page cannot pick it up by accident.

---

## Dependencies

| Dependency | Version | How loaded |
|---|---|---|
| MapLibre GL JS + CSS | 5.18.0 | `<script>` / `<link>` from `unpkg.com` |
| Inter font | — | Google Fonts `@import` |
| OpenFreeMap "bright" style | — | Remote style URL |
| Shared scripts | — | `/src/shared/config.js`, `basemap.js`, `crashes.js` |

No npm packages at runtime and no build step. Vite (`package.json` devDependency) is only a development server; production serves `frontend/` as is.

---

## Running it locally

**Built.** Two ways (details in the Front-End and Full Stack guides):

| Setup | Command | Address | Tiles and API come from |
|---|---|---|---|
| Front-End | `npm run dev` | `http://localhost:5173` | the upstream in `vite.config.js` (default `https://dev.ridescoredc.com`) |
| Full Stack | `npm run stack`, then `npm run setup` once | `http://localhost:8000` | your own Docker stack |

The Full Stack setup is `docker-compose.yml` at the root of the website repo: `nginx` (published on port 8000), `fastapi` and `martin` (internal only, reached through nginx), and `db` (PostGIS 17, published on `DB_PORT`, default 5432). `npm run setup` runs `npm run data` (loads the road data) then `npm run migrate` (creates the survey tables). Database credentials live in `api/.env` (see the Full Stack guide).
