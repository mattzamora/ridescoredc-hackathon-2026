# Website/UI track — background pack (Topics 3–7)

RideScore DC Hackathon, Saturday October 3, 2026.

This pack holds design notes and analysis for the Intermediate topics 3–7 of the Website/UI track. It's intended more for use with an AI assistant, for rapid comprehension of a topic: the topic pages on the hackathon site tell you what to do; these notes explain how the code works today, what was tried, and why.

Each document comes twice: a `.md` (Markdown) file and a `.docx` (Word) copy. The Topic 4 folder also has `survey_sample.html`, a standalone mock-up you can open in any browser.

## How current these notes are

Every note describes the code as of **website `develop` at commit 38386ee** and **models `develop` at commit ef0caea** (October 2026), and was checked against that code. Each section starts with a status:

- **Built** — in today's code, as described.
- **Partly built** — some of it exists; the note says which part.
- **Idea, not built** — a proposal you're free to pick up.
- **Historical plan** — the original plan for a feature that now exists, kept because it explains why the feature works the way it does.

Function names are reliable; line numbers are approximate and drift as people edit, so search for the function name.

## What's in it

| Topic | File | Why it's useful |
|---|---|---|
| 3. Make the map make sense | `topic-03-make-the-map-make-sense/mvp-map.md` | How the map page is built today: shared scripts, tile sources, layers, score colors, the Custom sliders and popups. |
| 3. Make the map make sense | `topic-03-make-the-map-make-sense/map-events-and-feedback-mechanism.md` | MapLibre click and hover events, feature-state highlighting, and how selection was built on the survey page. |
| 4. A survey that works on a phone | `topic-04-survey-on-a-phone/survey-per-segment-plan.md` | The per-segment bottom-sheet survey: its questions, the route sequencer, and what each submission stores. |
| 4. A survey that works on a phone | `topic-04-survey-on-a-phone/survey_sample.html` | Standalone bottom-sheet mock-up; open it in a phone-sized browser window. |
| 5. Rethink route drawing | `topic-05-rethink-route-drawing/paint-route-editing-roadmap.md` | Ideas for draggable-junction editing and other ways to correct a route. |
| 5. Rethink route drawing | `topic-05-rethink-route-drawing/route-snapper-audit-and-ridescore-recommendations.md` | How the route_snapper library's graph-based snapping differs from today's tile painting, with recommendations. |
| 5. Rethink route drawing | `topic-05-rethink-route-drawing/mvp-feedback-plan.md` | Historical context: the original build plan for paint mode, marked where today's code differs. |
| 5. Rethink route drawing | `topic-05-rethink-route-drawing/paint-concept-notes.md` | Historical context: the original intent and acceptance criteria for paint mode. |
| 6. Fix the route-selector bugs | `topic-06-fix-the-route-selector-bugs/route-selector-bugs-analysis.md` | Three tested selector bugs traced to specific functions, with reproduction steps, test results and fix ideas. |
| 6. Fix the route-selector bugs | `topic-06-fix-the-route-selector-bugs/snap-intersection-problem.md` | Approaches to the wrong-street-at-intersections problem, each marked built or not. |
| 7. Riders report hazards | `topic-07-riders-report-hazards/database-migrations.md` | How the database and migrations work today, and the steps to add a new table such as hazard reports. |
| 7. Riders report hazards | `topic-07-riders-report-hazards/nearmiss-dynamic-surveys.md` | External reference: a JSON-driven survey engine from another app (NearMiss), and how it could map onto RideScore DC. |

## How to use with AI tools

Give the `.md` files to your AI assistant (attach them or paste them in). Markdown keeps headings, tables and code blocks intact, so the assistant reads the structure correctly. The `.docx` copies are for reading or printing; diagrams and some formatting are simplified in them.

A good first prompt: "I'm working on Topic N of the RideScore DC hackathon Website/UI track. Read these background notes and the topic page, then help me plan a 2–3 hour approach."

For everything at once (all guide pages plus these notes), download `all-materials-for-ai.zip` from the track overview page.

## Other topics

Topics 3–7 have a pack. For the others, the topic pages and these guide pages cover the background:

- [How the site works](https://mattzamora.github.io/ridescoredc-hackathon-2026/tracks/website-ui/how-the-site-works)
- [The data](https://mattzamora.github.io/ridescoredc-hackathon-2026/tracks/website-ui/the-data)
- [Repository layout](https://mattzamora.github.io/ridescoredc-hackathon-2026/tracks/website-ui/repository-layout)

## Not included

Database dumps, server setup notes and personal messages are deliberately left out. route_snapper is a public library at https://github.com/dabreegster/route_snapper.
