# How the Database and Migrations Work Today

Describes the code as of website develop 38386ee and models develop ef0caea (October 2026).
Who writes which part of the database, how road data and app tables each change, and what adding a new table (for example hazard reports) involves end to end.

---

## The three schemas

**Built.** One PostGIS database holds three schemas. Each has one owner, and the split exists so that reloading the road data can never touch what users have submitted.

| Schema | Holds | Written by | Changed how |
|---|---|---|---|
| `data` | Road and crash data: `data.road_segment`, `data.ridescore_v1_scores`, `data.crashes`, and `data.load_record` (which package is loaded) | The loader from the models repo (`scripts/load_package.py`), run by the website's `scripts/load_data.py` | Dropped and rebuilt wholesale on every load. No migrations. |
| `serving` | What the map may show: `serving.survey_segments` (view), `serving.update_score` (tile function), `serving.crashes` (view) | The same loader, applying the **serving bundle** built from the models repo's `serving/*.sql` | Re-applied on every load, after `data` |
| `app` | What users create: `app.survey_submissions`, `app.survey_contiguous_segments`, `app.survey_granular_segments` | The website's API (`api/main.py`) | Numbered yoyo migrations in `api/migrations/` |

Martin (the tile server) publishes **only** `serving` (`martin.yaml`, `auto_publish` from schema `serving`, tables and functions). It never exposes `data` or `app` directly, so raw columns, scores the survey must not show, and user responses stay off the open internet unless a `serving` object chooses to show them.

```mermaid
flowchart LR
  P["Data package<br/>(Parquet)"] --> L["npm run data<br/>scripts/load_data.py"]
  B["Serving bundle<br/>(SQL)"] --> L
  L --> D[("data schema")]
  L --> S[("serving schema")]
  M["npm run migrate<br/>scripts/migrate.py"] --> A[("app schema")]
  API["api/main.py<br/>POST /api/submissions"] --> A
  S --> T["Martin<br/>/tiles/..."]
  D -. read by .-> S
```

---

## How road data arrives

**Built.**

The models repo publishes two files per release on its GitHub Releases page (`https://github.com/civictechdc/ridescoredc-models/releases`):

- a **data package**, `ridescoredc-data-preview.tar.gz`: Parquet files for `road_segment`, `crashes` and `ridescore_v1_scores`;
- a **serving bundle**, `ridescoredc-bundle-preview.tar.gz`: the SQL that defines the `serving` schema (from the models repo's `serving/010_schema.sql`, `020_survey_segments.sql`, `030_update_score.sql`, `040_crashes.sql`).

They are versioned separately, so changing what the map shows does not mean republishing the data. Where they come from is set in `scripts/data_source.py` (overridable in `.env`).

`npm run data` runs `scripts/load_data.py`, which fetches and runs the models repo's loader. The loader:

1. Creates schema `data` and table `data.load_record` if missing, then empties `data.load_record`.
2. For each dataset: `DROP TABLE IF EXISTS data.<name> CASCADE`, recreates it from the Parquet file, converts geometry to SRID 4326 and adds a spatial index. The `CASCADE` also drops the `serving` objects that read the table.
3. Records each dataset, its row count, the package and bundle names and their SHA-256 in `data.load_record`.
4. Applies every SQL file in the bundle, recreating `serving`.
5. Prints how many `app.survey_contiguous_segments` rows match none of the loaded segments.

It never writes to `app`. Afterwards `load_data.py` restarts the `martin` container if it is running, because Martin reads the database catalog only at startup.

Options: `--version 0.1` for a particular release, `--package DIR --bundle DIR` for local builds, `--database URL` for another database.

The API uses `data.load_record` too: every submission stores the loaded package name (for example `ridescoredc-data-preview@0.1`) in `geometry_source`, and the API returns 503 if no road data is loaded.

Road data has **no migration history**, on purpose: it is derived, so it is replaced, not altered. To change a column or a scoring rule, change the models repo and publish a new package or bundle.

> The models repo's `live/` folder is an older yoyo setup that loaded a full database dump. Today's site does not use it.

---

## How app tables change: migrations

**Built.**

The `app` schema is changed only by numbered SQL files in `api/migrations/`, applied by **yoyo-migrations**. Today there is one: `0001_app_schema.sql`, which creates the three survey tables and their indexes.

| Command | What it does |
|---|---|
| `npm run migrate` | `scripts/migrate.py`: applies every migration not yet applied |
| `npm run migrate:list` | Shows what has and has not been applied |
| `npm run migrate -- --rollback` | Undoes the most recent one |
| `npm run setup` | `npm run data`, then `npm run migrate` |

How it works (`scripts/migrate.py`, `api/yoyo.ini`):

- `migrate.py` runs yoyo through `uvx` (yoyo-migrations 9.0.0 with psycopg 3), so nothing needs installing beyond `uv`.
- yoyo picks its database driver from the URL scheme, so `migrate.py` passes a `postgresql+psycopg://` address. psql and Martin use the plain `postgres://` form of the same address.
- yoyo records what it applied in `_yoyo_migration_app` (set in `api/yoyo.ini`), not the default table name, because two repositories write to one database.
- Running it twice does nothing. It waits up to 90 seconds for the database to come up.
- Database credentials come from `api/.env` (see the Full Stack guide).

**Where migrations run:**

- **Your machine:** `npm run migrate`.
- **CI** (`.github/workflows/ci.yml`, job `check-migrations`): applies all migrations to an empty PostGIS 17 database, checks that the three survey tables exist, then applies again to prove the second run changes nothing.
- **Deploy:** merging to `develop` deploys to `dev.ridescoredc.com`, and merging to `main` deploys to `ridescoredc.com`. Each deploy applies pending migrations **before** restarting the API and the tile server. If a migration fails, the deploy stops and the old code keeps running against the old schema.

**Rules:**

- **Never edit a migration that has been applied anywhere**: your machine, a teammate's, staging or production. yoyo only knows that a file ran, not that it changed. Write a new migration instead.
- **Number the next file after the last one**: `0002_short_description.sql`.
- **Destructive changes take two deploys.** A deploy migrates first and then restarts the code, so for a moment the old code runs against the new schema. Expand first (add the new column, write both, read the new one), then remove the old column in a later deploy.
- **No foreign keys into `data`.** Those tables are dropped on every load, which a foreign key would block. Refer to roads by `segment_id` value (text), never by `tile_id`, which changes every build.
- `api/migrations-legacy/` holds SQL that was applied by hand before yoyo. It is a record only; nothing applies it.

---

## Adding a new table end to end: hazard reports

**Idea, not built.** No hazard report table, endpoint or layer exists yet. This is the path the current code supports, in order.

### 1. Write a migration

Create `api/migrations/0002_hazard_reports.sql`. A sketch, not a decided design:

```sql
CREATE TABLE app.hazard_reports (
    report_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reported_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    hazard_type      VARCHAR(40) NOT NULL,
    description      TEXT,
    location         geometry(Point, 4326) NOT NULL,
    segment_id       TEXT,           -- nearest road block, by value; no foreign key
    geometry_source  TEXT            -- which road data segment_id refers to
);

CREATE INDEX idx_hazard_reports_location ON app.hazard_reports USING gist (location);
```

Then run `npm run migrate` and `npm run migrate:list`. Optionally add `0002_hazard_reports.rollback.sql` (yoyo's naming for a rollback step) so `npm run migrate -- --rollback` can undo it while it exists only on your machine.

Follow the survey tables' lead: store `segment_id` (text) and `geometry_source`, never `tile_id`; no foreign key into `data`.

### 2. Add a Pydantic model and an endpoint in `api/main.py`

Follow `SurveySubmission` and `create_submission()`:

- A request model, for example `HazardReport(BaseModel)` with `hazard_type: str`, `description: Optional[str] = None`, `lng: float`, `lat: float`, `segment_id: Optional[str] = None`.
- A route such as `@app.post("/api/hazards", status_code=201)` that inserts with `get_conn()` and a parameterized `INSERT INTO app.hazard_reports ...` (use `ST_SetSRID(ST_MakePoint(%s, %s), 4326)` for the point), and fills `geometry_source` by calling the existing `geometry_source(cur)` helper.
- A test in `api/tests/test_api.py` next to the submission tests.

Any path under `/api/` reaches the API with no other change: nginx forwards `/api/` to FastAPI (`nginx/default.conf`) and Vite proxies `/api` (`vite.config.js`).

### 3. Optional: show reports on the map

Two ways, with different trade-offs:

- **A `serving` view, published by Martin as tiles.** For example `serving.hazard_reports` selecting only the columns the map should show. Today every `serving` object comes from the models repo's bundle, applied by `npm run data`. Putting this view there keeps that rule, but the bundle would then depend on an `app` table, and `npm run setup` runs `data` before `migrate`, so the view would fail on a fresh database. Creating it in a website migration instead avoids that order problem but breaks the "`serving` comes from the bundle" rule. The team should decide which. Either way, Martin must be restarted to see a new object (locally `docker compose restart martin`; a deploy restarts it).
- **A JSON endpoint in the API**, for example `GET /api/hazards` returning GeoJSON, added as a MapLibre `geojson` source. No Martin or `serving` change. Fine while the number of reports is small.

Whichever is chosen, anything published is public. Decide which fields are safe to show (free-text descriptions may contain personal details) and whether reports need review before they appear.

### 4. Ship it

Open a pull request into `develop`. CI lints, runs the tests and applies the migrations to an empty database twice. Merging deploys to staging, which applies `0002_hazard_reports.sql` before restarting the services.
