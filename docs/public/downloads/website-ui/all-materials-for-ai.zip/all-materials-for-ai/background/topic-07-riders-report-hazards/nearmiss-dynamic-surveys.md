# Dynamic Surveys from JSON: the NearMiss Example

Describes the code as of website develop 38386ee and models develop ef0caea (October 2026).
An idea source for making RideScore DC's survey (or a hazard report form) data-driven, using another app's design as the example.

> **External reference:** this describes the NearMiss app, not RideScore DC. It's included as an example of a JSON-driven survey engine; we haven't verified it against NearMiss's current code. The NearMiss source is not included in this pack.
>
> Status labels below say whether RideScore DC has the feature. Sections 1–9 describe NearMiss, so they are **Idea, not built** for RideScore DC unless marked otherwise. The last section maps the ideas onto today's RideScore DC code.

---

## Overview

**Idea, not built** (in RideScore DC). The NearMiss app implements a JSON-driven survey engine in **SvelteKit 2 / Svelte 5**. Survey structure is entirely data-defined — adding or modifying a survey requires only editing a JSON file, no code changes.

---

## 1. JSON Schema Structure

**Idea, not built** (in RideScore DC). Surveys live in `src/lib/data/` as plain JSON files (`nvfssSurvey.json`, `wabaSurvey.json`, `surveyAllOnePage.json`). The schema is three levels deep:

```
Survey
  └── pages[]
        └── questions[]
              ├── legend       — field label
              ├── key          — form field name (also URL param key)
              ├── type         — "checkbox" | "radio" | "textarea" | "date" | "geospatial"
              ├── required     — boolean validation flag
              ├── choices[]    — options for radio/checkbox
              └── description  — array of help text strings
```

The `type` field is the discriminator that drives the entire rendering pipeline.

**Example question definition:**
```json
{
  "legend": "What are you reporting?",
  "key": "report types",
  "description": ["Check all that apply"],
  "required": true,
  "type": "checkbox",
  "choices": ["Near Miss", "Dangerous Location"]
}
```

---

## 2. Rendering Pipeline

**Idea, not built** (in RideScore DC).

```
JSON file
   ↓  imported at route load
Survey object (typed via types.ts)
   ↓  passed as prop
SurveyForm.svelte  (multi-page orchestrator)
   ↓  iterates survey.pages[currentPage].questions
FieldSet.svelte  (per-question dispatcher)
   ↓  switches on question.type
CheckboxInput | RadioInput | TextAreaInput | DateTimeInput | GeospatialInput
```

**FieldSet** is the critical dispatch layer — a thin `{#if}` chain on `question.type` that hands the `Question` object down to the correct leaf component. Each leaf component is self-contained and knows nothing about the survey structure above it.

### TypeScript Types (`src/lib/types.ts`)

```typescript
type Question = {
  legend: string
  key: string
  description: string[]
  required?: boolean
  choices?: string[]
  type: string   // "checkbox" | "radio" | "textarea" | "date" | "geospatial"
}

type SurveyPage = {
  title: string
  description?: string
  questions?: Question[]
}

type Survey = {
  id: number | string
  title: string
  pages: SurveyPage[]
}

type SurveyAnswer = {
  survey_id: number | string
  report_id: number | string
  answer_string: string       // JSON stringified form data
  last_page_viewed: number
  submitted: boolean
}
```

---

## 3. State Management — Two-Layer Persistence

**Idea, not built** (in RideScore DC). Every input component syncs its value to **two places simultaneously**:

| Layer | Mechanism | Purpose |
|---|---|---|
| URL search params | `page.url.searchParams.set/append(key, value)` | Shareable links, page refresh survival |
| IndexedDB (Dexie) | `updateSurveyAnswerText(JSON.stringify(formObj), answer)` | Cross-session persistence, offline |

On mount, components read initial values from URL params — meaning a partially filled survey can be resumed just by revisiting the URL. Multi-select fields (checkbox) use `searchParams.append` to store repeated keys.

**IndexedDB schema (`src/lib/db.ts`):**
```typescript
const db = new Dexie('NearMissLocal') as Dexie & {
  reports: EntityTable<Report, 'id'>,
  surveyAnswers: Table<SurveyAnswer, '[report_id+survey_id]'>
};

db.version(1).stores({
  reports: '++id, date, position, inserted_at, updated_at',
  surveyAnswers: '[report_id+survey_id], submitted, report_id, survey_id'
});
```

The `answer_string` field stores the full form data as a JSON blob — capturing all keys including multi-valued checkboxes.

---

## 4. Form Data Collection & Serialization

**Idea, not built** (in RideScore DC). On every page transition, `SurveyForm` collects the entire `<form>` via the `FormData` API and merges it into a single object:

```typescript
const formObj = Object.fromEntries(
  [...formData.keys()].map((key) => [key, [...new Set(formData.getAll(key))]])
);
updateSurveyAnswerText(JSON.stringify(formObj), surveyAnswer);
```

`FormData.getAll()` handles checkbox multi-select correctly. `Set` deduplication prevents duplicate entries on repeated saves.

**Serialized format stored in IndexedDB:**
```json
{
  "report types": ["Near Miss", "Dangerous Location"],
  "reporting": ["Driver"],
  "description": "Incident description text",
  "location": "-77.357, 38.9586",
  "date": "2024-01-15T14:30"
}
```

---

## 5. Special Question Type: Geospatial

**Idea, not built** (in RideScore DC). The `geospatial` type renders a full **MapLibre GL** map with a click-to-place marker. It stores coordinates as a URL param string (`"-77.357, 38.9586"`) and as GeoJSON features internally.

A utility function in `src/lib/surveyutils.ts` scans the schema to find all question keys of a given type, then pre-populates them from the report's known position at load time:

```typescript
function keysForQuestionType(survey: Survey, type: string): string[] {
  let keys: string[] = []
  survey.pages.forEach((page) => page.questions?.forEach((question) => {
    if (question.type === type) keys = [...keys, question.key]
  }))
  return keys
}

// Usage at route load:
const geoKeys = keysForQuestionType(survey, 'geospatial');
geoKeys.forEach((key) => {
  page.url.searchParams.set(key, `${report.position[0]}, ${report.position[1]}`);
});

const dateKeys = keysForQuestionType(survey, 'date');
dateKeys.forEach((key) => {
  page.url.searchParams.set(key, dateToDatetimeLocalString(report.date));
});
```

---

## 6. Validation

**Partly built** (in RideScore DC). The RideScore survey checks its three required summary questions in `validateSummary()`, which marks missing answers and scrolls to the first, but the rules are hand-written, not read from a schema. Below is how NearMiss does it.

- **Per-field:** Each input component derives an `invalid` boolean (`$derived(required && group.length === 0)`) and sets the HTML5 `required` attribute conditionally, enabling native browser constraint validation
- **Per-page:** On "Next", `SurveyForm` collects all invalid `<input>` elements from the DOM before allowing navigation
- **UX:** `ErrorFields.svelte` renders a sticky error banner with count; scrolls to the first invalid field

---

## 7. Multi-page Navigation & Resumption

**Idea, not built** (in RideScore DC). `SurveyForm` tracks `currentPage` (1-indexed). `last_page_viewed` is persisted to IndexedDB on each page transition. On reload, `getOrCreateSurveyAnswer()` is idempotent — it returns the existing record if present and pre-populates URL params from the stored `answer_string`, enabling full form resumption.

**Report creation flow:**
```
1. User creates report (with geolocation)
   → createReport(date, position) → IndexedDB.reports

2. User navigates to /reports/[id]
   → getOrCreateSurveyAnswer(survey.id, report.id)
   → Pre-populate URL params from saved answer_string

3. SurveyForm mounts, user fills out pages
   → Each page nav: updateSurveyAnswerText() saves to DB
   → last_page_viewed tracked for resumption

4. Final page submit
   → updateSurveyAnswerSubmitted(true, surveyAnswer)
   → Optional POST to backend API
```

---

## 8. API Integration (`src/lib/api.ts`)

**Idea, not built** (in RideScore DC).

| Endpoint | Method | Purpose |
|---|---|---|
| `/v1/anonymous` | POST | Register anonymous user |
| `/v1/anonymous/otp` | POST | Generate one-time password |
| `/v1/reports` | POST | Submit report with survey answers |
| `/v1/reports` | DELETE | Delete report (OTP verified) |

Submission is optional — the app is fully functional offline with IndexedDB as the source of truth.

---

## 9. Stack

**Idea, not built** (in RideScore DC). This is NearMiss's stack; RideScore DC pages are plain HTML and JavaScript with no build step.

| Concern | Technology |
|---|---|
| Framework | SvelteKit 2 / Svelte 5 |
| Reactivity | `$state`, `$derived`, `bind:` |
| Styling | Tailwind CSS 4 + @tailwindcss/forms |
| Mapping | MapLibre GL 5 |
| Local DB | Dexie 4 (IndexedDB) |
| Types | TypeScript 5 |
| Build | Vite 6 |

---

## Key Design Decisions

**Idea, not built** (in RideScore DC).

- **JSON as schema, not config** — the entire survey structure (pages, ordering, question types, choices) is expressed in JSON, making it editable without code changes
- **`key` doubles as URL param name** — the question's `key` field is used directly as the URL search parameter key, coupling the schema to state management with no additional mapping layer
- **No central store** — state lives in URL params (ephemeral) and IndexedDB (persistent); no Svelte store layer
- **Leaf components are stateless** — each input reads from and writes to URL params; `SurveyForm` owns the lifecycle and persistence logic
- **Idempotent DB operations** — `getOrCreateSurveyAnswer()` ensures no duplicate records and enables safe re-entry

---

## File Reference

These paths are inside the NearMiss repository, not RideScore DC.

| File | Role |
|---|---|
| `src/lib/data/nvfssSurvey.json` | 4-page near-miss survey schema |
| `src/lib/data/wabaSurvey.json` | Crash tracker survey schema |
| `src/lib/data/surveyAllOnePage.json` | Single-page condensed variant |
| `src/lib/types.ts` | TypeScript interfaces (Survey, Question, SurveyAnswer) |
| `src/lib/surveyutils.ts` | `keysForQuestionType()` and helpers |
| `src/lib/db.ts` | Dexie IndexedDB schema and CRUD operations |
| `src/lib/api.ts` | Backend API client |
| `src/lib/components/forms/SurveyForm.svelte` | Multi-page form orchestrator |
| `src/lib/components/forms/elements/FieldSet.svelte` | Question type dispatcher |
| `src/lib/components/forms/elements/CheckboxInput.svelte` | Multi-select input |
| `src/lib/components/forms/elements/RadioInput.svelte` | Single-select input |
| `src/lib/components/forms/elements/TextAreaInput.svelte` | Free text input |
| `src/lib/components/forms/elements/DateTimeInput.svelte` | Date/time picker |
| `src/lib/components/forms/elements/GeospatialInput.svelte` | MapLibre map picker |
| `src/routes/reports/[slug]/+page.svelte` | Survey form route |
| `src/routes/reports/[slug]/+page.ts` | Route data loader |

---

## How this could map onto RideScore DC today

**Idea, not built.** RideScore DC's survey is not JSON-driven. This section says where things live now and what a JSON-driven version (or a hazard report form built the same way) would have to touch.

### Where the questions are defined today

Everything is in one file, `frontend/survey/index.html`, as hand-written HTML and JavaScript. There is no framework and no build step, so a schema renderer would be plain JavaScript in that page (or a new file in `frontend/src/shared/` if the map page should use it too).

| Part of the survey | Where it is defined |
|---|---|
| Perceived LTS (1–4) | Buttons in `#ss-lts-row`, handler `setSegLts()`; explanations in `#ss-lts-info-panel` |
| Safety (1–10) | Buttons in `#ss-safety-row`, handler `setSegSafety()` |
| Stress factors (shown for LTS 3–4) | The `STRESS_FACTORS` array, drawn by `renderStressFactors()`, shown or hidden by `updateStressFactorsVisibility()` |
| Summary: time of day, satisfaction, ride again | Blocks `#ss-req-time`, `#ss-req-sat`, `#ss-req-again` in `#ss-summary`; handlers `setSumTime()`, `setSumSat()`, `setSumAgain()`; required check in `validateSummary()` |
| Summary: comments | `#ss-comments` textarea (500 characters) |
| Answers in memory | `surveyAnswers` (one object per street run) and `sumTime`, `sumSat`, `sumRideAgain`, `sumTripPurpose` |
| Building the request | `submitSurvey()`, which POSTs to `/api/submissions` |

Answers are only in memory: closing or reloading the page loses them. NearMiss's IndexedDB drafts (section 3) would be new.

The closest thing to NearMiss's `keysForQuestionType` geospatial pre-fill is the painted route itself: the survey is already tied to the `segment_id`s of what the rider painted.

### What the API accepts today

`api/main.py` defines two Pydantic models with fixed fields:

| Model | Fields |
|---|---|
| `SurveySubmission` | `segment_ids: List[str]`, `contiguous_segments: List[ContiguousSegment]`, and optional `time_of_day: str`, `overall_satisfaction: int`, `would_ride_again: str`, `trip_purpose: str`, `comments: str` |
| `ContiguousSegment` | `sequence_index: int`, `route_name: Optional[str]`, `segment_ids: List[str]`, and optional `lts_perceived: int`, `safety_rating: int`, `stress_factors: List[str]` |

`create_submission()` inserts each field into a matching column. Pydantic ignores fields it does not know, so a new question sent from the page **is silently dropped** until it is added to a model and to the `INSERT`.

### What the database would need

The answers live in fixed columns of `app.survey_submissions` and `app.survey_contiguous_segments` (`api/migrations/0001_app_schema.sql`). Two ways forward, both needing a new numbered migration (`api/migrations/0002_...sql`, applied with `npm run migrate`; never edit `0001`):

- **One column per question** (today's pattern). Simple to query and to constrain with `CHECK`, but every new question needs a migration, a Pydantic field and an `INSERT` change.
- **A JSON column** (closer to NearMiss's `answer_string`). For example an `answers JSONB` column on each table plus a `survey_version TEXT` naming the schema the answers came from. New questions then need only a new JSON definition, but the database no longer checks the values, and analysis has to read JSON.

A mix is also possible: keep the core ratings (`lts_perceived`, `safety_rating`) as columns and put extra or experimental questions in JSON.

### For hazard reports

A NearMiss-style report (a point on the map plus a few questions) fits a new table better than the survey tables, because it is about a spot, not a painted route. See `database-migrations.md` in this folder for the end-to-end path: a migration for `app.hazard_reports`, a Pydantic model and endpoint in `api/main.py`, and an optional way to show reports on the map. Store `segment_id` (text) if a report is tied to a road, never `tile_id`.
