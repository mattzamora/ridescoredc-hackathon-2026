# The intersection snap problem: approaches and what was built

Describes the code as of website develop 38386ee (October 2026).
Lays out why snapping a painted stroke to the right street at an intersection is hard, the approaches considered, and which of them the survey page uses today.

> Code: paint mode in `frontend/survey/index.html` (the survey, served at `/survey/`). The map layers involved are on source `segments`, source-layer `survey_segments`: `road-score` (the grey road lines that snapping queries) and `road-selected` (the blue and light-blue highlight). Selected blocks are tracked by `tile_id`; answers are stored by `segment_id`. For live test results and reproduction steps, see `route-selector-bugs-analysis.md` in this folder.

---

## How snapping works today

**Built.**

- While painting, every pointer sample goes into `paintPoints`, and `updateMomentum` keeps a smoothed stroke direction (`MOMENTUM_SMOOTH` = 0.25, measured over the last 10 samples, only once they span at least `MIN_MOVE` = 12 px).
- At most every 50 ms, `enqueuePaintSnap` calls `findBestCandidate`. It queries `road-score` within `SNAP_RADIUS` = 40 px of the pointer and scores every edge as `dist × penalty × contMult`, where `penalty` runs from 1 (edge aligned with the stroke) to `PERP_PENALTY` = 3.5 (perpendicular), `contMult` is 0.58 for edges touching the last committed edge, and blocks already selected are multiplied by `AVOID_REVISIT_MULT` = 1.14. The lowest score wins.
- The winner goes onto `snapQueue` and is shown light blue (`pending` feature-state). It is not committed yet.
- `tryDrainSnapQueue` commits the oldest queued pick once 8 picks are queued (`COMMIT_LAG`), but only if the stroke's later direction lines up with the picked edge (`COMMIT_ALIGN_THRESHOLD` = 0.38). Otherwise the pick is dropped.
- On lift, `finishStrokePipeline` flushes the queue with a looser check (`flushSnapQueueRelaxed`, 0.22; items with no measurable later direction are committed), then `pruneSelectionsFarFromRawPolyline` removes blocks added this stroke that sit more than `OUTLIER_PRUNE_PX` = 62 px from the stroke (resampled by `resampleUniform` at 10 px).
- Corrections: **Undo** (`undoLastSegment`, also Ctrl/Cmd+Z), **Undo stroke** (`undoLastPaintStroke`), **Clear** (`clearSelection`), click a blue block with paint mode off (`removeSegmentSelection`), and **Unpaint** mode (`toggleUnpaintMode`, `eraseNearPaintPoint`).

---

## Why the problem persists

**Still true of today's code.**

The direction penalty is applied at the moment of each snap query, and **that decision is made at the worst possible moment.** When the pointer is at the intersection itself, the stroke direction is ambiguous. At that instant:

- All the streets meeting there are at almost the same pixel distance, close to 0.
- The momentum points into the intersection, not along either street.
- Because the penalty multiplies the distance, a distance near 0 makes the penalty nearly irrelevant.

Any approach that tries to decide *at the intersection* fights this ambiguity. The more productive framing is to **defer or revise the decision using information that only arrives after the pointer has moved past the intersection.** Today's lookahead does this mid-stroke, which is why straight-through strokes usually come out right. At the **end** of a stroke there is no "after," and the last picks are committed without a direction check; live testing found that stopping on an intersection picks the cross street about 5 times in 8.

---

## Approach 1: historical revision (retroactive correction)

**Partly built.** The lookahead queue (Approach 3) does the core of this: it holds picks and drops ones that contradict the later direction. What is not built is revising picks that were already committed, or a "suspect" flag on picks flanked by good ones.

### Concept

Don't commit a block at snap time. Keep a **pending buffer** of recent picks. As new samples come in, look back and ask whether the current direction of travel contradicts a recent pick. If it does, revise it.

```
Stroke:  A → B → C → D  (points over time)

At C, the snap grabs a perpendicular block (wrong street).
At D, the pointer has clearly continued straight, so C's pick is removed.
```

**Sketch (not in the code):**

```javascript
const PENDING_WINDOW = 6;  // picks to hold before committing
let pendingSnaps = [];     // [{ featureId, props, pt, strokeIdx }]

function revisePending() {
  pendingSnaps.forEach(snap => {
    // Direction of the stroke after this pick was made
    const dirAfter = getStrokeDirectionFrom(paintPoints, snap.strokeIdx + 4, 6);
    const alignment = Math.abs(dirAfter.nx * snap.segNx + dirAfter.ny * snap.segNy);
    snap.suspect = alignment < 0.45;  // likely wrong
  });
  // Remove suspects flanked by non-suspects (a wrong turn in the middle of a straight run)
}
```

On lift: commit non-suspects, discard suspects, then run a final pass over the whole selection.

**Pros:** fixes mistakes the user never notices; no UI needed.
**Cons:** selection lags behind the stroke; intentional sharp turns can be flagged as suspect; the threshold needs tuning.

---

## Approach 2: segment continuity (chain preference)

**Partly built.** Variant A is built. Variant B is an idea, not built.

### Concept

Prefer blocks that **connect to the last selected block**. When a rider paints along K St and reaches Connecticut Ave, the right next block is the one that continues K St from the shared intersection, not the one that branches off at 90°.

### Variant A: client-side geometric bonus

**Built,** in `findBestCandidate` (the `contMult` lines). How it works today: `lastCommittedEdge` holds the screen-pixel endpoints of the last committed edge (set in `commitSegment`). For each candidate edge, if either of its ends is within `CONTINUITY_PX` = 16 px of either end of `lastCommittedEdge`, the score is multiplied by `CONTINUITY_SCORE_MULT` = 0.58.

Known weaknesses (see the bugs analysis): at an intersection the straight-on block and the cross street both touch the last edge, so both get the bonus; and `lastCommittedEdge` is not reset when a new stroke starts, so after a pan or zoom it points at the wrong place on screen.

### Variant B: database-backed adjacency

**Idea, not built.** Precompute which blocks share an endpoint, as an adjacency table, and use it to boost true continuations. A sketch in PostGIS (table and column names are illustrative; the survey's road data is published through `serving.survey_segments`):

```sql
-- Blocks that share an endpoint with a given block
SELECT b.segment_id
FROM roads a JOIN roads b ON a.segment_id <> b.segment_id
WHERE a.segment_id = $1
  AND (ST_DWithin(ST_StartPoint(a.geom), ST_StartPoint(b.geom), 0.00001)
    OR ST_DWithin(ST_StartPoint(a.geom), ST_EndPoint(b.geom),   0.00001)
    OR ST_DWithin(ST_EndPoint(a.geom),   ST_StartPoint(b.geom), 0.00001)
    OR ST_DWithin(ST_EndPoint(a.geom),   ST_EndPoint(b.geom),   0.00001));
```

Key it by `segment_id`, not `tile_id`: `tile_id` changes every data build. The page would still need `segmentIdsFor`-style lookups to go between the two.

The page already does a client-side version of this for a different job: the sequencer (`computeRouteSequence`) links selected blocks whose endpoints are within `ENDPOINT_THRESH` = 0.0001° to put them in route order for the survey. It is not used during snapping.

**Pros:** models "continuing along a street" directly; complements momentum.
**Cons:** Variant A can fail at complex intersections (it does today); Variant B adds data or API work.

---

## Approach 3: lookahead commit (deferred snapping)

**Built,** with some differences from the plan.

### Concept

Like a vector pen tool: **don't snap to a street until enough of the stroke has been seen to confirm intent.** The committed selection trails the pointer by a fixed number of picks.

```
Pointer:          ──────────────X  (current)
Committed:        ────────X        (N picks behind)
Lookahead window:           ────X  (used to check the oldest pick)
```

### How it works today

- `enqueuePaintSnap` pushes each pick onto `snapQueue` with the stroke sample index (`strokeIdx`) and the picked edge's direction (`segNx`, `segNy`), and marks the block `pending`.
- `tryDrainSnapQueue` runs while the queue holds at least `COMMIT_LAG` = 8 picks. It waits until the stroke has at least 4 more samples past the oldest pick, measures the stroke direction from that pick forward (`getStrokeDirectionFrom`, span up to 12 samples), and commits the pick (`commitFromQueueItem` → `commitSegment`) if `|dot| ≥ COMMIT_ALIGN_THRESHOLD` = 0.38. Otherwise it drops the pick.
- On lift, `flushSnapQueueRelaxed` empties the queue with `COMMIT_ALIGN_RELAXED` = 0.22.

**Differences from the plan:**

- The plan's flush was to "fall back to momentum at the time of the snap" when there is no later data. The code does not do that: an item with no measurable later direction is committed with no check. This is the main reason strokes that end on an intersection often add the cross street.
- The plan compared against the direction of the whole block. The code compares against the single edge that won the snap.
- A rejected pick is dropped. Nothing re-picks the street that does match the later direction.

**Pros:** uses observed future movement, not predictions; handles turns mid-stroke well (straight-through strokes went wrong 1 time in 19 in testing).
**Cons:** visible lag (8 picks × about 50 ms ≈ 400 ms); the end of the stroke is weak; more state to manage.

---

## Approach 4: post-stroke geometric smoothing

**Idea, not built.** A comment in the code next to the prune constants says "no Chaikin / re-snap." `resampleUniform` exists, but it is used only to build the polyline that the prune measures against, not for re-snapping.

### Concept

As with the smoothing tools in drawing apps: after the stroke ends, fit a smoothed curve through the samples and re-snap against that curve rather than the jittery input. The rider's intent is better represented by a smooth line than by raw pointer positions.

### Sketch (not in the code)

```javascript
paintCanvas.addEventListener('pointerup', () => {
  painting = false;
  // discard this stroke's real-time picks, then:
  const smoothed = chaikin(chaikin(chaikin(resampleUniform(paintPoints, 8))));
  smoothed.forEach(pt => enqueuePaintSnap(pt));   // re-snap the clean path
  fadeStroke();
});

function chaikin(pts) {
  const out = [pts[0]];
  for (let i = 0; i < pts.length - 1; i++) {
    out.push({ x: pts[i].x * 0.75 + pts[i+1].x * 0.25, y: pts[i].y * 0.75 + pts[i+1].y * 0.25 });
    out.push({ x: pts[i].x * 0.25 + pts[i+1].x * 0.75, y: pts[i].y * 0.25 + pts[i+1].y * 0.75 });
  }
  out.push(pts[pts.length - 1]);
  return out;
}
```

**Caution:** today's `resampleUniform` does not resample slow strokes correctly. When consecutive samples are under the step size apart, it returns only the first and last points (see Bug C in the bugs analysis). Fix it to resample by arc length before building anything on it.

**Pros:** removes jitter at the source; the visible stroke can stay raw.
**Cons:** selection would appear only on lift; smoothing cuts corners on real turns; aggressive smoothing can lose short blocks.

---

## Approach 5: manual correction tools

Whatever the algorithm, riders need to fix mistakes without starting over.

### Undo last block

**Built,** differently from the plan. `selectionHistory` records commits in order. `undoLastSegment` pops the last one and clears its `selected` feature-state. It is wired to the **Undo** button in the selection badge and to **Ctrl/Cmd+Z** (not a bare `Z` key, as the plan suggested). There is also **Undo stroke** (`undoLastPaintStroke`), which removes every block added by the last stroke, using `strokeBatchesHistory`.

### Click to deselect

**Built** as planned, for when paint mode is off: `map.on('click', 'road-selected', …)` calls `removeSegmentSelection` for a selected block. In paint or unpaint mode the handler returns early.

### Erase brush

**Built** as a separate **Unpaint** mode (the plan suggested Alt + paint). `toggleUnpaintMode` gives pointer events to `#unpaint-canvas`, draws a red stroke, and `eraseNearPaintPoint` removes any selected block within 28 px of the pointer (checked about every 50 ms). A tap in unpaint mode removes the selected block under it (`tryUnpaintTapAt`). Esc leaves unpaint mode.

### Lasso / box deselect

**Idea, not built.** Drag in normal mode to draw a box; selected blocks inside it are removed. Useful for cleaning up clusters of mistakes at an intersection.

---

## Recommended implementation priority (original plan) and status

### Phase 1: quick wins

1. **`selectionHistory` array for undo.** Built.
2. **Click to deselect on `road-selected`.** Built.
3. **Post-stroke Chaikin smoothing (Approach 4).** Idea, not built.

### Phase 2: architectural improvement

4. **Lookahead commit (Approach 3).** Built.
5. **Segment continuity bonus (Approach 2, Variant A).** Built.

### Phase 3: polish

6. **Revision sweep on lift** that removes blocks whose direction contradicts the final smoothed path. Idea, not built. What exists instead is a distance-only prune (`pruneSelectionsFarFromRawPolyline`, 62 px), measured against a resampled stroke that can collapse to a straight chord on slow strokes.
7. **Visual feedback for unconfirmed picks.** Built: the `pending` feature-state draws queued picks at 0.48 opacity on `road-selected`.

---

## Combined algorithm: plan vs today

```
1. Pointer moves                                              BUILT
   → record paint points; update momentum (smoothed direction)
   → every ~50 ms: find best candidate with direction-penalised score

2. Candidate found                                            BUILT
   → push to snapQueue, show as pending
   → once the queue holds COMMIT_LAG picks: check the oldest against
     the direction the stroke went afterwards; commit or drop

3. Pointer up
   → Chaikin smoothing of the raw stroke                      NOT BUILT
   → flush the queue with a relaxed threshold                 BUILT (no check when no later direction)
   → revision sweep against the smoothed path                 NOT BUILT (distance-only prune instead)
   → fade the stroke                                          BUILT

4. User correction
   → Undo button / Ctrl+Z: pop selectionHistory               BUILT
   → Undo stroke                                              BUILT (not in the original plan)
   → click a selected block (paint off): deselect it          BUILT
   → Unpaint mode                                             BUILT
```

---

## Parameters to tune

| Parameter | Today | Suggested range | Effect |
|---|---|---|---|
| `PERP_PENALTY` | 3.5 | 2.5 – 5.0 | Higher makes cross streets harder to grab (but has almost no effect when distance ≈ 0) |
| `SNAP_RADIUS` | 40 px | 25 – 50 px | Smaller is more precise but misses thin roads |
| `MOMENTUM_SMOOTH` | 0.25 | 0.1 – 0.4 | Lower means direction changes more slowly |
| `MIN_MOVE` | 12 px | 8 – 20 px | Movement needed before the direction penalty starts |
| `COMMIT_LAG` | 8 picks | 6 – 12 | Higher means more lookahead and more lag |
| `COMMIT_ALIGN_THRESHOLD` | 0.38 | — | Mid-stroke alignment needed to commit a pick |
| `COMMIT_ALIGN_RELAXED` | 0.22 | — | Alignment needed on the end-of-stroke flush |
| `CONTINUITY_PX` / `CONTINUITY_SCORE_MULT` | 16 px / 0.58 | — | Size and strength of the continuity bonus |
| `AVOID_REVISIT_MULT` | 1.14 | — | Penalty on blocks already selected |
| `OUTLIER_PRUNE_PX` | 62 px | — | How far from the stroke a new block can be before it is removed on lift |
| `RAW_PRUNE_SAMPLE_PX` | 10 px | — | Resampling step for the prune polyline |
| Chaikin passes | not built | 2 – 4 | More is smoother but cuts more corners |

All of these are fixed pixel values and do not change with zoom. They interact. Tune them against fixed test routes, one change at a time. Good test cases from live testing: painting up 14th St NW or 11th St NW and stopping exactly on the intersection with U, V or W St; and an L-shaped route painted slowly.
