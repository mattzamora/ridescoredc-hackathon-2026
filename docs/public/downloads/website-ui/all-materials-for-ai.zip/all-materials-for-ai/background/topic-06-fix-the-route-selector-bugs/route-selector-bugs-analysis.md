# Route-selector bugs: analysis for hackathon Topic 6

Describes the code as of website develop 38386ee (October 2026).
Explains why the paint-a-route selector picks the wrong blocks or loses blocks, how to reproduce each problem, and where to start fixing it.

> File: `frontend/survey/index.html` in `ridescoredc-website` (about 2,250 lines), served at `/survey/`. Line numbers below are approximate. Search by function name rather than trusting a number.

Live testing on dev.ridescoredc.com/survey/ on Oct 2, 2026 (desktop at 1280 × 800 with mouse strokes, plus one phone touch stroke) confirmed three ways the selector goes wrong:

| Problem | Status | How often it reproduced |
|---|---|---|
| A. Wrong street at an intersection | Confirmed, mostly at the **end** of a stroke | Straight through: 1 of 19. Ending on the intersection: 5 of 8. Overshooting by ~4 px: 6 of 6 |
| B. Block split across tiles vanishes on lift | Confirmed | 6 of 6 on the right piece of the block |
| C. Blocks near a turn vanish on lift (slow strokes) | Confirmed, probably the main real-world cause of "blocks vanish when I lift" | 6 of 6 at 4–8 px sample spacing; 0 of 6 at 10–16 px |

The fix ideas are starting points, not tested solutions.

---

## How painting works today (short version)

**Built.**

1. Turning on **Paint Route** (`togglePaintMode`) gives pointer events to the `#paint-canvas` overlay and disables map pan and zoom.
2. On `pointermove` (handler at about line 979) the page records the screen point in `paintPoints`, updates the stroke direction (`updateMomentum`) and, at most every 50 ms, calls `enqueuePaintSnap(pt)` (about lines 1438–1462).
3. `enqueuePaintSnap` calls `findBestCandidate(pt, { avoidRevisit: true })` to pick one street block near the pointer, pushes it onto `snapQueue`, and sets its `pending` feature-state (the light-blue "about to be selected" highlight).
4. `tryDrainSnapQueue` (about 1376–1393) waits until the queue holds `COMMIT_LAG` = 8 picks, then checks the oldest pick against the direction the stroke went afterwards. It either commits the pick (`commitFromQueueItem` → `commitSegment`) or drops it.
5. On `pointerup` (about 994–1019): a short tap (`isStrokeTapGesture`: under 14 px and at most 10 samples) adds the single nearest block. Otherwise the final point is enqueued and `finishStrokePipeline` (about 1557–1566) runs:
   - `flushSnapQueueRelaxed` commits the remaining queue with a looser direction check;
   - `resampleUniform(paintPoints, RAW_PRUNE_SAMPLE_PX)` turns the stroke into a "raw chain" (`RAW_PRUNE_SAMPLE_PX` = 10);
   - `pruneSelectionsFarFromRawPolyline` removes any block added in this stroke whose distance from that chain is more than `OUTLIER_PRUNE_PX` = 62 px;
   - the stroke's block ids are pushed onto `strokeBatchesHistory` for **Undo stroke**.

Feature ids on this page are `tile_id`, promoted with `promoteId: { 'survey_segments': 'tile_id' }` on the `segments` source (about line 774). `tile_id` is only good for MapLibre feature-state and changes every data build. At submit time `segmentIdsFor` converts the selected `tile_id`s into `segment_id`s, the lasting id stored with the answers.

---

## Bug A: wrong street picked at intersections

**Confirmed (live).**

### What testing found

- **Painting straight through an intersection is mostly fine.** It went wrong only 1 time in 19: a stroke on 14th St NW that zigzagged about ±7 px picked a block of W St NW.
- **Ending a stroke exactly on an intersection picks the cross street often: 5 of 8 strokes.** Examples: 14th St ending at W St added a block of W ST NW; 11th St at U added U ST NW; 11th St at V added V ST NW; 11th St at W added W ST NW; a phone stroke ending at 13th & U added a block of 13TH ST NW.
- **Overshooting an intersection by about 4 px added the whole next block on the same street: 6 of 6 strokes.** The rider only touched the next block, but the selector works in whole blocks.

**To reproduce:** zoom to about 16. Turn on Paint Route and paint up 14th St NW (or 11th St NW). Stop exactly on the intersection with W St (or U, V or W St for 11th). Lift. Look for a short blue stub on the cross street. Then repeat, stopping a few pixels past the intersection, and watch the whole next block turn blue.

### What the code does

`findBestCandidate` (about lines 1260–1346):

- Queries rendered features on layer `road-score` in a box of ±`SNAP_RADIUS` around the pointer. `SNAP_RADIUS` = 40 (about line 1208), so the box is about 80 × 80 px.
- For every edge of every feature, computes `dist`, the pixel distance from pointer to edge, and skips edges 40 px or more away.
- Computes a direction `penalty` from the stroke's momentum: `penalty = PERP_PENALTY - (PERP_PENALTY - 1) * alignment` (about line 1306), with `PERP_PENALTY` = 3.5. An edge aligned with the stroke gets 1; a perpendicular edge gets 3.5. The momentum only starts counting once the stroke has moved at least `MIN_MOVE` = 12 px across its last 10 samples (`updateMomentum`); before that, every edge gets penalty 1.
- Applies a continuity multiplier `contMult` (about 1310–1317): if either end of the edge is within `CONTINUITY_PX` = 16 px of either end of `lastCommittedEdge`, the score is multiplied by `CONTINUITY_SCORE_MULT` = 0.58.
- Multiplies the score of blocks that are already selected by `AVOID_REVISIT_MULT` = 1.14 (defined at about line 750, used at about 1321).
- Final score: `score = dist * penalty * contMult` (about line 1319), times the revisit factor where it applies. The lowest score wins with a strict `<` (about line 1323). If the winner is already selected, the function returns nothing (unless called with `allowSelected`).

At the end of a stroke, `flushSnapQueueRelaxed` (about 1464–1479) commits what is left in the queue. For each item it measures the stroke direction from that item's sample onward with `getStrokeDirectionFrom`. It drops the item only if that direction exists and its alignment is below `COMMIT_ALIGN_RELAXED` = 0.22. If no direction can be measured, it commits the item.

### Why it goes wrong

1. **Multiplying by distance cancels direction at the intersection.** When the pointer is on the intersection, `dist` is close to 0 for every street that meets there. `0 × 1` and `0 × 3.5` are both about 0, so direction stops mattering at exactly the moment it matters most.
2. **Ties go to whichever feature MapLibre lists first.** With all scores about 0, the strict `<` keeps the first edge that reached the minimum. That order comes from `queryRenderedFeatures`, not from the stroke.
3. **The last pick of a stroke is committed with no direction check.** On `pointerup` the final point is enqueued with `strokeIdx` equal to the last sample. In `flushSnapQueueRelaxed`, `getStrokeDirectionFrom(paintPoints, strokeIdx, span)` then has no later samples to look at (`toIdx <= fromIdx`), returns `null`, and the item is committed. The same happens for picks made in the last few samples, where the remaining stroke is under 5 px. This is why stopping on an intersection so often adds the cross street, and why a 4 px overshoot always adds the next block: that block's edge has `dist` ≈ 0, and nothing asks whether the stroke really travelled along it.
4. **The lookahead can only accept or drop, never re-pick.** Mid-stroke, `tryDrainSnapQueue` checks the queued pick against the direction the stroke went next (`|dot| ≥ COMMIT_ALIGN_THRESHOLD` = 0.38, about line 894; check at about 1389). A wrong pick is dropped, but nothing goes back to ask which street *does* match the later direction, so the correct block near the corner can be lost too. Because this check works, straight-through strokes usually come out right (18 of 19).
5. **The continuity bonus helps both streets equally.** At the shared intersection, the straight-on block and the cross street both have an endpoint within 16 px of `lastCommittedEdge`, so both get the 0.58 bonus. It cannot break the tie it was meant to break.
6. **`lastCommittedEdge` is stored in screen pixels and is not reset per stroke.** It is set in `commitSegment` (about line 1358) and cleared only when the selection becomes empty or is cleared (`removeSegmentCompletely`, `removeSegmentSelection`, `undoLastSegment`, `clearSelection`). The paint `pointerdown` handler (about 969–977) resets momentum and the queue but not `lastCommittedEdge`. If the user pans or zooms between strokes, the stored pixel position points at an unrelated place on screen, and the first picks of the next stroke can get a bonus they should not.
7. **All thresholds are fixed pixel values.** `SNAP_RADIUS` 40, `CONTINUITY_PX` 16, `MIN_MOVE` 12, `OUTLIER_PRUNE_PX` 62. Nothing in the paint code reads the zoom level (there is no `getZoom` call in the file), so at low zoom 40 px covers several blocks and at high zoom very little.

### Fix ideas

- **Additive penalty instead of multiplicative:** for example `score = dist + k * (1 - alignment) * SNAP_RADIUS`. Direction then still counts when `dist` is about 0.
- **Don't commit end-of-stroke picks blindly.** In `flushSnapQueueRelaxed`, when no later direction exists, use the direction the stroke arrived from (the momentum), and require it to align with the block. Or require the stroke to run some minimum distance along a block (for example 15–20 px, or a share of the block's length) before that block counts.
- **Re-pick after the corner instead of only dropping:** when the lookahead rejects a queued pick, call `findBestCandidate` again near that queued point using the post-corner direction (the `dirOverride` option already exists), and commit what that returns if it aligns.
- **Reset `lastCommittedEdge` on `pointerdown`**, or store it in lng/lat and re-project it when used.
- **Make the continuity bonus direction-aware:** give the bonus only to an edge that continues roughly in line with `lastCommittedEdge`.
- **Scale pixel thresholds with zoom**, or express them in metres and convert.
- **Deterministic tie-break:** when scores are within a small epsilon, prefer the better-aligned edge.

---

## Bug B: a block split across tiles vanishes on lift

**Confirmed (live).**

### What testing found

At zoom 17 on HOSPITAL CENTER DR NW, one block comes back from the tiles as two pieces with the same `tile_id`. Painting about 150 px along the piece that `querySourceFeatures(...).find()` does **not** return first: `selectedSegments.size` went 1 → 0 on lift, 6 of 6 times. Painting on the other piece kept the block (1 → 1).

**To reproduce:**

1. Open `/survey/` and the browser console.
2. Run `map.showTileBoundaries = true` to draw the tile grid.
3. Zoom to 17 and find a long block that crosses a tile line (HOSPITAL CENTER DR NW works).
4. Turn on Paint Route and paint along the far piece of the block only. Lift.
5. The block turns blue while you paint and disappears when you lift. Paint the other piece and it stays.

### What the code does

- Martin serves vector tiles. A tile only contains the part of each line that falls inside it, so a long block that crosses a tile edge arrives as **several pieces that share one `tile_id`**.
- `querySegmentFeatureById(fid)` (about lines 1508–1515) calls `map.querySourceFeatures('segments', { sourceLayer: 'survey_segments' })` and returns `.find(...)`, the **first** piece with that `tile_id`.
- `segmentMinDistToPolylineScreen` (about 1517–1542) measures the stroke-to-block distance using only that one piece.
- `pruneSelectionsFarFromRawPolyline` (about 1546–1555), run on lift, removes any block added in this stroke whose measured distance is more than `OUTLIER_PRUNE_PX` = 62 px (about line 900).

### Why it goes wrong

If the first piece returned is the part of the block you did not paint, the block measures more than 62 px from the stroke and is removed on lift.

### A related effect (inferred from code, not tested)

The sequencer (`computeRouteSequence`, about line 1731) links blocks by their endpoints (`segmentEndpoints`, threshold `ENDPOINT_THRESH` = 0.0001°, about line 1729). Those endpoints come from `lineEndpointA` / `lineEndpointB` of the piece that won in `findBestCandidate`, so a clipped piece can give an endpoint at a tile edge rather than at an intersection. That can break adjacency and split or reorder the route in the survey.

### Fix ideas

- **Use the nearest piece:** `filter` instead of `find`, then take the minimum distance over every piece with that id.
- **Merge piece endpoints** per id before the sequencer runs, keeping the two endpoints farthest apart (or the ones not on a tile edge).
- Longer term: fetch whole geometries by `segment_id` from the server when the stroke ends.

---

## Bug C (new): slow strokes lose the blocks near a turn

**Confirmed (live and in code).** This is probably the main real-world cause of "blocks vanish when I lift," because slow mouse strokes and finger strokes are common.

### What testing found

On two L-shaped routes, every stroke whose pointer samples were 4, 6 or 8 px apart lost 3 blocks near the corner on lift (6 of 6). Strokes with 10–16 px spacing lost none (0 of 6). A synthetic 101-point L-shaped stroke was resampled to just 2 points.

**To reproduce:** paint an L-shaped route (up one street, turn, along the cross street) slowly, so the mouse or finger moves only a few pixels between samples. The corner blocks turn blue while you paint and vanish on lift. Paint the same L quickly and they stay.

### What the code does, and why

`resampleUniform(pts, stepPx)` (about lines 1481–1506) is meant to place points every `stepPx` = 10 px along the stroke. The loop keeps a cursor `(cx, cy)` and a target sample `pts[segIdx + 1]`:

```javascript
const dist = Math.hypot(dx, dy);          // cursor → next input sample
...
if (dist >= stepPx) {
  const t = stepPx / dist;
  cx += dx * t;
  cy += dy * t;
  out.push({ x: cx, y: cy });             // emit a point 10 px along
} else {
  segIdx++;
  cx = tx; cy = ty;                       // jump the cursor to the sample, emit nothing
}
```

When the next sample is less than 10 px from the cursor, the cursor simply moves to that sample and nothing is emitted. The distance already travelled is thrown away; it never accumulates. So if every pair of consecutive samples is under 10 px apart, no point is ever emitted inside the loop. After the loop the function adds the last sample (if it is more than 2 px from the first), and the result is just **[first point, last point]**. Running the function on synthetic L-strokes confirms it: 101 samples at 4, 6, 8 or 9.9 px spacing all come back as 2 points; at 10 px or more they come back as about one point per sample.

`finishStrokePipeline` passes that result to `pruneSelectionsFarFromRawPolyline`, which measures each block against it with `segmentMinDistToPolylineScreen`. With only two points, the "stroke" is a straight chord from start to end. On an L-shaped route the corner can be well over 62 px from that chord, so the blocks near the corner are removed even though the rider painted right over them.

### Fix ideas

- **Resample by arc length:** carry the leftover distance from sample to sample, so short steps add up and a point is emitted every 10 px of actual travel.
- **Or skip resampling for the prune:** measure against the raw `paintPoints` polyline. The prune only needs distances, not even spacing.
- **Add a guard:** if the resampled chain has far fewer points than the stroke's length suggests, fall back to the raw points.

---

## Side findings

**Confirmed (live; the first two also confirmed in code).**

- **The badge counts streets, not blocks.** `updateBadge` (about 1575–1585) shows `buildContiguousSegments().length` as "N roads selected". `buildContiguousSegments` (about 1835) groups the sequenced blocks into runs with the same `route_name`. Losing 3 blocks of one street does not change the number, so the badge did not reveal Bug C.
- **"Undo stroke" stays disabled after the first stroke.** `updateBadge` sets the button from `strokeBatchesHistory.length`. It is called from `commitSegment` and from removals, but `finishStrokePipeline` pushes the stroke onto `strokeBatchesHistory` after those calls and does not call `updateBadge` again. The tap path in the `pointerup` handler does the same. So the button always reflects the history before the latest stroke: after the first stroke (or the first after **Clear**) it stays disabled until something else refreshes the badge. In testing this showed up after strokes whose blocks were pruned on lift. Fix: call `updateBadge()` at the end of `finishStrokePipeline` and after the tap-path push.
- **The paint and unpaint hint boxes cover the map.** `#paint-hint` and `#unpaint-hint` are fixed at `bottom: 180px`, centred, up to 420 px wide. On desktop and on a phone they sit over the middle of the map, where the rider is painting. Fix ideas: move them to the top edge, shrink them, or hide them after the first stroke.
- **The paint hint promises something paint mode does not do (code only, not live-tested).** It says "Undo or tap a blue segment to remove one segment." In paint mode a tap goes to the paint canvas; `findBestCandidate` ignores already-selected blocks by default, so tapping a blue block does nothing. Removing a block by tapping works only with paint mode off (the `road-selected` click handler) or in Unpaint mode.
- **`undoLastSegment`** (about 1619–1633) removes the id from `selectedSegments` but not from `strokeOrderedSegmentIds`, unlike `removeSegmentSelection`. The survey order comes from `computeRouteSequence`, which reads `selectedSegments`, and `segmentIdsFor` skips ids no longer selected, so the effect is probably small. Not tested.

---

## What snap-intersection-problem.md proposed vs what is in the code

| Proposal in snap-intersection-problem.md | In today's code? | Where (approximate) |
|---|---|---|
| Lookahead commit (Approach 3) | Built | `snapQueue`, `tryDrainSnapQueue` ~1376, `COMMIT_LAG` = 8 |
| Relaxed flush on stroke end | Built | `flushSnapQueueRelaxed` ~1464, `COMMIT_ALIGN_RELAXED` = 0.22 |
| Client-side continuity bonus (Approach 2, Variant A) | Built | `contMult` in `findBestCandidate` ~1310 |
| Undo last segment | Built | `undoLastSegment` ~1619, **Undo** button, Ctrl/Cmd+Z |
| Undo last stroke | Built | `undoLastPaintStroke` ~1587, **Undo stroke** button |
| Click a selected block to deselect | Built (paint mode off) | `map.on('click', 'road-selected', …)` ~835 |
| Pending (unconfirmed) highlight | Built | `pending` feature-state, set in `enqueuePaintSnap` ~1455 |
| Erase / unpaint brush | Built | Unpaint mode, `toggleUnpaintMode` ~1140, `eraseNearPaintPoint` ~1410 |
| Database adjacency table (Approach 2, Variant B) | Idea, not built | none |
| Chaikin smoothing + re-snap after stroke (Approach 4) | Idea, not built | A comment at ~898 says "no Chaikin / re-snap" |
| Retroactive revision of committed picks (Approach 1) | Idea, not built | Only the distance-based prune on lift |
| Post-stroke direction sweep (Phase 3) | Idea, not built | none |
| Lasso / box deselect | Idea, not built | none |

The "Refine route" handles described in paint-route-editing-roadmap.md are also not in today's file: there are no refine functions.
