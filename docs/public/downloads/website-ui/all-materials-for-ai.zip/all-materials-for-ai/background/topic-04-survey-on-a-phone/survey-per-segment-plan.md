# Per-Segment Survey: Design Intent and How It Is Built

Describes the code as of website develop 38386ee and models develop ef0caea (October 2026).
Why the survey asks about one street at a time, and how that is implemented in the page, the API and the database, for anyone improving the survey on a phone.

> Code: `frontend/survey/index.html` (served at `/survey/`), `api/main.py`, `api/migrations/0001_app_schema.sql`.
> Reference mock-up: `survey_sample.html` in this folder.
> Earlier plan this builds on: `topic-05-rethink-route-drawing/mvp-feedback-plan.md`.

---

## What it does

**Built.** After a rider paints a route on the survey page and taps **Rate route →**, a questionnaire opens that steps through the route one street at a time. It has two tiers:

1. **Per-street questions**: the main body. The rider steps through each run of the same street (a "contiguous segment").
2. **Route summary questions**: asked once at the end.

The survey page never shows a safety score. Its road tiles come from `serving.survey_segments` (models repo, `serving/020_survey_segments.sql`), a view with only `tile_id`, `segment_id`, `route_name` and geometry. A rider who has seen our rating of a street cannot give an independent one, and a page cannot show data it never fetched.

---

## Segment granularity: three tiers

**Built.**

| Tier | Definition | In the page | Stored as |
|---|---|---|---|
| **Granular** | One block of road (one row of `data.road_segment`) | A `tile_id` key in `selectedSegments` | One row in `app.survey_granular_segments`, by `segment_id` |
| **Contiguous** | A run of consecutive granular segments with the same `route_name` | One entry of `surveySegments` (`{ route_name, tile_ids }`) | One row in `app.survey_contiguous_segments` |
| **Selected route** | Everything painted, as one submission | `strokeOrderedSegmentIds` | One row in `app.survey_submissions` |

`tile_id` is an integer used only for MapLibre feature-state; it changes every time the road data is rebuilt, so it is never sent to the API. Before submitting, `segmentIdsFor()` turns each `tile_id` into the lasting text `segment_id` using the feature properties saved at paint time.

### Grouping into contiguous segments

`buildContiguousSegments()` takes the ordered list from `computeRouteSequence()` (see "Sequencer" below) and starts a new group whenever `route_name` changes.

**Disconnected stretches.** If the rider paints two stretches that do not touch, they stay in **one submission**. The sequencer orders the stretches by when each was first painted and numbers the streets continuously across them (if the first stretch ends at street 3, the second starts at 4). Splitting disconnected stretches into separate submissions was an earlier plan: **Idea, not built.**

---

## Survey flow

**Built.**

```
Rider paints route(s) → "Rate route →" (openSurveyPanel)

   Per-street questions:
      → Map shrinks to the top half on a phone; flies to street 1 and highlights it cyan with a black border
      → Sheet: street track + questions
      → Rider answers perceived LTS (1–4) and safety (1–10)
         → if LTS is 3 or 4: stress-factor checkboxes appear
      → "Next segment" → map flies to street 2 … repeat
      → On the last street the button reads "Review summary"
      → Any street can be skipped or revisited by tapping the track
      → "Skip →" is always there to jump straight to the summary

   Route summary:
      → Time of day (required)
      → Overall satisfaction 1–5 (required)
      → Would you ride this route again? (required)
      → Comments (optional)
      → Submit → thank-you screen → "Done" clears the selection
```

Per-street answers are all optional (nulls are allowed). The three summary questions are checked by `validateSummary()`, which marks missing ones in red and scrolls to the first.

---

## Map behavior during the survey

**Built.**

- **Phone (up to 768 px wide)**: the map takes the top half (`body.survey-active #map { bottom: 50vh; }`); the sheet takes the bottom half.
- **Wider screens**: the map fills the screen and the survey is a 380 px panel on the right. `fitMapToSegmentFids()` pads the right side by 395 px so the street is not hidden behind the panel.
- **All roads**: one flat gray (`#94a3b8`, layer `road-score`). There is no score to color by.
- **Painted roads**: blue (`#2563eb`, layer `road-selected`, feature-state `selected`).
- **Active street**: cyan (`#00e5ff`, layer `road-survey-active`) over a black border (layer `road-survey-border`), both driven by feature-state `surveyActive`. Cyan was chosen because it suggests no rating.
- The map **flies to** the active street when the rider advances, goes back, or taps a node in the track (`activateSurveySegment()` → `fitMapToSegmentFids()`, max zoom 17).

---

## The survey sheet

**Built.** One layout for 1 to N streets (`#survey-sheet`):

1. **Header**: "Rate your route", a progress pill such as "3 / 8", the street name, and a close button.
2. **Street track** (`#ss-track`): a horizontal timeline, scrollable by drag or swipe (`initTrackDrag()`). Nodes show a check (answered), a number (not yet answered) or an enlarged active node. Tapping a node jumps to that street and moves the map. It scrolls to keep the active node in view (`scrollTrackToActive()`). A street counts as answered once it has an LTS or a safety rating.
3. **Question panel**: street name, then the questions. Stress factors show only for LTS 3 or 4.
4. **Footer**: back arrow, **Next segment** (or **Review summary** on the last street), and **Skip →** to the summary.

The `survey_sample.html` mock-up in this folder shows the intended look; the built page follows its structure.

---

## Questions

### Per street

**Built.**

| # | Question (as shown) | Type | Scale | When |
|---|---|---|---|---|
| 1 | Was this segment appropriate for: | Buttons 1–4, labeled "Most inclusive" to "Expert only" | LTS 1–4 | Always |
| 2 | How safe did you feel? (1–10) | Buttons | 1 (Very unsafe) – 10 (Very safe) | Always |
| 3 | What drove stress here? (select all that apply) | Checkboxes | — | Only if LTS is 3 or 4 |

Choosing LTS 1 or 2 clears any stress factors already ticked for that street (`setSegLts()`).

**Stress factor options** (the `STRESS_FACTORS` array):

- Motor traffic speed
- Motor traffic volume
- Number of motor lanes
- Little separation from traffic
- Intersections or crossings
- Door zone or parking-adjacent
- Bike lane or path blocked
- Map bike facility did not match ground

**LTS explanations** (shown by the "more info…" link, `toggleLtsInfo()`):

| Value | Label | Description in the page |
|---|---|---|
| 1 | Beginners & children | Calm, strong separation from traffic |
| 2 | Casual adults | Own space away from fast or multilane roads |
| 3 | Confident riders | Moderate-speed or multilane interaction |
| 4 | Strong & fearless | High-speed traffic, assertive riders only |

### Route summary

**Built**, but different from the original plan.

| # | Question (as shown) | Type | Stored in |
|---|---|---|---|
| 1 | When did you ride this route? (required) | Morning (6am–12pm) · Afternoon (12pm–5pm) · Evening (5pm–9pm) · Night (9pm–6am) | `time_of_day` |
| 2 | How satisfied were you with this route overall? (required) | Buttons 1–5, Very dissatisfied – Very satisfied | `overall_satisfaction` |
| 3 | Would you ride this route again? (required) | Yes · Probably · No (stored as `yes` / `probably` / `no`) | `would_ride_again` |
| 4 | Any other comments? (optional) | Free text, 500 characters max | `comments` |

- **Trip purpose**: **Partly built.** The column `trip_purpose`, the API field and a `setSumPurpose()` handler exist, but the page has no buttons for it, so it is always sent as `null`.
- **"Compared to the map colors…" calibration question** and **perceived traffic volume**: **Idea, not built.** They were in the original plan and are not in today's page, API or tables. The calibration question would also clash with the no-score rule above, since the survey page shows no score colors to compare against.

---

## Database storage

**Built.** Three tables in the `app` schema, created by `api/migrations/0001_app_schema.sql` (applied with `npm run migrate`). `POST /api/submissions` writes all three in one transaction.

### `app.survey_submissions`

One row per submission.

| Column | Type | Notes |
|---|---|---|
| `submission_id` | UUID, primary key | Generated by the API |
| `submitted_at` | timestamptz | Default `NOW()` |
| `segment_ids` | text[] | Every painted segment, in the order painted |
| `geometry_source` | text | Which published road data the ids belong to, for example `ridescoredc-data-preview@0.1`. Read by the API from `data.load_record`, not sent by the browser. |
| `time_of_day` | varchar(20) | |
| `overall_satisfaction` | integer | Checked 1–5 |
| `would_ride_again` | varchar(20) | |
| `trip_purpose` | varchar(30) | Always null today (no UI) |
| `comments` | text | |

### `app.survey_contiguous_segments`

One row per street run per submission.

| Column | Type | Notes |
|---|---|---|
| `id` | UUID, primary key | |
| `submission_id` | UUID → `survey_submissions` | `ON DELETE CASCADE` |
| `sequence_index` | integer | Order within the submission, from 0 |
| `route_name` | varchar | Saved at answer time, so a person can still recognize the street if segment ids change later |
| `segment_ids` | text[] | The run's segments, in sequenced order |
| `lts_perceived` | integer | Checked 1–4, nullable |
| `safety_rating` | integer | Checked 1–10, nullable |
| `stress_factors` | text[] | Sent as null when none are ticked |

### `app.survey_granular_segments`

One row per segment per submission.

| Column | Type | Notes |
|---|---|---|
| `submission_id` | UUID → `survey_submissions` | Part of the primary key |
| `segment_id` | text | Part of the primary key |
| `contiguous_segment_id` | UUID → `survey_contiguous_segments` | |
| `sequence_index` | integer | Position **within its street run**, from 0 (the API numbers per run) |

Because the primary key is `(submission_id, segment_id)` and the insert uses `ON CONFLICT DO NOTHING`, a segment that appears in two runs is recorded only once, under the first.

There is **no foreign key** to the road data. The `data` tables are dropped and rebuilt on every data load, which a foreign key would block. Responses refer to segments by value; after each load, the models repo's loader (`scripts/load_package.py`) prints how many `app.survey_contiguous_segments` rows match none of the loaded segments.

---

## Implementation notes

### Files

**Built.**

| File | Role |
|---|---|
| `frontend/survey/index.html` | The whole survey page: paint tools, sheet HTML, CSS and JS |
| `frontend/src/shared/config.js`, `basemap.js`, `crashes.js` | Basemap, imagery and crash layers shared with the map page |
| `api/main.py` | FastAPI: `POST /api/submissions`, `GET /health` |
| `api/migrations/0001_app_schema.sql` | Creates the three `app` tables |
| `api/requirements.txt` | API dependencies (fastapi, uvicorn, psycopg 3, pydantic, aiofiles) |
| `docker-compose.yml` | The `fastapi` service (python:3.12-slim, runs uvicorn on port 8000 behind nginx) |

### Key frontend pieces

- `segmentGeoCenter`: `tile_id → [lng, lat]`, the midpoint of the best-matching edge, saved while painting. Used to fly the map during the survey.
- `segmentEndpoints`: `tile_id → [[lngA, latA], [lngB, latB]]`, the first and last points of the segment's line. Used by the sequencer.
- `road-survey-border` and `road-survey-active` layers, switched with feature-state `surveyActive` by `setSurveyActiveFeatureState()`.
- `buildContiguousSegments()`: groups the sequenced selection by `route_name`.
- `fitMapToSegmentFids()`: fits the map to the active street, with right padding for the desktop panel. On a phone no extra padding is needed because the map container itself has shrunk.
- `segmentIdsFor()`: maps `tile_id`s to `segment_id`s at submit time.

### API endpoint

**Built.** The page calls `/api/submissions` on its own origin (nginx on `localhost:8000` in the Full Stack setup, proxied by Vite on `localhost:5173` in the Front-End setup).

```
POST /api/submissions
Content-Type: application/json

{
  "segment_ids": ["string", ...],            // every painted segment, paint order
  "contiguous_segments": [
    {
      "sequence_index": 0,
      "route_name": "string | null",
      "segment_ids": ["string", ...],        // this run, sequenced order
      "lts_perceived": 1-4 | null,
      "safety_rating": 1-10 | null,
      "stress_factors": ["string", ...] | null
    }
  ],
  "time_of_day": "string | null",
  "overall_satisfaction": 1-5 | null,
  "would_ride_again": "string | null",
  "trip_purpose": "string | null",
  "comments": "string | null"
}

201 → { "submission_id": "uuid" }
422 → the body does not match the Pydantic models (SurveySubmission / ContiguousSegment)
503 → no road data is loaded, so the ids cannot be tied to a road network
500 → any other database error (for example a value outside a CHECK range)
```

The page gives up after 8 seconds (`AbortController`) and shows the thank-you screen whether or not the request succeeded; failures are only logged to the console. Retrying or saving a failed submission is **Idea, not built.**

---

## Sequencer algorithm

**Built.** `computeRouteSequence()` in `frontend/survey/index.html` runs when the survey opens (through `buildContiguousSegments()`), and also to count roads for the selection badge.

### Data saved while painting

- `segmentEndpoints`: the two end points of each segment's line, found in `findBestCandidate()` and saved by `commitSegment()`.
- `strokeOrderedSegmentIds`: segments in the order they were added (paint order). Removing a segment removes it from this list too.

### Steps

1. **Adjacency graph.** Two segments are neighbors if any of their four end-point pairs are closer than `ENDPOINT_THRESH` (0.0001°, about 10 m). This absorbs floating-point drift; segments that meet at an intersection share an end point in the road data.
2. **Connected components in paint order.** A breadth-first search starts from the unvisited segment painted earliest. Components come out in the order the rider first touched them, and numbering continues across components.
3. **Direction-preserving walk per component:**
   - Find the **first-painted** segment in the component.
   - **Search outward from it** to the nearest end of the route (a segment with only one neighbor). Using the nearest end, not the earliest-painted end, anchors the count to the side where the rider started, even if more segments were added later on the other side.
   - **Walk neighbor to neighbor** from that end, each time choosing the unvisited neighbor painted earliest. This follows the original drawing direction through turns. Only adjacent segments follow each other.
   - Segments the walk cannot reach (branches, or segments without end-point data) are added at the end of the component in paint order.
4. **Group by street.** `buildContiguousSegments()` splits the result wherever `route_name` changes.

### Guarantees

- Within a connected stretch, consecutive segments always share an intersection. No jumping.
- The sequence starts at the end of the route where the rider began drawing.
- Disconnected stretches continue the numbering from the previous one.

### Edge cases

- **Loops** (no segment with only one neighbor): starts from the first-painted segment.
- **Branches**: the walk covers the main path; the rest is added in paint order.
- **Missing end-point data**: the segment has no neighbors, becomes its own component, and is ordered by paint order.
- **Segments added in the middle after the first stroke**: the direction comes from the first-painted anchor, so later additions do not flip the count.
