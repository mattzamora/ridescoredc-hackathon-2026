# route_snapper: audit and recommendations for RideScore

Describes the code as of website develop 38386ee (October 2026).
Explains how the public route_snapper library works, how it differs from RideScore's paint mode, and which of its ideas RideScore could borrow.

> **Reference:** route_snapper, a public MapLibre route-drawing library from the A/B Street project: https://github.com/dabreegster/route_snapper (Apache 2.0). Sections 1, 2 and 4 describe that library, not RideScore code.
> **RideScore today:** paint-to-block selection in `frontend/survey/index.html` (the survey, served at `/survey/`), using vector tiles from Martin at `/tiles/survey_segments/{z}/{x}/{y}`.

---

## 1. What route_snapper is

**External library (not RideScore code).**

route_snapper is a MapLibre tool for drawing **routes** (or **polygons** in "area mode") that **snap to a precomputed street network graph** in the browser. Routing runs client-side in **Rust compiled to WebAssembly**; there is no server round-trip per drag.

Pipeline:

1. **Offline:** build a compact binary graph (`snap.bin`) from OpenStreetMap (`osm-to-route-snapper`) or from GeoJSON LineStrings (`geojson-to-route-snapper`) that share vertices (see the connectivity rule below).
2. **Runtime:** load `snap.bin` in the page, construct `RouteSnapper` (JS wrapper) or `RouteTool` (TypeScript), and wire up MapLibre events.
3. **Interaction:** the user places **waypoints**, snapped to graph **nodes**, or **freehand** with shift+click. The tool computes **shortest paths** along directed edges between consecutive waypoints and renders a preview and final GeoJSON.

Main docs in the upstream repository: `README.md` and `user_guide.md`.

---

## 2. Technical architecture

**External library (not RideScore code).**

### 2.1 Graph model (`route-snapper-graph`)

- **`RouteSnapperMap`**: `nodes` (coordinates) plus `edges` (each with `node1`, `node2`, a `LineString` geometry and an optional `name`).
- **Directed routing:** each undirected edge becomes **two** directed arcs in a `petgraph` `DiGraphMap`, each with its own cost (`forward_cost` / `backward_cost`).
- **Costs:** by default, `length_meters` along the geometry. Overrides can set `null` to forbid a direction (one-way, no access).
- **Serialization:** custom bincode layout with quantized coordinates.

This is a real network graph, suitable for shortest-path queries.

### 2.2 WASM core (`route-snapper/src/lib.rs`)

- **`JsRouteSnapper`** holds a `Router` (map, graph, config) and an **R-tree** over node positions for nearest-node queries under the cursor (the radius comes from a pixel distance in the TypeScript layer, about 30 px, converted to metres at the current zoom).
- **State machine:** modes such as `Neutral`, `Hovering(Waypoint)`, `Dragging`, `Freehand`. Routes are **waypoint-driven**, not "every mouse move picks an edge."
- **`Route`:** `waypoints` (`Snapped(NodeID)` or `Free(Coord)`) and a derived `full_path` of traversed directed edges.
- **Undo:** a stack of waypoint snapshots (`MAX_PREVIOUS_STATES = 100`).
- **`renderGeojson`** returns a FeatureCollection for the current preview, with properties such as `snapped` on lines, `type` on points (`snapped-waypoint`, `free-waypoint`, `node`), and `cursor`, `snap_mode`, `undo_length`.

### 2.3 TypeScript wrapper (`route-snapper-ts/src/index.ts`)

- **`RouteTool`** binds MapLibre `mousemove`, `click`, `dblclick`, drag and key handlers.
- **`snapDistancePixels = 30`**, converted to metres at the cursor.
- **Keys:** Enter finishes, Escape cancels, Ctrl+Z undoes, **S** toggles snap mode.
- **`split.ts`:** `splitRoute` splits a finished LineString at a point and rebuilds waypoint metadata.

### 2.4 Tooling

- **OSM import:** a browser `import.html` or a CLI, with an optional boundary GeoJSON clip.
- **GeoJSON import:** LineStrings must **share points** to connect: "If LineStrings cross but don't share points (within 7 decimal places) they won't connect."
- **Examples:** `examples/index.html`, `examples/serve_locally.sh`.

---

## 3. How this differs from RideScore paint mode

**RideScore column: Built** (as of today's code).

| Dimension | route_snapper | RideScore paint mode today |
|-----------|-------------------|-----------------------------|
| **Geometry source** | A fixed `snap.bin` graph | Vector tiles of `survey_segments`, read with `queryRenderedFeatures` (snapping) and `querySourceFeatures` (the prune on lift) |
| **Snap target** | Graph **nodes**, then the shortest path between waypoints | The best-scoring edge of any rendered road within 40 px of the pointer (`findBestCandidate`), sampled about every 50 ms |
| **Ambiguity at crossings** | Low: the user picks nodes or sparse waypoints, and the path is computed | Reduced but still heuristic: lookahead queue (`tryDrainSnapQueue`), stroke direction penalty, continuity bonus, and a distance prune on lift. Live testing found strokes that **end** on an intersection pick the cross street about 5 times in 8. |
| **Output** | One connected `LineString`, plus waypoints and length | A set of blocks, tracked by `tile_id` while painting and sent as `segment_id`s. The survey orders them by shared endpoints (`computeRouteSequence`) and groups them by street name (`buildContiguousSegments`). No route line is sent. |
| **Costs / preferences** | Per-edge forward and backward costs | None. The survey deliberately shows no scores: all roads are drawn in one grey. |
| **Build / deploy** | Rust + wasm-pack, a graph build step, an NPM or CDN bundle | One HTML page plus shared scripts; no build step, no WASM |
| **Area coverage** | Must define the graph extent in advance | Whatever tiles the viewport loads. Long blocks that cross tile edges arrive in pieces, which causes Bug B in the Topic 6 notes. |

**Bottom line:** route_snapper finds **paths on a known graph**; RideScore paint mode collects **blocks near a stroke** from map tiles. They solve related but different problems.

---

## 4. Strengths of route_snapper (ideas worth borrowing)

**External library.** RideScore status noted where relevant.

1. **Waypoints plus shortest path.** Far fewer "wrong street at the intersection" errors than picking the nearest edge at every sample, because the route between two deliberate clicks is chosen on the graph as a whole. *RideScore: idea, not built.*
2. **Explicit snapped vs freehand points** (`Waypoint::Snapped` vs `Free`, `toggleSnapMode`, shift+click). A good pattern for "I really mean this off-street point." *RideScore: idea, not built.*
3. **Per-edge directed costs.** A natural fit for one-way streets or bike-friendliness. *RideScore: idea, not built.* (Using RideScore scores as costs in the survey would need care, since the survey avoids steering riders with our assessment.)
4. **`avoid_doubling_back`.** A penalty on reusing edges between intermediate waypoints. *RideScore: partly built:* `findBestCandidate` multiplies the score of already-selected blocks by `AVOID_REVISIT_MULT` = 1.14 while painting.
5. **`extend_route` vs fixed endpoints.** Clear modes: two-click route vs keep extending. *RideScore: idea, not built.*
6. **`editExistingRoute` with waypoints kept.** Reopen a route for adjustment without redrawing. *RideScore: idea, not built* (see `paint-route-editing-roadmap.md`).
7. **`splitRoute`.** Split one route into two legs. *RideScore: idea, not built;* the survey already splits the route into same-street runs automatically.
8. **Rich preview GeoJSON** (`snapped` flags, cursor hints, undo depth). *RideScore: partly built:* unconfirmed picks show light blue (`pending` feature-state); undo depth is not shown.
9. **Client-only routing.** No latency per interaction once the graph is loaded. *RideScore: snapping is also client-only today, but it is not routing.*
10. **Documented caveats.** The user guide's "Routing caveats" are honest that default graphs may include tram lines or construction and ignore one-way rules.

---

## 5. Limitations and risks for RideScore

**Analysis** (applies if RideScore adopts a graph).

1. **Graph build and freshness.** A pipeline would be needed from RideScore's published road data (the same data behind `survey_segments`) to a noded GeoJSON and then `snap.bin`. The tile pipeline and the graph pipeline can drift apart unless they are versioned together.
2. **Topology quality.** DC centrelines must share vertices at intersections, as the GeoJSON importer expects. Messy topology means broken or missing connections.
3. **Node-centric snapping.** Users snap to junctions, not arbitrary points along a long block. That feels different from "draw along the street."
4. **Bundle and start-up.** Deserializing the graph and building the R-tree has a one-time cost. Today's survey page has no WASM at all.
5. **MapLibre event coordination.** route_snapper needs `boxZoom` and `doubleClickZoom` off while drawing. It would have to coexist with the paint and unpaint canvases and the survey sheet.
6. **Output mismatch.** route_snapper returns a line; the survey needs block ids. Getting from one to the other needs a spatial join (buffer the line, intersect with blocks) or `segment_id` tags on graph edges at build time. Use `segment_id`, never `tile_id`, which changes every data build.
7. **Default OSM costs are not about safety.** "Where I rode" may not be the shortest path; a shortest-path tool can quietly replace the rider's real route with a different one.

---

## 6. Recommendations for RideScore (prioritized)

### Tier A: high value, incremental (no WASM)

1. **Waypoint-assisted "route confirm" mode.** **Idea, not built.** After a rough paint stroke, simplify it to K points, then for each consecutive pair find a short path on a small client-side graph built from the visible tile features. Select the blocks along that path. *Challenge:* tile features are clipped at tile edges (one block can arrive in several pieces), so the graph needs stitching by id.
2. **Borrow UX patterns.** **Partly built.** Today: Undo and Undo stroke buttons, Ctrl/Cmd+Z, and Esc to leave Unpaint mode. Not built: Enter to finish, Esc to cancel the current stroke, a strict/loose snap toggle, visible undo depth.
3. **`avoid_doubling_back` analogue.** **Built** as `AVOID_REVISIT_MULT` = 1.14 in `findBestCandidate`, applied while painting (`enqueuePaintSnap` passes `avoidRevisit: true`).
4. **Document the caveats.** **Idea, not built.** Tell riders, in the UI or help text, that paint snapping is a best guess and how to fix mistakes.

### Tier B: medium effort, strong correctness

5. **Build a DC graph and offer route_snapper as a second drawing tool.** **Idea, not built.** Export the published road blocks as GeoJSON with consistent noding, build `snap.bin` with `geojson-to-route-snapper`, and tag each edge with its `segment_id`. Offer "Draw route (snapped)" next to "Paint Route." On finish, collect the `segment_id`s along the line.
6. **`editExistingRoute` pattern.** **Idea, not built.** Reopen a finished route as waypoints for correction.

### Tier C: research, longer term

7. **Build the graph from vector tiles on the fly.** **Idea, not built.** Avoids a second pipeline but needs careful stitching across tiles and zooms.
8. **Server-side shortest path** (PostGIS pgRouting). **Idea, not built.** Same UX as Tier B with the graph in the database; more latency, simpler client. The API today has only `POST /api/submissions` and `GET /health`, so this would need a new endpoint.

---

## 7. Decision matrix

**Analysis.**

| If your priority is… | Favour… |
|----------------------|--------|
| Fastest improvement, minimal build | Keep tile-based paint; fix the known bugs and apply Tier A. |
| Fewest wrong blocks at complex intersections | Graph plus shortest path (Tier B) for at least one drawing mode. |
| Exact, lasting block ids | Graph edges tagged with `segment_id` at build time, or a spatial join with a tolerance check. |
| No WASM, single page | Don't embed route_snapper; use server-side or precomputed paths plus a block join. |
| Sharing tooling with other route-planning projects | Adopt the route-snapper NPM package and its graph build scripts. |

---

## 8. File index (upstream repository)

**External library.** Paths in https://github.com/dabreegster/route_snapper.

| Path | Role |
|------|------|
| `README.md` | Project overview, demo link |
| `user_guide.md` | Graph build, API, events, MapLibre gotchas |
| `route-snapper-graph/src/lib.rs` | Serializable graph schema |
| `route-snapper/src/lib.rs` | WASM `JsRouteSnapper`, routing and UI state |
| `route-snapper-ts/src/index.ts` | `RouteTool` MapLibre bindings |
| `route-snapper-ts/src/split.ts` | Route splitting helper |
| `osm-to-route-snapper/` | CLI: OSM → `snap.bin` |
| `geojson-to-route-snapper/` | CLI: GeoJSON → `snap.bin` |
| `examples/index.html` | End-to-end demo |

---

## 9. Summary

route_snapper is strong where RideScore paint mode is weak: **correct connectivity** and **deliberate route shape**, via waypoints and shortest paths on a graph. It fits RideScore less well unless we invest in a graph build, a mapping from graph edges to `segment_id`, and WASM tooling.

**Practical path:** keep improving heuristic paint for fluid "I traced my ride" input. Today it already has the lookahead queue, the continuity bonus, the distance prune on lift, and the Unpaint eraser; the open problems are listed in the Topic 6 bugs analysis. Lasso deselect is still an idea. Then consider a second "snapped route" mode (route_snapper or server routing) for riders who want a clean line and fewer intersection errors, and merge the blocks from both modes into the same survey payload.

---

## 10. In scope: draggable junction editing

**Idea, not built.**

Draggable waypoints for small corrections after painting (the route_snapper pattern: snapped vs free points, drag handles, preview) are in scope for RideScore. They can be lightweight (re-snap tiles between handles) or graph-backed (WASM and `snap.bin`). See `paint-route-editing-roadmap.md` in this folder.
