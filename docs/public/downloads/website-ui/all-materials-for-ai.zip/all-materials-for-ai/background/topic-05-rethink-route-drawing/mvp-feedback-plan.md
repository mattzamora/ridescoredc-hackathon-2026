# Paint mode: original build plan, with what was built

Describes the code as of website develop 38386ee (October 2026).
Explains why paint-a-route on the survey page works the way it does, by walking through its original build plan step by step.

> **Historical context:** this is the original plan for paint mode, which is now built. It explains why the feature works the way it does. Where today's code differs from the plan, it's noted inline. All of today's paint code is in `frontend/survey/index.html` (the survey, served at `/survey/`). The scored map at `/` (`frontend/index.html`) has no paint mode.

---

## Intention

**Built.**

Let cyclists trace the route they rode by painting over streets with a finger or mouse. The stroke snaps to nearby road blocks and highlights them blue. Once the route is painted, the rider answers a short survey about it, and the answers are stored against those specific blocks.

**Today:** the blocks are tracked on the page by `tile_id` (MapLibre's feature-state id while painting; it changes every data build). When the survey is submitted, `segmentIdsFor` converts them to `segment_id`, the lasting id stored with the answers.

**Core flow as planned, and as built:**

```
Tap "Paint Route"
   → drag finger or mouse along streets
   → blocks snap and highlight (light blue while pending, blue when committed)
   → lift → stroke fades
   → selection badge appears ("N roads selected", Undo, Undo stroke, Clear, "Rate route →")
   → survey sheet opens
   → submit → POST /api/submissions with segment_ids and answers
```

**Planned as out of scope:** graph-based routing, per-segment questions, saving the selection offline.
**Today:** graph routing and offline saving are still not built. Per-segment questions **were** built: the survey asks questions for each run of blocks on the same street (see Step 7).

---

## What existed when the plan was written

**Historical plan.** The plan started from the scored map, a Martin tile server on `localhost:3000` serving `update_score` tiles, a road table keyed by `ogc_fid`, and a reference survey project.

**Today:**

| Piece | Today |
|---|---|
| Road data for the survey | Published as `serving.survey_segments`: street names and shapes, **no score**. The survey never loads scored tiles, so a rider is not shown our assessment before giving theirs. |
| Tiles | Requested at `/tiles/survey_segments/{z}/{x}/{y}` on the page's own address; nginx (or the Vite dev server) forwards `/tiles/` to Martin. |
| Feature ids | Each feature carries `tile_id` (integer, per build) and `segment_id` (text, lasting). |
| Map page | `frontend/index.html` at `/`, scored `update_score` tiles, no paint mode. |
| Backend | `POST /api/submissions` in `api/main.py`, stored in `app.survey_submissions` as `segment_ids TEXT[]`. |

---

## Step 1: give every feature an id for feature-state

**Built differently.** The plan was to add `ogc_fid` to the `update_score` SQL function and promote it as the feature id.

**Today:** the survey does not use `update_score` at all. Its source is:

```javascript
map.addSource('segments', {
  type: 'vector',
  tiles: [`${location.origin}/tiles/survey_segments/{z}/{x}/{y}`],
  promoteId: { 'survey_segments': 'tile_id' },
  minzoom: 1,
  maxzoom: 14
});
```

`tile_id` is used for feature-state only. Never store it: store `segment_id`.

---

## Step 2: a selection highlight layer

**Built,** with different names and an extra state.

The plan's `update_score_selected` layer became `road-selected` on source `segments`, source-layer `survey_segments`: blue `#2563eb`, width 6, opacity 1 when `selected` and 0.48 when `pending` (a pick waiting for the lookahead to confirm it). It sits on top of `road-score`, which on the survey page draws every road in one grey colour, because shading by score would bias the answers.

Not in the plan: two more layers, `road-survey-border` and `road-survey-active`, outline the block group being asked about in the survey (`surveyActive` feature-state).

---

## Step 3: paint mode UI

**Built as planned.**

The controls bar on the survey page has **Imagery**, **Accidents**, **Paint Route** (`#paintBtn`, calls `togglePaintMode`) and, not in the plan, **Unpaint** (`#unpaintBtn`, calls `toggleUnpaintMode`).

The `#paint-canvas` overlay covers the window, has `pointer-events: none` until paint mode turns it to `all`, `z-index: 500` and `touch-action: none`. Unpaint mode has its own `#unpaint-canvas`.

---

## Step 4: paint mode logic

**Built as planned,** plus a few extras.

`togglePaintMode` toggles `paintMode`, the button's `active` class and the canvas's pointer events, and disables `dragPan`, `scrollZoom`, `doubleClickZoom` and `touchZoomRotate` while painting. It re-enables them only if unpaint mode is also off.

Extras today: it first turns unpaint mode off; if a stroke is in progress it finishes it (`finishStrokePipeline`); and it shows the `#paint-hint` strip.

`selectedSegments` is a `Map` from `tile_id` to the feature's properties, as planned (the plan keyed it by `ogc_fid`).

---

## Step 5: stroke drawing and snap-to-block

**Built differently.** The plan drew a straight-line polyline and, every 50 ms, selected the feature with the nearest **vertex**. Today's code is considerably more careful.

**Stroke drawing:**

- `pointerdown` starts `paintPoints`, captures the pointer (`setPointerCapture`), and resets the stroke state (momentum, snap queue, the set of ids touched this stroke).
- `pointermove` records the point, updates the stroke direction (`updateMomentum`) and draws a Catmull-Rom spline (`drawSpline`, blue, 70% opacity) instead of straight segments.
- On lift, `fadeStroke` fades it out (about 300 ms).

**Snapping** (see `snap-intersection-problem.md` and `route-selector-bugs-analysis.md` in the Topic 6 folder for detail):

- The 50 ms throttle is as planned, but it calls `enqueuePaintSnap`, not a direct select.
- `findBestCandidate` queries layer `road-score` within `SNAP_RADIUS` = 40 px, as planned, but measures the distance to each **edge** (`ptSegDist`) rather than each vertex, and adjusts it by stroke direction (`PERP_PENALTY`), continuity with the last block (`CONTINUITY_SCORE_MULT`) and a small penalty for already-selected blocks (`AVOID_REVISIT_MULT`).
- Picks go into a lookahead queue (`snapQueue`) and are committed by `tryDrainSnapQueue` only after the stroke has gone on far enough to confirm the direction. Committing goes through `commitFromQueueItem` → `commitSegment`, which sets `selected` feature-state and records the block's order and endpoints for the survey.
- On lift, `finishStrokePipeline` flushes the queue (`flushSnapQueueRelaxed`), removes blocks that ended up far from the stroke (`pruneSelectionsFarFromRawPolyline`) and records the stroke for **Undo stroke**.
- A short tap (`isStrokeTapGesture`) adds the single nearest block.

---

## Step 6: selection badge and Clear

**Built differently.**

`#selection-badge` appears when anything is selected. Instead of "N segments selected" with Clear and "Rate segments →", it has:

- `#badge-count`: "N roads selected". `updateBadge` counts **runs of blocks on the same street** (`buildContiguousSegments().length`), not individual blocks.
- **Undo** (`undoLastSegment`, also Ctrl/Cmd+Z) and **Undo stroke** (`undoLastPaintStroke`). Not in the plan.
- **Clear** (`clearSelection`): resets feature-state on every selected block and clears all selection and undo state, as planned and more.
- **Rate route →** (`openSurveyPanel`).

---

## Step 7: survey panel

**Built differently.** The plan was a hardcoded right-hand panel with one 1–5 safety rating for the whole route, a factor checklist and a comment box, logging the payload to the console.

**Today** (`openSurveyPanel`, `#survey-sheet`; a bottom sheet on phones, a right-hand panel on desktop):

1. `buildContiguousSegments` puts the selected blocks in route order (`computeRouteSequence` links blocks by shared endpoints and follows the paint order) and groups them into runs with the same street name.
2. For each run, the rider answers: which rider the block suits (LTS 1–4), how safe they felt (1–10), and, when LTS is 3 or 4, what drove the stress (a checklist). The map outlines the run being asked about.
3. A route summary asks time of day, overall satisfaction (1–5), whether they'd ride it again, and optional comments.
4. `submitSurvey` sends `POST /api/submissions` with `segment_ids` for the whole route and a `contiguous_segments` list with each run's `segment_ids` and answers. All ids go through `segmentIdsFor`, so only `segment_id`s are sent. The thank-you screen appears even if the request fails (the error is logged to the console).

Not built from the plan's handoff idea: the painted stroke as a GeoJSON `LineString` and a client timestamp are not sent.

---

## Demo checklist (original) and status

| Step | Status |
|---|---|
| Add `ogc_fid` to `update_score` | Built differently: survey uses `survey_segments` tiles with `tile_id` and `segment_id` |
| Add `promoteId` to `addSource` | Built: `promoteId: { 'survey_segments': 'tile_id' }` |
| Add selection highlight layer | Built: `road-selected` |
| Add Paint Route button | Built |
| Add `#paint-canvas` overlay | Built |
| Paint mode JS (toggle, pointer events, stroke drawing) | Built |
| Snap-to-block logic | Built differently: lookahead queue and scoring |
| Selection badge and Clear | Built, with Undo and Undo stroke |
| Survey panel | Built differently: per-street questions plus route summary |
| Wire submit, log payload | Built further: POSTs to `/api/submissions` |

---

## Next steps after the demo (original) and status

1. **JSON-driven survey schema.** Idea, not built: the questions are written directly in the page's HTML.
2. **Backend endpoint to receive and store feedback.** Built: `POST /api/submissions`, stored in `app.survey_submissions`.
3. **Show aggregate feedback on the map as a second layer.** Idea, not built: the map page does not read survey submissions.
4. **Select a whole named route in one tap (`route_id` grouping).** Idea, not built.
