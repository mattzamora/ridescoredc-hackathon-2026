# Website / UI

This track improves the RideScore DC website: the **map** people use to explore how safe each street is to bike, and the **route survey** where riders tell us how a ride felt. You can fix rough edges, build something new, mock up a landing page, or write a plan. Web developers, designers, mapping enthusiasts and planners are all welcome.

The code lives in the [RideScore DC website repository](https://github.com/civictechdc/ridescoredc-website) on the `develop` branch. The current site is at [dev.ridescoredc.com](https://dev.ridescoredc.com/).

## Start here

1. **Pick a topic.** Browse the [13 topics](/tracks/website-ui/topics) and choose one per team.
2. **Set up.** Install what your topic needs, ideally before Saturday. Some topics need nothing at all. See [Setting up](/tracks/website-ui/setting-up), and the [Technical guides](/tracks/website-ui/making-changes) for step-by-step recipes once you're coding.
3. **Build for two to three hours.** Mentors check in at 1:45. Ask questions any time.
4. **Hand in by 4:00** with one form per team, then show your work in a two-minute demo at 4:15. See [Submitting your work](/tracks/website-ui/submitting-your-work).

## What's in this guide

| Section | What it covers |
|---|---|
| [**Setting up**](/tracks/website-ui/setting-up) | Which setup your topic needs (none, Front-End or Full Stack), step-by-step guides for each including Windows, and [Technical guides](/tracks/website-ui/making-changes): recipes for common changes and opening a pull request. |
| [**Understanding the site**](/tracks/website-ui/understanding-the-site) | How the pieces fit together: the pages, the map tiles, the survey API and the database; where things live in the code; and what the data contains. |
| [**Topics**](/tracks/website-ui/topics) | All 13 topics by level, each with its own page: the problem, tools, the challenge, what "done" looks like, and how to hand it in. |
| [**Submitting your work**](/tracks/website-ui/submitting-your-work) | The one form every team fills in, your team's folder in the shared hand-in Drive folder, your AI-use note, and the demo. |

## Downloads

- **[all-materials-for-ai.zip](/downloads/website-ui/all-materials-for-ai.zip):** this whole guide plus the background notes, in Markdown. Upload it to your AI assistant and ask it to help you plan your topic.
- **[All notes across topics](/downloads/website-ui/all-notes-across-topics.zip)** (just in case 😄): every background note for Topics 2–6, in Word and Markdown. Each of those topic pages also links its own zip, intended more for use with an AI assistant, for rapid comprehension of the issue.

## How judging works

There's no ranking: this is a collaborative hackathon. Each topic page has a **Done when** list, concrete checks that mentors use to give feedback at the 1:45 check-in and after demos. Code is checked on your own local copy of the site. Unfinished work is welcome; say what doesn't work yet.

## Using AI

AI tools are encouraged. Two or three hours is short, and a coding, design or writing assistant can help you get much further. You stay responsible for what you hand in, and every submission includes a short AI-use attestation. See [Submitting your work](/tracks/website-ui/submitting-your-work#_2-say-how-you-used-ai).

## Glossary

| Term | Meaning |
|---|---|
| **API** | The small Python (FastAPI) service that saves survey responses. It answers addresses starting `/api/`. |
| **Branch** | Your own line of changes in Git. Make one for each piece of work, starting from `develop`. |
| **Browser console** | A panel in your browser that shows errors and lets you run small commands. Press F12 (or Cmd+Option+I on a Mac) and choose **Console**. |
| **Custom panel** | The sliders in the map’s **Settings** panel that let you change how much each street feature counts toward the score. |
| **Dev site** | [dev.ridescoredc.com](https://dev.ridescoredc.com/), the shared development server. Front-End setups get their map data from it. |
| **`develop`** | The branch where new work lands. Pull requests go against `develop`, not `main`. |
| **Docker** | Runs the database, API, tile server and nginx on your own machine. Only the Full Stack setup needs it. |
| **Docker container** | One program running in its own sealed box on your laptop. The Full Stack setup runs four: `nginx`, `martin`, `fastapi` and `db`. See the [Infrastructure guide](/tracks/website-ui/infrastructure). |
| **Done when** | The checklist on each topic page that defines a finished result and guides feedback. |
| **Drive folder** | One Google Drive folder per team, created inside the [Website/UI hand-in folder](https://drive.google.com/drive/folders/1n4fRuS5yiRNWO8Tfr6MA1l56i626spuh?usp=sharing), for anything that isn't code. It must open in a private browser window. |
| **`dvh`** | A CSS height unit that follows the visible screen on phones, including when the address bar shows or hides. `vh` doesn’t. |
| **Endpoint** | One address on the API that does one job, for example `POST /api/submissions` saves a survey. |
| **ES modules** | JavaScript files that share code with `import` and `export`, so each file only loads what it needs. |
| **Fork** | Your own copy of a repository on GitHub. You push your branch there and open a pull request from it. |
| **Front-End setup** | Git, Node.js and an editor. Runs the pages on your laptop with `npm run dev`; map data comes from the dev site. Enough for most code topics. |
| **Full Stack setup** | Front-End plus Docker and uv. Runs the whole site, database included, on your machine. Needed to store new data or change the API. |
| **Guided tour** | A few short steps that point at a page's features one at a time, with Skip and Restart. Topic 2 builds one for the map. |
| **LTS** | Level of Traffic Stress: a 1–4 rating of how stressful a street is to bike, from calm to hostile. The basis of the safety score. |
| **MapLibre** | The JavaScript library that draws the map in the browser. |
| **Martin** | The tile server. It turns database rows into map tiles. |
| **Migration** | A numbered file that changes the database tables, applied with `npm run migrate`. Never edit one that has already run. |
| **nginx** | The web server in front of everything. It sends each request to the right place: pages from disk, map tiles to Martin, survey answers to the API. |
| **Parquet** | A compact file format for tables of data, readable from Python. The published road data comes as Parquet files. |
| **Plan or proof of concept** | What Advanced topics hand in: a written plan, or a small working piece of code that proves the idea. |
| **PMTiles** | A single file holding a whole set of map tiles, which a browser can read directly from ordinary web hosting. |
| **Pointer events** | The browser events for touches, pens and mouse clicks, handled the same way. The paint tool listens to them. |
| **PostGIS** | The database: PostgreSQL with map geometry support. |
| **Pull request (PR)** | A request to merge your branch into the project. How code is handed in. |
| **Pydantic** | The Python library the API uses to check that incoming data has the right shape before saving it. |
| **RideScore** | The project's safety score for each street block, blending LTS with the bike facility and crash history. |
| **Schema** | A named area of the database. RideScore DC has three: `data` (roads, crashes, scores), `app` (survey answers) and `serving` (what the map may show). |
| **`segment_id`** | A street block's lasting ID. Survey answers are stored against it. |
| **Spec** | A written plan or proposal, for example on the [models wiki](https://github.com/civictechdc/ridescoredc-models/wiki) proposal template. |
| **Survey** | The page at `/survey/` where a rider paints a route on the map and rates it block by block. It never shows our scores. |
| **`tile_id`** | A number the map uses internally. It changes with every data build, so never store it. |
| **Tile** | One small square of the map at one zoom level. The browser fetches only the tiles it is showing, from Martin. |
| **tippecanoe** | A command-line tool that turns map data (GeoJSON) into map tiles. It runs on macOS and Linux, or WSL on Windows. |
| **Vite** | The development server behind `npm run dev`. Serves the pages at `localhost:5173` and reloads on save. |